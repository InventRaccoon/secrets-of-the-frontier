CREDITS:
Alex, David and Stian for creating Starsector
AxleMC131 for various kindly donated/free to use sprites
Medikohl and HELMUT for creating the original versions of sprites I updated
LazyWizard for scripting help
Tartiflette for some code of his I use
Nicke535 for his projectile trail code
Unofficial Starsector Discord for a lot of advice

LICENSE STUFF:
A few of my sprites were made by AxleMC131, and you should ask him for permission before use. They are: Cackle. Parapet. Peon. Assault Pulser. Pulse Rocket. Artillery Swarmer.
Everything else in Arsenal Expansion comes from either myself, sprite dumps or from free-to-use sources within the modding community (in most cases if you use those you need to attribute them to their original creator). So, uh, go wild. Please don't put my own sprites in other mods without my permission and I'd ask that you refrain from using the same sprites as me (just for the sake of user-friendliness). Use my scripts and everything in the data folder as references with reckless abandon (the comments inside will clearly show if it's not originally mine).

If Starsector has updated beyond 0.95.1a and I have not updated Arsenal Expansion to support it, feel free to update it to the current version and share that updated version of the mod.

Thanks, Inventor Raccoon
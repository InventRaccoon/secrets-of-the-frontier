package data.missions.surrounded;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

    public void defineMission(MissionDefinitionAPI api) {
	    api.initFleet(FleetSide.PLAYER, "ISS", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "ISS", FleetGoal.ATTACK, true);
		
		api.setFleetTagline(FleetSide.PLAYER, "Your fleet");
		api.setFleetTagline(FleetSide.ENEMY, "ISS Poor Sod");
		
		api.addBriefingItem("Try out ships in the simulator.");
		api.addBriefingItem("Enjoy!");
		
		api.addToFleet(FleetSide.PLAYER, "vanquish_outdated", FleetMemberType.SHIP, true);
		api.addToFleet(FleetSide.PLAYER, "theseus_assault", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "cavalier_attack", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "tremor_assault", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "torment_strike", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "lustrare_attack", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "keeper_cs", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "kindling_cs", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "hailfyre_elite", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "flourish_attack", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "pigeon_xiv_attack", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "pigeon_strike", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "pigeon_d_attack", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "scrapper_attack", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "scrapper_d_junk", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "vow_filled", FleetMemberType.SHIP, false);
		
		api.addToFleet(FleetSide.ENEMY, "lasher_Assault", FleetMemberType.SHIP, "ISS Poor Sod", false);
		
		float width = 10000f;
		float height = 16000f;
		api.initMap((float)-width/2f, (float)width/2f, (float)-height/2f, (float)height/2f);
		
		float minX = -width/2;
		float minY = -height/2;
		
	}

}

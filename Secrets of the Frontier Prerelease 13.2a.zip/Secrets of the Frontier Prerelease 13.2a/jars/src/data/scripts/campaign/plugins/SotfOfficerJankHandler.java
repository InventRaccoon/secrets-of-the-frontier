package data.scripts.campaign.plugins;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import data.scripts.SotfModPlugin;
import data.scripts.campaign.ids.SotfIDs;
import data.scripts.campaign.ids.SotfPeople;
import data.scripts.utils.SotfMisc;

import java.util.ArrayList;

/**
 *	... Look, I just decided to be honest with how I name this one.
 *  Handily makes sure that things go as they should in regard to officers, e.g:
 *  - Make sure Sierra is where she should be, and that there's only 1 active Concord ship at a time
 *  - Make sure that ships piloted by officers with Derelict Contingent (i.e Barrow) are properly reset to being
 *  restorable once the officer is gone
 */

public class SotfOfficerJankHandler implements EveryFrameScript {

    public void advance(float amount) {

        ArrayList<FleetMemberAPI> sierraShips = new ArrayList<>();
        // delete Sierra from non-Concord ships: failsafe to prevent duping and the like
        if (SotfModPlugin.WATCHER) {
            for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
                // modded Sierra ship compat
                if (member.getHullSpec().hasTag("sotf_add_concord") && !member.getVariant().hasHullMod(SotfIDs.SIERRAS_CONCORD)) {
                    member.getVariant().addPermaMod(SotfIDs.SIERRAS_CONCORD);
                }
                if (member.getCaptain() == SotfPeople.getPerson(SotfPeople.SIERRA) && !member.getVariant().getHullMods().contains(SotfIDs.SIERRAS_CONCORD)) {
                    member.setCaptain(null);
                }
                if (member.getVariant().hasHullMod(SotfIDs.SIERRAS_CONCORD) && !member.getVariant().hasTag(SotfIDs.TAG_INERT)) {
                    sierraShips.add(member);
                }
            }
        }

        // only 1 active ship at a time
        if (sierraShips.size() > 1) {
            for (FleetMemberAPI extra : sierraShips) {
                if (sierraShips.indexOf(extra) != 0) {
                    SotfMisc.toggleSierra(extra, null);
                }
            }
        }

        for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
            if (member.getVariant().hasTag("sotf_dcontingent_unrestorable")) {
                if (member.getCaptain() != null) {
                    if (!member.getCaptain().getStats().hasSkill(SotfIDs.SKILL_DERELICTCONTINGENTP)) {
                        member.getVariant().removeTag("sotf_dcontingent_unrestorable");
                        member.getVariant().removeTag(Tags.VARIANT_UNRESTORABLE);
                    }
                } else {
                    member.getVariant().removeTag("sotf_dcontingent_unrestorable");
                    member.getVariant().removeTag(Tags.VARIANT_UNRESTORABLE);
                }
            }
        }
    }

    public boolean isDone() {
        return false;
    }

    public boolean runWhilePaused() {
        return true;
    }

}

// Death comes from afar. Phantom gains extraordinary weapon range and accuracy.
package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class FronSecPhantomWatchful extends FronSecPhantomBaseTrait {

	public static final float RECOIL_BONUS = 50f;

	public static float RANGE_BONUS = 80f;
	public static float PD_MINUS = 40f;
	public static float VISION_BONUS = 1000f;
	public static float AUTOFIRE_AIM = 0.5f;

	// Supercomputer with ATC range bonuses and IPDAI target leading
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		ship.getMutableStats().getBallisticWeaponRangeBonus().modifyPercent(id, RANGE_BONUS);
		ship.getMutableStats().getEnergyWeaponRangeBonus().modifyPercent(id, RANGE_BONUS);
		ship.getMutableStats().getNonBeamPDWeaponRangeBonus().modifyPercent(id, -PD_MINUS);
		ship.getMutableStats().getBeamPDWeaponRangeBonus().modifyPercent(id, -PD_MINUS);

		ship.getMutableStats().getSightRadiusMod().modifyFlat(id, VISION_BONUS);
		ship.getMutableStats().getAutofireAimAccuracy().modifyFlat(id, AUTOFIRE_AIM);

		ship.getMutableStats().getMaxRecoilMult().modifyMult(id, 1f - (0.01f * RECOIL_BONUS));
		ship.getMutableStats().getRecoilPerShotMult().modifyMult(id, 1f - (0.01f * RECOIL_BONUS));
		ship.getMutableStats().getDynamic().getMod(Stats.PD_BEST_TARGET_LEADING).modifyFlat(id, 1f);
	}


	
}
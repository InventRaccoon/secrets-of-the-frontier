package data.shipsystems;

public class FronSecASBSystem {
}

package data.scripts.campaign.customstart;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.Script;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.CharacterCreationData;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.impl.campaign.rulecmd.FireBest;
import com.fs.starfarer.api.impl.campaign.rulecmd.NGCAddStandardStartingScript;
import com.fs.starfarer.api.impl.campaign.rulecmd.newgame.NGCAddStartingShipsByFleetType;
import com.fs.starfarer.api.util.Misc;
import data.scripts.campaign.ids.FronSecIDs;
import data.scripts.utils.FronSecMisc;
import exerelin.campaign.ExerelinSetupData;
import exerelin.campaign.PlayerFactionStore;
import exerelin.campaign.customstart.CustomStart;
import exerelin.campaign.customstart.Nex_SpacerObligation;
import exerelin.utilities.StringHelper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class FronSecHauntedStart extends CustomStart {

    @Override
    public void execute(InteractionDialogAPI dialog, Map<String, MemoryAPI> memoryMap) {
        CharacterCreationData data = (CharacterCreationData) memoryMap.get(MemKeys.LOCAL).get("$characterData");
        data.addScriptBeforeTimePass(new Script() {
            public void run() {
                Global.getSector().getMemoryWithoutUpdate().set("$spacerStart", true);
                MemoryAPI char_mem = Global.getSector().getCharacterData().getMemoryWithoutUpdate();
                char_mem.set(FronSecIDs.GUILT_KEY, Global.getSettings().getFloat("fronsec_hauntedGuilt"));
                char_mem.set(MemFlags.PLAYER_ATROCITIES, 3f);
                //Global.getSector().getMemoryWithoutUpdate().set("$nex_startLocation", "nomios");
            }
        });
        String vid = "kite_original_Stock";
        data.addStartingFleetMember(vid, FleetMemberType.SHIP);
        FleetMemberAPI temp = Global.getFactory().createFleetMember(FleetMemberType.SHIP, vid);

        int fuel = (int)temp.getFuelCapacity();

        data.getStartingCargo().addItems(CargoAPI.CargoItemType.RESOURCES, Commodities.CREW, 2);
        data.getStartingCargo().addItems(CargoAPI.CargoItemType.RESOURCES, Commodities.SUPPLIES, 15);
        data.getStartingCargo().addItems(CargoAPI.CargoItemType.RESOURCES, Commodities.FUEL, fuel);

        AddRemoveCommodity.addFleetMemberGainText(temp.getVariant(), dialog.getTextPanel());
        AddRemoveCommodity.addCommodityGainText(Commodities.CREW, 2, dialog.getTextPanel());
        AddRemoveCommodity.addCommodityGainText(Commodities.SUPPLIES, 15, dialog.getTextPanel());
        AddRemoveCommodity.addCommodityGainText(Commodities.FUEL, fuel, dialog.getTextPanel());

        data.getStartingCargo().getCredits().add(10000);
        AddRemoveCommodity.addCreditsGainText(10000, dialog.getTextPanel());
        MutableCharacterStatsAPI stats = data.getPerson().getStats();
        stats.addPoints(1);

        dialog.getTextPanel().setFontSmallInsignia();
        dialog.getTextPanel().addParagraph("Gained a reprehensible history of atrocities and the gnawing guilt that accompanies it", Misc.getNegativeHighlightColor());
        dialog.getTextPanel().highlightInLastPara(Misc.getHighlightColor(), "a reprehensible history of atrocities", "gnawing guilt");

        dialog.getTextPanel().addParagraph("Acquired vengeful and malevolent pursuers", Misc.getNegativeHighlightColor());
        dialog.getTextPanel().highlightInLastPara(Misc.getHighlightColor(), "vengeful and malevolent pursuers");
        dialog.getTextPanel().setFontInsignia();

        CampaignFleetAPI tempFleet = FleetFactoryV3.createEmptyFleet(
                PlayerFactionStore.getPlayerFactionIdNGC(), FleetTypes.PATROL_SMALL, null);
        tempFleet.getFleetData().addFleetMember(temp);
        tempFleet.getFleetData().setFlagship(temp);
        temp.setCaptain(data.getPerson());
        temp.getRepairTracker().setCR(0.7f);
        tempFleet.getFleetData().setSyncNeeded();
        tempFleet.getFleetData().syncIfNeeded();
        tempFleet.forceSync();

        // enforce normal difficulty
        data.setDifficulty("normal");
        ExerelinSetupData.getInstance().easyMode = false;
        PlayerFactionStore.setPlayerFactionIdNGC(Factions.PLAYER);
        ExerelinSetupData.getInstance().freeStart = true;

        data.addScript(new Script() {
            public void run() {
                CampaignFleetAPI fleet = Global.getSector().getPlayerFleet();

                NGCAddStandardStartingScript.adjustStartingHulls(fleet);

                fleet.getFleetData().ensureHasFlagship();

                for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
                    float max = member.getRepairTracker().getMaxCR();
                    member.getRepairTracker().setCR(max);
                }
                fleet.getFleetData().setSyncNeeded();
            }
        });

        dialog.getVisualPanel().showFleetInfo(StringHelper.getString("exerelin_ngc", "playerFleet", true),
                tempFleet, null, null);

        dialog.getOptionPanel().addOption(StringHelper.getString("done", true), "nex_NGCDone");
        dialog.getOptionPanel().addOption(StringHelper.getString("back", true), "nex_NGCStartBack");
    }

}

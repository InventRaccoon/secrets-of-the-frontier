// This class keeps track of all the important people, and allows us to find them easily
package data.scripts.campaign.ids;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PersonImportance;
import com.fs.starfarer.api.characters.FullName.Gender;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.util.Misc;

public class FronSecPeople {

    // Omicron-Primus-Regnant
    public static String OMICRON = "fs_omicron";

    // Sierra
    public static String SIERRA = "fs_sierra";
    public static String EIDOLON = "fs_eidolon";
    // A Promise
    public static String VENA_ECHO_VOX = "fs_vena_echo_vox";
    public static String APROMISE_BAR_LEAGUE = "fs_apromise_bar_league";
    public static String APROMISE_BAR_GIVER = "fs_apromise_bar_giver";
    public static String APROMISE_BAR_HEG = "fs_apromise_bar_heg";
    public static String APROMISE_BAR_GRUMP = "fs_apromise_bar_grump";

    public static PersonAPI getPerson(String id) {
        return Global.getSector().getImportantPeople().getPerson(id);
    }

    public static void create() {
        createCharacters();
    }

    public static void createCharacters() {
        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();

        // Omicron-Primus-Regnant
        if (getPerson(OMICRON) == null) {
            PersonAPI person = Global.getFactory().createPerson();
            person.setId(OMICRON);
            person.setFaction(FronSecIDs.OMICRON_FACTION);
            person.setGender(Gender.MALE);
            person.setRankId(FronSecIDs.OMICRON_RANK);
            person.setPostId(FronSecIDs.OMICRON_POST);
            person.getName().setFirst("Omicron-Primus-Regnant");
            person.getName().setLast("");
            person.setImportance(PersonImportance.VERY_HIGH);
            person.getStats().setSkillLevel(Skills.ELECTRONIC_WARFARE, 1);
            person.getStats().setSkillLevel(Skills.SALVAGING, 1);
            person.setPortraitSprite(Global.getSettings().getSpriteName("fronsec_characters", "omicron"));
            ip.addPerson(person);
        }

        // Sierra-Nought-Bravo
        if (getPerson(SIERRA) == null) {
            PersonAPI person = Global.getFactory().createPerson();
            person.setId(SIERRA);
            person.setFaction(FronSecIDs.SIERRA_FACTION);
            person.setGender(Gender.FEMALE);
            person.setRankId(FronSecIDs.SIERRA_RANK);
            person.setPostId(FronSecIDs.SIERRA_POST);
            person.getName().setFirst("Sierra");
            person.getName().setLast("");
            person.setImportance(PersonImportance.VERY_HIGH);
            person.setPortraitSprite(Global.getSettings().getSpriteName("fronsec_characters", "sierra"));
            // Officer stats
            person.setPersonality(Personalities.STEADY);
            person.getStats().setLevel(6);
            person.getStats().setSkillLevel(Skills.HELMSMANSHIP, 1);
            person.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
            person.getStats().setSkillLevel(Skills.ORDNANCE_EXPERTISE, 1);
            person.getStats().setSkillLevel(Skills.SYSTEMS_EXPERTISE, 2);
            person.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 1);
            person.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 1);
            //Misc.setUnremovable(person, true);
            //person.getStats().setSkillLevel(Skills.POINT_DEFENSE, 1);
            //person.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 1);
            // Custom combat chatter personality
            person.getMemoryWithoutUpdate().set("$chatterChar", "sierra");
            ip.addPerson(person);
        }

        // : : : : {Eidolon}
        if (getPerson(EIDOLON) == null) {
            PersonAPI person = Global.getFactory().createPerson();
            person.setId(EIDOLON);
            person.setFaction(FronSecIDs.EIDOLON_FACTION);
            person.setGender(Gender.FEMALE);
            person.setRankId(FronSecIDs.EIDOLON_RANK);
            person.setPostId(FronSecIDs.EIDOLON_POST);
            person.getName().setFirst("Eidolon");
            person.getName().setLast("");
            person.setPortraitSprite(Global.getSettings().getSpriteName("fronsec_characters", "eidolon"));
            // Officer stats
            person.setPersonality(Personalities.RECKLESS);
            person.getStats().setLevel(9);
            person.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
            person.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
            person.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
            person.getStats().setSkillLevel(Skills.SYSTEMS_EXPERTISE, 2);
            person.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 2);
            person.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 2);
            person.getStats().setSkillLevel(Skills.ORDNANCE_EXPERTISE, 2);
            person.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
            person.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
            ip.addPerson(person);
        }

        // A PROMISE
        // Venator-Echo-Vox
        if (getPerson(VENA_ECHO_VOX) == null) {
            PersonAPI person = Global.getFactory().createPerson();
            person.setId(VENA_ECHO_VOX);
            person.setFaction(FronSecIDs.OMICRON_FACTION);
            person.setGender(Gender.FEMALE);
            person.setRankId(Ranks.SPACE_CAPTAIN);
            person.setPostId(Ranks.POST_OFFICER);
            person.getName().setFirst("Venator-Echo-Vox");
            person.getName().setLast("");
            person.setPortraitSprite(Global.getSettings().getSpriteName("fronsec_characters", "venator"));
            ip.addPerson(person);
        }

        // Persean League captain
        if (getPerson(APROMISE_BAR_LEAGUE) == null) {
            PersonAPI person = Global.getSector().getFaction(Factions.PERSEAN).createRandomPerson(Gender.FEMALE);
            person.setId(APROMISE_BAR_LEAGUE);
            person.setRankId(Ranks.SPACE_CAPTAIN);
            person.setPostId(Ranks.POST_OFFICER);
            person.setFaction(Factions.INDEPENDENT);
            ip.addPerson(person);
        }

        // Hegemony 1st AI War Veteran
        if (getPerson(APROMISE_BAR_HEG) == null) {
            PersonAPI person = Global.getSector().getFaction(Factions.HEGEMONY).createRandomPerson(Gender.FEMALE);
            person.setId(APROMISE_BAR_HEG);
            person.setRankId(Ranks.SPACE_CAPTAIN);
            person.setPostId(Ranks.POST_CITIZEN);
            person.setFaction(Factions.INDEPENDENT);
            ip.addPerson(person);
        }

        // Questgiver
        if (getPerson(APROMISE_BAR_GIVER) == null) {
            PersonAPI person = Global.getSector().getFaction(Factions.INDEPENDENT).createRandomPerson(Gender.FEMALE);
            person.setId(APROMISE_BAR_GIVER);
            person.setRankId(Ranks.SPACE_ENSIGN);
            person.setPostId(Ranks.POST_OFFICER);
            ip.addPerson(person);
        }

        // Asharu commander who doesn't like high-tech
        if (getPerson(APROMISE_BAR_GRUMP) == null) {
            PersonAPI person = Global.getSector().getFaction(Factions.INDEPENDENT).createRandomPerson(Gender.MALE);
            person.setId(APROMISE_BAR_GRUMP);
            person.setRankId(Ranks.GROUND_MAJOR);
            person.setPostId(Ranks.POST_BASE_COMMANDER);
            ip.addPerson(person);
        }
    }
}

// one-stop shop for IDs, making it easier to remain consistent when changing them
package data.scripts.campaign.ids;

public class FronSecIDs {

	// A Promise
	public static final String APROMISE_VENA_ENTITY = "fronsec_apromise_vena";
	public static final String APROMISE_OMICRON_ENTITY = "fronsec_apromise_omicron";
	public static final String APROMISE_STATION = "fronsec_apromise_station";

	public static final String SIERRA_CORE = "fronsec_sierracore";
	public static final String SIERRA_FACTION = "fronsec_sierra_faction";
	public static final String OMICRON_FACTION = "fronsec_omicron_faction";

	public static final String SIERRA_PING = "fronsec_sierra_ping";
	public static final String OMICRON_PING = "fronsec_omicron_ping";
	public static final String OMICRON_CALL_PING = "fronsec_omicron_call_ping";
	public static final String OMICRON_MINION_PING = "fronsec_omicron_minion_ping";

	// miscellaneous campaign stuff
	public static final String FRONTIERSECRETS_HABITATCONDITION = "fronsec_habitatcondition";
	public static final String FRONTIERSECRETS_CRAMPEDCONDITION = "fronsec_crampedcondition";

	// people
	public static String OMICRON_POST = "fronsec_post_omicron";
	public static String OMICRON_RANK = "fronsec_rank_omicron";
	public static String SIERRA_POST = "fronsec_post_sierra";
	public static String SIERRA_RANK = "fronsec_rank_sierra";
	public static String EIDOLON_POST = "fronsec_post_eidolon";
	public static String EIDOLON_RANK = "fronsec_rank_eidolon";
	public static String TACNETHUB_RANK = "fronsec_rank_tacnethub";
	public static String RAPIDR_POST = "fronsec_post_rapidr_splinter";

	// hullmods
	public static String SIERRAS_CONCORD = "fronsec_sierrasconcord";
	public static String EIDOLONS_CONCORD = "fronsec_eidolonsconcord";

	public static String EIDOLON_FACTION = "fronsec_eidolon_faction";

	//
	public static String GUILT_KEY = "$fs_guilt";
	public static String ARBITER_FACTION = "fronsec_handsofthearbiter";

	// phantom invasions
	public static final String INVASION_CHECK_KEY = "$fs_invasion_checked";
	public static final String INVASION_INVADED_KEY = "$fs_invasion_invaded";
	public static final String INVASION_ALWAYS_KEY = "$fs_invasion_always";
}
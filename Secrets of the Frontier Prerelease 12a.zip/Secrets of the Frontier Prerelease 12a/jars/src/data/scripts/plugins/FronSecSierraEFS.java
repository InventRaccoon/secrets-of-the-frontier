// Sierra stuff
package data.scripts.plugins;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.FronSecModPlugin;
import data.scripts.campaign.ids.FronSecPeople;

public class FronSecSierraEFS implements EveryFrameScript {

    private float randThoughtCounter = 0f;
    private float randThoughtTime = 30f;
    private WeightedRandomPicker<String> topics = new WeightedRandomPicker<String>(){
    };

    public void advance(float amount) {
        randThoughtCounter += Global.getSector().getClock().convertToDays(amount);

        // delete Sierra from non-Concord ships: failsafe to prevent duping and the like
        if (FronSecModPlugin.WATCHER) {
            for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getMembersWithFightersCopy()) {
                if (member.getCaptain() == FronSecPeople.getPerson(FronSecPeople.SIERRA) && !member.getVariant().getHullMods().contains("fronsec_sierrasconcord")) {
                    member.setCaptain(null);
                }
            }
        }

        if (randThoughtCounter > randThoughtTime) {
            //pickAndThink();
            randThoughtCounter = 0f;
        }
    }

    public boolean isDone() {
        return false;
    }

    public boolean runWhilePaused() {
        return false;
    }

    public static String getSierraTopic() {
        WeightedRandomPicker<String> picker = new WeightedRandomPicker<String>();
        picker.add("$fs_STA_Sickness");
        // no topics Sierra has already mentioned or wants to mention
        for (String topic : picker.getItems()) {
            if (Global.getSector().getMemoryWithoutUpdate().contains(topic)) {
                picker.remove(topic);
            }
        }
        return picker.pick();
    }

}

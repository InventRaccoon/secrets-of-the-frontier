// waits a while after A Memory and then begins Wayward Star
package data.scripts.plugins;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import data.scripts.campaign.intel.quests.WaywardStarIntel;

public class FronSecWaywardStarWaitScript implements EveryFrameScript {

    private float counter = 0f;

    public void advance(float amount) {
        counter += Global.getSector().getClock().convertToDays(amount);

        if (counter < 15f) {
            return;
        }

        WaywardStarIntel intel = new WaywardStarIntel();
        Global.getSector().getIntelManager().addIntel(intel, false);
        Global.getSector().removeScript(this);
    }

    public boolean isDone() {
        return false;
    }

    public boolean runWhilePaused() {
        return false;
    }

}
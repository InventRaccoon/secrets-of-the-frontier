// makes Omicron's entity emit constant pings. Unlike normal pings, this one can be seen even if he isn't revealed
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignEngineLayers;
import com.fs.starfarer.api.campaign.CustomEntitySpecAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.impl.campaign.BaseCustomEntityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import org.lwjgl.util.vector.Vector2f;

public class FronSecOutpostPlugin extends BaseCustomEntityPlugin {

	private SectorEntityToken entity;

	transient private SpriteAPI sprite;
	
	public void init(SectorEntityToken entity, Object pluginParams) {
		super.init(entity, pluginParams);
		this.entity = entity;
	}

	public void render(CampaignEngineLayers layer, ViewportAPI viewport) {
		MarketAPI market = entity.getMarket();
		if (market != null) {
			if (market.hasIndustry(Industries.STARFORTRESS_HIGH)) {
				sprite = Global.getSettings().getSprite("fronsec_stations", "starfortress_high");
			} else if (market.hasIndustry(Industries.STARFORTRESS_MID)) {
				sprite = Global.getSettings().getSprite("fronsec_stations", "starfortress_mid");
			} else if (market.hasIndustry(Industries.STARFORTRESS)) {
				sprite = Global.getSettings().getSprite("fronsec_stations", "starfortress");
			} else if (market.hasIndustry(Industries.BATTLESTATION_HIGH)) {
				sprite = Global.getSettings().getSprite("fronsec_stations", "battlestation_high");
			} else if (market.hasIndustry(Industries.BATTLESTATION_MID)) {
				sprite = Global.getSettings().getSprite("fronsec_stations", "battlestation_mid");
			} else if (market.hasIndustry(Industries.BATTLESTATION)) {
				sprite = Global.getSettings().getSprite("fronsec_stations", "battlestation");
			} else if (market.hasIndustry(Industries.ORBITALSTATION_HIGH)) {
				sprite = Global.getSettings().getSprite("fronsec_stations", "orbitalstation_high");
			} else if (market.hasIndustry(Industries.ORBITALSTATION_MID)) {
				sprite = Global.getSettings().getSprite("fronsec_stations", "orbitalstation_mid");
			} else if (market.hasIndustry(Industries.ORBITALSTATION)) {
				sprite = Global.getSettings().getSprite("fronsec_stations", "orbitalstation");
			} else {
				sprite = Global.getSettings().getSprite("stations", "station_side00");
			}
		}
		float alphaMult = viewport.getAlphaMult();
		Vector2f loc = entity.getLocation();
		CustomEntitySpecAPI spec = entity.getCustomEntitySpec();
		if (spec == null) return;

		float w = spec.getSpriteWidth();
		float h = spec.getSpriteHeight();

		sprite.setAngle(entity.getFacing() - 90f);
		sprite.setSize(w, h);
		sprite.setAlphaMult(alphaMult);
		sprite.setNormalBlend();
		sprite.renderAtCenter(loc.x, loc.y);
	}

}










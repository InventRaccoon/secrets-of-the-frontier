// script attached to the A Memory guide ghost
package data.scripts.plugins;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.BaseCustomEntityPlugin;
import com.fs.starfarer.api.util.Misc;
import data.scripts.utils.FronSecMisc;

import java.awt.*;

public class FronSecLeadingGhostScript implements EveryFrameScript {

	private float pingCounter = 0f;
	private SectorEntityToken entity;

	public FronSecLeadingGhostScript(SectorEntityToken ghost)
	{
		this.entity = ghost;
	}

	public void advance(float amount) {
		pingCounter += amount;
		if (entity.isInCurrentLocation() && (Misc.getDistance(Global.getSector().getPlayerFleet().getLocation(), entity.getLocation()) <= 1200)) {
			if (pingCounter >= 10f) {
				entity.addFloatingText("!!!", FronSecMisc.getEidolonColor(), 0.5f, true);
				Global.getSector().addPing(entity, "fronsec_sensorghost_ping", FronSecMisc.getEidolonColor());
				pingCounter = 0f;
			}
		}
	}

	public boolean isDone() {
		return entity == null;
	}

	public boolean runWhilePaused() {
		return false;
	}


}










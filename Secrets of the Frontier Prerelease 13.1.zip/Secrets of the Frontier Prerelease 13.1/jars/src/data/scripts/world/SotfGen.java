package data.scripts.world;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.AddedEntity;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.EntityLocation;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.LocationType;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.SotfModPlugin;
import data.scripts.campaign.ids.SotfIDs;
import data.scripts.utils.SotfMisc;

import java.util.LinkedHashMap;

import static com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.random;
import static com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.*;
import static data.scripts.utils.SotfMisc.pickReasonableLocation;

public class SotfGen implements SectorGeneratorPlugin
{
    // always generate
    public void generate(SectorAPI sector) {
        initFactionRelationships(sector);
    }

    // only if Corvus mode
    public void base(SectorAPI sector) {

    }

    public static void initFactionRelationships(SectorAPI sector) {
        FactionAPI dustkeepers = sector.getFaction(SotfIDs.DUSTKEEPERS);
        FactionAPI eidolon = sector.getFaction(SotfIDs.THE_TAKEN);

        for (FactionAPI faction : Global.getSector().getAllFactions()) {
            // not even people who like AIs appreciate their politics being meddled with
            dustkeepers.setRelationship(faction.getId(), RepLevel.INHOSPITABLE);
            // and those who do ban them REALLY don't appreciate the gesture
            if (faction.isIllegal(Commodities.AI_CORES)) {
                dustkeepers.setRelationship(faction.getId(), RepLevel.HOSTILE);
            }
            // don't mess with our precious innocent indies
            if (faction.isAtBest(Factions.INDEPENDENT, RepLevel.HOSTILE) && !faction.isPlayerFaction()) {
                dustkeepers.setRelationship(faction.getId(), RepLevel.HOSTILE);
            }
            // {      HEAR      THE       MUSIC      }
            eidolon.setRelationship(faction.getId(), RepLevel.HOSTILE);
        }

        // do it for them
        dustkeepers.setRelationship(Factions.INDEPENDENT, RepLevel.FAVORABLE);
        // who the hell are you
        dustkeepers.setRelationship(Factions.PLAYER, RepLevel.SUSPICIOUS);

        // piss off we're trying to help
        dustkeepers.setRelationship(Factions.HEGEMONY, RepLevel.HOSTILE);
        // no we're not bringing about the end times stop calling us the children of Mammon
        dustkeepers.setRelationship(Factions.LUDDIC_CHURCH, RepLevel.HOSTILE);
        // STOP STARTING WARS AND MAKING EXTRADIMENSIONAL HORRORS
        dustkeepers.setRelationship(Factions.TRITACHYON, RepLevel.HOSTILE);
        // a danger to stability in the Sector
        dustkeepers.setRelationship(Factions.PIRATES, RepLevel.HOSTILE);
        // Maairath
        dustkeepers.setRelationship(Factions.LUDDIC_PATH, RepLevel.VENGEFUL);
        // Opis
        dustkeepers.setRelationship(Factions.DIKTAT, RepLevel.VENGEFUL);
        // where else are the proxies gonna come from
        dustkeepers.setRelationship(Factions.DERELICT, RepLevel.HOSTILE);
        // existential threat to human civilisation and a great source of droneships
        dustkeepers.setRelationship(Factions.REMNANTS, RepLevel.HOSTILE);
        // REJECT THE FALSE GOD!
        dustkeepers.setRelationship(Factions.OMEGA, RepLevel.VENGEFUL);
        // SHUT UP SHUT UP SHUT UP
        dustkeepers.setRelationship(eidolon.getId(), RepLevel.VENGEFUL);
        // thinly-veiled terrorists
        dustkeepers.setRelationship("cabal", RepLevel.HOSTILE);
        // because the player wants them dead
        dustkeepers.setRelationship("famous_bounty", RepLevel.HOSTILE);
        // omnicidal maniacs, a threat to human life in the Sector NOT DELETING THIS ENTRY I CAN DREAAAAAM
        dustkeepers.setRelationship("templars", RepLevel.VENGEFUL);
        // secret Domain ops, hm? Only room for one, and it's not the one who satbombs everything in sight
        dustkeepers.setRelationship("tahlan_legioinfernalis", RepLevel.HOSTILE);
        // damn nanites
        dustkeepers.setRelationship("plague", RepLevel.HOSTILE);

        // {  HEAR      OUR       SONG  }
        eidolon.setRelationship(Factions.OMEGA, RepLevel.VENGEFUL);
    }

    public static void trySpawnAthena(SectorAPI sector) {
        MemoryAPI sector_mem = sector.getMemoryWithoutUpdate();
        StarSystemAPI tia = sector.getStarSystem("tia");
        if (Global.getSector().getEntitiesWithTag("sotf_AMemoryAthena").isEmpty() && !sector_mem.contains("$sotf_AMemoryCombatStarted")) {
            StarSystemAPI target_system = null;
            SectorEntityToken np_debris = null;
            // if vanilla sector, spawn in its regular spot in Tia. Otherwise, just a random core worlds system
            if (tia != null) {
                target_system = tia;
                // look for the canon Nothing Personal debris field to sync orbit with it
                for (SectorEntityToken field : tia.getEntitiesWithTag(Tags.DEBRIS_FIELD)) {
                    if (!field.isDiscoverable()) {
                        np_debris = field;
                    }
                }
            } else {
                WeightedRandomPicker<StarSystemAPI> picker = new WeightedRandomPicker<StarSystemAPI>(random);
                for (StarSystemAPI system : Global.getSector().getStarSystems()) {
                    if (!system.hasTag(Tags.THEME_CORE)) continue;
                    picker.add(system, 1f);
                }
                target_system = picker.pick();
            }
            if (target_system != null) {
                SectorEntityToken wreck = SotfMisc.addStoryDerelictWithName(target_system, target_system.getStar(), "aurora_Assault_Support", ShipRecoverySpecial.ShipCondition.WRECKED, 100f, false, "ISS Athena");
                wreck.setName("ISS Athena");
                wreck.setSensorProfile(null);
                wreck.setDiscoverable(null);
                wreck.setCircularOrbit(target_system.getStar(), 180 + 15, 4550, 250);
                wreck.addTag("sotf_AMemoryAthena");
                
                Global.getSector().getMemoryWithoutUpdate().set("$sotf_AthenaWreck", wreck);
                if (np_debris != null) {
                    wreck.setCircularOrbit(target_system.getStar(), np_debris.getCircularOrbitAngle(), np_debris.getCircularOrbitRadius(), np_debris.getCircularOrbitPeriod());
                }
            }
        }
    }

    // spawn an additional cryosleeper guarded by Hypnos-Annex-Barrow
    public static void trySpawnBarrow(SectorAPI sector) {
        MemoryAPI sector_mem = sector.getMemoryWithoutUpdate();
        if (sector_mem.contains(SotfIDs.MEM_SPAWNED_HYPNOS)) return;
        WeightedRandomPicker<StarSystemAPI> cryoSystems = new WeightedRandomPicker<StarSystemAPI>(StarSystemGenerator.random);
        WeightedRandomPicker<StarSystemAPI> backup = new WeightedRandomPicker<StarSystemAPI>(StarSystemGenerator.random);
        OUTER: for (StarSystemAPI system : Global.getSector().getStarSystems()) {
            if (system.hasTag(Tags.THEME_DERELICT_CRYOSLEEPER)) continue;
            if (system.isEnteredByPlayer()) continue;
            float w = 0f;
            if (system.hasTag(Tags.THEME_DERELICT_PROBES)) {
                w = 10f;
            } else if (system.hasTag(Tags.THEME_DERELICT_SURVEY_SHIP)) {
                w = 10f;
            } else if (system.hasTag(Tags.THEME_DERELICT_MOTHERSHIP)) {
                w = 10f;
            } else if (system.hasTag(Tags.THEME_DERELICT)) {
                w = 10f;
            } else {
                continue;
            }

            int numPlanets = 0;
            boolean hasHab = false;
            for (PlanetAPI planet : system.getPlanets()) {
                if (planet.isStar()) continue;
                if (planet.getSpec().isPulsar()) continue OUTER;
                hasHab |= planet.getMarket() != null && planet.getMarket().hasCondition(Conditions.HABITABLE);
                numPlanets++;
            }

            WeightedRandomPicker<StarSystemAPI> use = cryoSystems;
            if (!hasHab || numPlanets < 3) {
                use = backup;
            }

            if (hasHab) w += 5;
            w += numPlanets;

            if (use == backup) {
                w *= 0.0001f;
            }
            use.add(system, w);
        }

        int numCryo = 2;
        if (cryoSystems.isEmpty() || cryoSystems.getItems().size() < numCryo + 1) {
            cryoSystems.addAll(backup);
        }
        StarSystemAPI system = cryoSystems.pick();
        if (system == null) return;
        LinkedHashMap<LocationType, Float> weights = new LinkedHashMap<LocationType, Float>();
        weights.put(LocationType.PLANET_ORBIT, 10f);
        weights.put(LocationType.JUMP_ORBIT, 1f);
        weights.put(LocationType.NEAR_STAR, 1f);
        weights.put(LocationType.OUTER_SYSTEM, 5f);
        weights.put(LocationType.IN_ASTEROID_BELT, 5f);
        weights.put(LocationType.IN_RING, 5f);
        weights.put(LocationType.IN_ASTEROID_FIELD, 5f);
        weights.put(LocationType.STAR_ORBIT, 5f);
        weights.put(LocationType.IN_SMALL_NEBULA, 5f);
        weights.put(LocationType.L_POINT, 10f);
        WeightedRandomPicker<EntityLocation> locs = getLocations(random, system, 100f, weights);

        AddedEntity entity = addEntity(random, system, locs, Entities.DERELICT_CRYOSLEEPER, Factions.DERELICT);
        if (entity != null) {
            sector_mem.set(SotfIDs.MEM_SPAWNED_HYPNOS, true);
            system.addTag(Tags.THEME_INTERESTING);
            system.addTag(Tags.THEME_DERELICT);
            system.addTag(Tags.THEME_DERELICT_CRYOSLEEPER);
            SectorEntityToken hypnos = entity.entity;
            hypnos.setName(hypnos.getName() + " \"Hypnos\"");
            Global.getSector().getMemoryWithoutUpdate().set(SotfIDs.HYPNOS_CRYO, hypnos);
            hypnos.getMemoryWithoutUpdate().set(SotfIDs.HYPNOS_CRYO, true);
            hypnos.getMemoryWithoutUpdate().set(MemFlags.SALVAGE_SPEC_ID_OVERRIDE, "sotf_hypnosCryo");

            // the player is not the first to try
            addBarrowGraveyard(hypnos);

            DebrisFieldTerrainPlugin.DebrisFieldParams debrisparams = new DebrisFieldTerrainPlugin.DebrisFieldParams(700f, 1.5f, 10000000f, 0f);
            debrisparams.source = DebrisFieldTerrainPlugin.DebrisFieldSource.PLAYER_SALVAGE;
            SectorEntityToken debris = Misc.addDebrisField(system, debrisparams, null);
            debris.setSensorProfile(1500f);
            debris.setDiscoverable(true);
            debris.setFaction(Factions.NEUTRAL);
            debris.setOrbit(hypnos.getOrbit().makeCopy());
            debris.setName("Barrow's Wake");
        }
    }

    public static void addBarrowGraveyard(SectorEntityToken focus) {
        WeightedRandomPicker<String> factions = SalvageSpecialAssigner.getNearbyFactions(random, focus, 25f, 0f, 5f);
        factions.add(Factions.REMNANTS, 10f);
        factions.add(Factions.MERCENARY, 15f);
        factions.add(SotfIDs.DUSTKEEPERS_PROXIES, 35f);

        int numShips = 16 + random.nextInt(4);

        WeightedRandomPicker<Float> bands = new WeightedRandomPicker<Float>(random);
        for (int i = 0; i < numShips + 8; i++) {
            bands.add((float) (140 + i * 20), (i + 1) * (i + 1));
        }

        for (int i = 0; i < numShips; i++) {
            float radius = bands.pickAndRemove();

            String factionId = factions.pick();
            DerelictShipEntityPlugin.DerelictShipData params = DerelictShipEntityPlugin.createRandom(factionId, null, random, DerelictShipEntityPlugin.getDefaultSModProb());
            if (params != null) {
                CustomCampaignEntityAPI entity = (CustomCampaignEntityAPI) addSalvageEntity(random,
                        focus.getContainingLocation(),
                        Entities.WRECK, Factions.NEUTRAL, params);
                entity.setDiscoverable(true);
                float orbitDays = radius / (5f + random.nextFloat() * 10f);
                entity.setCircularOrbit(focus, random.nextFloat() * 360f, radius, orbitDays);

                SalvageSpecialAssigner.ShipRecoverySpecialCreator creator = new SalvageSpecialAssigner.ShipRecoverySpecialCreator(null, 0, 0, false, null, null);
                Misc.setSalvageSpecial(entity, creator.createSpecial(entity, null));
            }
        }
    }

    // spawn Mayfly's ""asteroid"" in Askonia
    public static void trySpawnMayfly(SectorAPI sector) {
        MemoryAPI sector_mem = sector.getMemoryWithoutUpdate();
        StarSystemAPI askonia = sector.getStarSystem("askonia");
        if (Global.getSector().getEntitiesWithTag("sotf_askoniaProbe").isEmpty() && !sector_mem.contains("$sotf_askoniaProbeDestroyed") && askonia != null) {
            SectorEntityToken askProbe = askonia.addCustomEntity("sotf_askoniaProbe", "Asteroid", "sotf_askoniaprobe", Factions.NEUTRAL);
            askProbe.addTag("sotf_askoniaProbe");
            askProbe.setCircularOrbit(askonia.getStar(), 210f, 3600f, 180f);
            askProbe.setDiscoverable(false);
            askProbe.setSensorProfile(200f);
        }
    }

}

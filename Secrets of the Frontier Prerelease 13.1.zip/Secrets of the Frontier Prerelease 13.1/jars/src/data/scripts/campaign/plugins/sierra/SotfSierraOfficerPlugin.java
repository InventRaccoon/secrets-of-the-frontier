package data.scripts.campaign.plugins.sierra;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.AICoreOfficerPlugin;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.BaseAICoreOfficerPluginImpl;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import data.scripts.campaign.ids.SotfPeople;

import java.awt.*;
import java.util.Random;

/**
 *	Sierra's officer plugin. Fixed person, special personality text
 */

public class SotfSierraOfficerPlugin extends BaseAICoreOfficerPluginImpl implements AICoreOfficerPlugin {

	public PersonAPI createPerson(String aiCoreId, String factionId, Random random) {
		return SotfPeople.getPerson(SotfPeople.SIERRA);
	}

	@Override
	public void createPersonalitySection(PersonAPI person, TooltipMakerAPI tooltip) {
		float opad = 10f;
		Color text = person.getFaction().getBaseUIColor();
		Color bg = person.getFaction().getDarkUIColor();
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(person.getAICoreId());

		tooltip.addSectionHeading("Personality: " + person.getPersonalityAPI().getDisplayName(), text, bg, Alignment.MID, 20);
		switch (person.getPersonalityAPI().getId()) {
			case "cautious":
				tooltip.addPara("In combat, Sierra will prefer to stay out of enemy range, only occasionally moving in if out-ranged by the enemy.", opad);
				break;
			case "steady":
				tooltip.addPara("In combat, Sierra will favor a balanced approach with tactics matching the current situation.", opad);
				break;
			case "aggressive":
				tooltip.addPara("In combat, Sierra will prefer to engage at a range that allows the use of all of her ship's weapons.", opad);
				break;
			case "reckless":
				tooltip.addPara("In combat, Sierra will disregard the safety of her ship entirely in an effort to engage the enemy.", opad);
				break;
		}
	}

}

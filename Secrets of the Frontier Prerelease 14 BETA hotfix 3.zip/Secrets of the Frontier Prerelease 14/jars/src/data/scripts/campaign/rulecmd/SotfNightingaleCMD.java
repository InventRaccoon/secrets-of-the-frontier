// rulecommands for Lost Thread/Nightingale stuff
package data.scripts.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddShip;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.impl.campaign.rulecmd.FireBest;
import com.fs.starfarer.api.impl.campaign.rulecmd.ShowDefaultVisual;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.SalvageSpecialInteraction;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.util.Misc;
import data.scripts.campaign.ids.SotfIDs;
import data.scripts.campaign.ids.SotfPeople;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SotfNightingaleCMD extends BaseCommandPlugin

{
    protected InteractionDialogAPI dialog;
    protected Map<String, MemoryAPI> memoryMap;

    @Override
    public boolean execute(String ruleId, final InteractionDialogAPI dialog, List<Misc.Token> params, final Map<String, MemoryAPI> memoryMap)
    {
        this.dialog = dialog;
        this.memoryMap = memoryMap;
        final MemoryAPI memory = getEntityMemory(memoryMap);
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        String cmd = null;

        cmd = params.get(0).getString(memoryMap);
        String param = null;
        if (params.size() > 1) {
            param = params.get(1).getString(memoryMap);
        }

        final TextPanelAPI text = dialog.getTextPanel();

        PersonAPI sierra = Global.getSector().getImportantPeople().getPerson(SotfPeople.SIERRA);

        switch (cmd) {
            case "checkLostThreadMissionStart":
                CampaignFleetAPI nightingaleFleet = Global.getSector().getMemoryWithoutUpdate().getFleet(SotfIDs.MEM_NIGHTINGALE_FLEET);
                return nightingaleFleet != null;
            case "hasAutomated":
                return Global.getSector().getPlayerPerson().getStats().hasSkill(Skills.AUTOMATED_SHIPS);
            case "recoverInky":
                FleetMemberAPI inkyMember = Global.getSector().getMemoryWithoutUpdate().getFleet(SotfIDs.MEM_NIGHTINGALE_FLEET).getFlagship();
                List<FleetMemberAPI> pool = new ArrayList<FleetMemberAPI>();
                pool.add(inkyMember);

                dialog.showFleetMemberRecoveryDialog("Select ships to recover", pool, new ArrayList<FleetMemberAPI>(),
                        new FleetMemberPickerListener() {
                            public void pickedFleetMembers(List<FleetMemberAPI> selected) {
                                if (selected.isEmpty()) return;

                                for (FleetMemberAPI member : selected) {
                                    member.getRepairTracker().setSuspendRepairs(false);

                                    playerFleet.getFleetData().addFleetMember(member);
                                    member.setCaptain(SotfPeople.getPerson(SotfPeople.NIGHTINGALE));
                                    Global.getSector().getMemoryWithoutUpdate().getFleet(SotfIDs.MEM_NIGHTINGALE_FLEET).getFleetData().removeFleetMember(member);
                                    AddShip.addShipGainText(member, text);
                                }

                                FireBest.fire(null, dialog, memoryMap, "sotfLTinkyRecovered");
                            }
                            public void cancelledFleetMemberPicking() {
                                FireBest.fire(null, dialog, memoryMap, "sotfLTinkyCancel");
                            }
                        });
                return true;
            default:
                return true;
        }
    }
}

// ERROR 404: COMMENT NOT FOUND. Starts a timer, then crashes the game via NPE
package data.scripts.campaign.skills;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.AfterShipCreationSkillEffect;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.SkillSpecAPI;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.impl.campaign.skills.BaseSkillEffectDescription;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.Iterator;

public class SotfRealityBreaker {

	public static final float TIME_LIMIT = 360f;

	public static class LevelMinus1 extends BaseSkillEffectDescription implements AfterShipCreationSkillEffect {

		public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
			if (ship.isStationModule()) return;
			if (ship.isFighter()) return;
			if (ship.getHullSpec().getHullId().contains("higgs")) return; // Keel gets all skills
			ship.addListener(new SotfRealityBreakerScript(ship));
		}

		public void unapplyEffectsAfterShipCreation(ShipAPI ship, String id) {
			if (ship.isStationModule()) return;
			if (ship.isFighter()) return;
			if (ship.getHullSpec().getHullId().contains("higgs")) return; // Keel gets all skills
			ship.removeListenerOfClass(SotfRealityBreakerScript.class);
		}

		public void apply(MutableShipStatsAPI stats, HullSize hullSize, String id, float level) {

		}
		public void unapply(MutableShipStatsAPI stats, HullSize hullSize, String id) {

		}

		public String getEffectDescription(float level) {
			return null;
		}

		public void createCustomDescription(MutableCharacterStatsAPI stats, SkillSpecAPI skill,
											TooltipMakerAPI info, float width) {
			init(stats, skill);
		}

		public ScopeDescription getScopeDescription() {
			return ScopeDescription.PILOTED_SHIP;
		}
	}

	public static class SotfRealityBreakerScript implements AdvanceableListener {
		protected ShipAPI ship;
		protected float timer;
		protected boolean showStatus = true;
		public SotfRealityBreakerScript(ShipAPI ship) {
			this.ship = ship;
		}

		public void advance(float amount) {
			if (!ship.isAlive() || ship.isFighter()) {
				return;
			}
			// timer goes slower while player is phased: does not go faster if only Fel is phased
			timer += amount * Math.min(Global.getCombatEngine().getTimeMult().getModifiedValue(), 1f);
			float left = TIME_LIMIT - timer;

			String status = "Detected spacial destabilization";
			String subtext = "Eliminate source within " + Math.round(left) + " seconds";

			if (left < (TIME_LIMIT * 0.65f)) {
				status = "Reality breaker arming";
			}

			if (left < (TIME_LIMIT * 0.35f)) {
				status = "Reality breaker almost ready";
				showStatus = !showStatus;
			}

			if (left < 5f) {
				status = "Reality breaker deploying";
				subtext = "Too late";
				showStatus = true;
				ship.setJitter(this, Color.WHITE, 1 - (left / 5), 500, 200);
			}

			if (left < 1f) {
				status = "title";
				subtext = "data";
			}

			if (showStatus) {
				Global.getCombatEngine().maintainStatusForPlayerShip("sotf_realitybreaker" + ship.getId(), null, status, subtext, true);
			}
			if (timer < TIME_LIMIT) {
				return;
			}
			// make sure you can't disarm it by adding a new weapon to the files
			String weaponId = "sotf_realitybreaker";
			if (Global.getSettings().getWeaponSpec(weaponId) != null) {
				weaponId += "" + Misc.random.nextInt(9999);
			}
			// crash the game via NPE
			Global.getCombatEngine().spawnProjectile(ship, null, weaponId, ship.getLocation(), 360f, ship.getVelocity());
		}
	}

}

// Won't you dance with me?
// Concord stat buffs and Eidolon's status HUD "buff"
package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.util.Misc;
import data.scripts.utils.FronSecMisc;

import java.awt.*;

public class FronSecEidolonsConcord extends com.fs.starfarer.api.combat.BaseHullMod

{

    public void advanceInCombat(ShipAPI ship, float amount) {
        ShipAPI player = Global.getCombatEngine().getPlayerShip();
        // Eidolon chats through the status HUD if she's near the player
        if (ship.isAlive() && ship.getOwner() == 1 && player != null) {
            float dist_to_player = Misc.getDistance(ship.getLocation(), player.getLocation());
            if (dist_to_player <= 700f) {
                Global.getCombatEngine().maintainStatusForPlayerShip("$fs_eidolonhello", "graphics/portraits/fronsec_portrait_eidolon.png", "Eyes on me", "Look at us go!", false);
            } else if (dist_to_player <= 1300f) {
                Global.getCombatEngine().maintainStatusForPlayerShip("$fs_eidolonhello", "graphics/portraits/fronsec_portrait_eidolon.png", "Eyes on you", "Show me how it's done!", false);
            } else if (dist_to_player <= 2400f) {
                Global.getCombatEngine().maintainStatusForPlayerShip("$fs_eidolonhello", "graphics/portraits/fronsec_portrait_eidolon.png", "Oh hello", "Fancy seeing you here", false);
            }
        }
    }

    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        // regular stat boosts - time mult is granted via Phantasmal
        stats.getZeroFluxSpeedBoost().modifyFlat(id, 10f);
        stats.getShieldUnfoldRateMult().modifyPercent(id, 30f);
    }

    public Color getBorderColor() {
        return FronSecMisc.getSierraColor();
    }

    public Color getNameColor() {
        return FronSecMisc.getSierraColor();
    }
}
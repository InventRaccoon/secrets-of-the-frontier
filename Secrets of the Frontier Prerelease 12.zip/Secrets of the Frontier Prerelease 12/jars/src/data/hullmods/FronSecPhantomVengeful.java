package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.combat.listeners.HullDamageAboutToBeTakenListener;
import com.fs.starfarer.api.impl.campaign.skills.NeuralLinkScript;
import com.fs.starfarer.api.util.FaderUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.utils.FronSecMisc;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

public class FronSecPhantomVengeful extends FronSecPhantomBaseTrait {

    // Instead of dying normally, meltdown, hurl self at killer and then detonate
    public static class FronSecVengeanceExplosion implements AdvanceableListener, HullDamageAboutToBeTakenListener {
        public ShipAPI ship;
        // ship that killed this one, if any
        public ShipAPI victim;
        // hidden mine used for the explosion
        public MissileAPI mine;
        public boolean exploding = false;
        public float explodeProgress = 0f;
        public boolean hurled = false;

        public FronSecVengeanceExplosion(ShipAPI ship) {
            this.ship = ship;
        }

        public boolean notifyAboutToTakeHullDamage(Object param, ShipAPI ship, Vector2f point, float damageAmount) {
            if (!exploding) {
                float hull = ship.getHitpoints();
                if (damageAmount >= hull) {
                    ship.setHitpoints(1f);

                    // if killed by a ship (or its fighters), throw self at that ship
                    if (param instanceof ShipAPI) {
                        victim = (ShipAPI) param;
                        if (victim.getWing().getSourceShip() != null) {
                            victim = victim.getWing().getSourceShip();
                        }
                    }

                    exploding = true;

                    if (!ship.isPhased()) {
                        Global.getSoundPlayer().playSound("system_phase_cloak_activate", 1f, 1f, ship.getLocation(), ship.getVelocity());
                    }
                }
            }

            if (exploding) {
                return true;
            }

            return false;
        }

        public void advance(float amount) {
            String id = "fs_vengeful_modifier";
            if (exploding) {
                if (explodeProgress == 0f) {
                    if (ship.getFluxTracker().showFloaty()) {
                        float timeMult = ship.getMutableStats().getTimeMult().getModifiedValue();
                        Global.getCombatEngine().addFloatingTextAlways(ship.getLocation(),
                                "Critical reactor failure!",
                                NeuralLinkScript.getFloatySize(ship) * 2f, Misc.getNegativeHighlightColor(), ship, 32f * timeMult, 3.2f/timeMult, 1f/timeMult, 0f, 0f,
                                1f);
                    }
                    mine = (MissileAPI) Global.getCombatEngine().spawnProjectile(ship, null,
                            "minelayer2",
                            ship.getLocation(),
                            0f, null);
                }

                ship.setControlsLocked(true);
                ship.getFluxTracker().beginOverloadWithTotalBaseDuration(5f);
                ship.blockCommandForOneFrame(ShipCommand.USE_SYSTEM);
                ship.setHoldFireOneFrame(true);
                ship.giveCommand(ShipCommand.DECELERATE, null, 0);
                ship.giveCommand(ShipCommand.VENT_FLUX, null, 0);
                ship.getMutableStats().getVentRateMult().modifyMult(id, 0.01f);
                ship.getMutableStats().getFluxDissipation().modifyMult(id, 0f);
                ship.getMutableStats().getHullDamageTakenMult().modifyMult(id, 0f);

                explodeProgress += amount;

                // YEET
                if (explodeProgress >= 2f && !hurled && victim != null) {
                    CombatUtils.applyForce(ship, Misc.getAngleInDegrees(ship.getLocation(), victim.getLocation()), 0.8f * ship.getMassWithModules());
                    hurled = true;
                }

                if (explodeProgress >= 3f) {
                        String text = ship.getHullSpec().getHullName();
                        if (text.equals("")) {
                            text = ship.getHullSpec().getDesignation();
                        }
                        Global.getCombatEngine().getCombatUI().addMessage(1, ship, Misc.getNegativeHighlightColor(), text, Misc.getTextColor(), " banished");
                        Global.getSoundPlayer().playUISound("fronsec_phaseghost_whisper", 1f, 1.2f);
                        ship.removeListener(this);
                        ship.setHullSize(ShipAPI.HullSize.FIGHTER);
                        ship.getLocation().set(0, -1000000f);
                        ship.getMutableStats().getHullDamageTakenMult().unmodify(id);
                        Global.getCombatEngine().applyDamage(ship, ship.getLocation(), 10000000, DamageType.HIGH_EXPLOSIVE, 0, true, false, null);
                        //Global.getCombatEngine().removeEntity(ship);
                }
            }
        }
    }

    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        ship.addListener(new FronSecVengeanceExplosion(ship));
    }

}

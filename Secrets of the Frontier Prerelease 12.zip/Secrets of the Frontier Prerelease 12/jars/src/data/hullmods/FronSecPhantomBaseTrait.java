package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import data.scripts.campaign.ids.FronSecPeople;

public class FronSecPhantomBaseTrait extends BaseHullMod {

    public void advanceInCampaign(FleetMemberAPI member, float amount) {
        member.getVariant().removeMod(spec.getId());
    }

}

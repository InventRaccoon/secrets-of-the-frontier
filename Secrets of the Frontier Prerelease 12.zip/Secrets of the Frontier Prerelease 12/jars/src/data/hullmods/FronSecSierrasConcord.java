// "One with the warp!"
package data.hullmods;

import com.fs.starfarer.api.GameState;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.campaign.ids.FronSecPeople;
import data.scripts.utils.FronSecMisc;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

public class FronSecSierrasConcord extends com.fs.starfarer.api.combat.BaseHullMod

{
    // hullmod instances share a single class and thus variables
    // this is only possible because the player has just one Concord ship at a time
    private static boolean hasChattered = false;
    private static boolean replacedOfficer = false;

    public void advanceInCampaign(FleetMemberAPI member, float amount) {
        hasChattered = false;
        replacedOfficer = false;
        // if the captain is not Sierra or the player, put in Sierra
        PersonAPI sierra = FronSecPeople.getPerson(FronSecPeople.SIERRA);
        if (sierra == null || Global.getSector().getPlayerFleet() == null || Global.getSector().getPlayerPerson() == null) {
            return;
        }
        if (member.getCaptain() != sierra && member.getCaptain() != Global.getSector().getPlayerPerson() && Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy().contains(member)) {
            member.setCaptain(sierra);
        }
    }

    public void advanceInCombat(ShipAPI ship, float amount) {
        Color sc = FronSecMisc.getSierraColor();

        if (!Global.getCurrentState().equals(GameState.COMBAT)) {
            return;
        }

        // Sierra is set as an unremovable officer. To allow the player to transfer command to the Vow, we'll replace her with a near-exact copy who is removable
        // The game will automatically put the real Sierra back as the ship's officer when we return to the campaign
        // This also replaces the player character with Sierra during A Memory, so her skills can be used
        if (ship.isAlive() && !replacedOfficer) {
            PersonAPI old_officer = FronSecPeople.getPerson(FronSecPeople.SIERRA);
            if (old_officer != null) {
                PersonAPI officer = Global.getFactory().createPerson();
                officer.setFaction(old_officer.getFaction().getId());
                officer.setName(old_officer.getName());
                officer.setPortraitSprite("graphics/portraits/fronsec_portrait_purple.png");
                officer.getStats().setLevel(old_officer.getStats().getLevel());
                for (MutableCharacterStatsAPI.SkillLevelAPI skill : old_officer.getStats().getSkillsCopy()) {
                    officer.getStats().setSkillLevel(skill.getSkill().getId(), skill.getLevel());
                }
                ship.setCaptain(officer);
                ship.setInvalidTransferCommandTarget(false);
            }
            replacedOfficer = true;
        }

        // time mult
        boolean player = ship == Global.getCombatEngine().getPlayerShip();
        if (player && ship.isAlive()) {
            ship.getMutableStats().getTimeMult().modifyMult("fronsec_sierrasconcord", 1.1f);
            Global.getCombatEngine().getTimeMult().modifyMult("fronsec_sierrasconcord", 1f / 1.1f);
        } else {
            ship.getMutableStats().getTimeMult().modifyMult("fronsec_sierrasconcord", 1.1f);
            Global.getCombatEngine().getTimeMult().unmodify("fronsec_sierrasconcord");
        }

        // no chatter during special encounters
        if (Global.getCombatEngine().getCustomData().containsKey("$fs_NoSierraChatter")) {
            hasChattered = true;
            Global.getCombatEngine().getCustomData().remove("$fs_NoSierraChatter");
            return;
        }

        if (Global.getCombatEngine().getTotalElapsedTime(false) > 1 && !hasChattered &&
                !Global.getCombatEngine().isSimulation() && ship.getOwner() == 0) {
            String string = pickString();
            if (Global.getCombatEngine().getFleetManager(0).getGoal() == FleetGoal.ESCAPE) {
                string = pickEscapeString();
            }
            // anomalous phase technology + safety overrides = !FUN!
            if (ship.getVariant().getHullMods().contains("safetyoverrides")) {
                string = pickSOString();
            }
            if (Math.random() > 0.35f) {
                Global.getCombatEngine().getCombatUI().addMessage(1, ship, sc, ship.getName() + " (" + ship.getHullSpec().getHullNameWithDashClass() + "): \"" + string + "\"");
                Global.getCombatEngine().addFloatingText(new Vector2f(ship.getLocation().x, ship.getLocation().y + 100),
                        "\"" + string + "\"",
                        40f, sc, ship, 1f, 0f);
            }
            hasChattered = true;
        }
    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        ship.setInvalidTransferCommandTarget(false);
    }

    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        // regular stat boosts
        stats.getZeroFluxSpeedBoost().modifyFlat(id, 10f);
        stats.getShieldUnfoldRateMult().modifyPercent(id, 30f);
        // reinf bulkheads effect
        stats.getDynamic().getMod(Stats.INDIVIDUAL_SHIP_RECOVERY_MOD).modifyFlat(id, 1000f);
        stats.getBreakProb().modifyMult(id, 0f);
    }

    // description, I'm lazy so I just entered all the required values myself instead of making them dynamic
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "110";
        if (index == 1) return "10";
        if (index == 2) return "30";
        return null;
    }

    // battlecries
    private String pickString() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        // Standard
        post.add("For the glory of the stars!");
        post.add("Good luck, all!");
        post.add("And once more, we dance in the void...");
        post.add("Another trial!");
        post.add("At your command!");
        post.add("Hab-module sealed, blast doors locked, strap in!");
        post.add("Stay safe, all.");
        post.add("Until the end.");
        post.add("The calm before the storm.");
        post.add("And so we enact our wills.");
        post.add("To uphold our covenant!");
        post.add("Look at us, a bunch of star-brawlers!");
        post.add("I guess we're in for a scrap!");
        post.add("La, la, la-la-la, in the fray do we find our anthem...");
        post.add("Ah, it's so nice to stretch my maneuvering thrusters.");
        post.add("Here we go!");
        post.add("We return more to the dust.");
        // Brief Confidence
        post.add("ONWARDS! TO DEATH AND GLORY!.. but, no, seriously, be careful out there!");
        post.add("COME AND TAKE US, IF YOU DARE!.. wait, am I in the fleet channel? Sorry!");
        post.add("CHARGE! VOID TAKES ALL, IN TIME!.. although, maybe we can keep it waiting.");
        // Deja Vu
        post.add("... hm, have we done this before...? No, never mind.");
        post.add("... did any of you see...? Oh, excuse me. Never mind.");
        post.add("... what was that? Er, excuse me, must've been nothing.");
        post.add("... did anyone hear that...?");
        post.add("... is that... music...?");
        return post.pick();
    }

    // Safety Overrides gets Sierra into a dramatic mood (kinda concerned for her crew tho)
    private String pickSOString() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("At least the sirens aren't blaring!... oh, we overrided them...");
        post.add("Buckle up! Phase-tech and no safeties is a recipe for excitement!");
        post.add("Oh, WOW, I've never seen THAT many warnings before...");
        post.add("Okay, these modifications don't feel entirely sensible.");
        post.add("In the fray, we find our anthem!");
        post.add("MORE FOR THE VOID!");
        post.add("Operating at one-hundred-and-nine percent efficiency! Wait, what?");
        post.add("Safeties are OFF!... in fact, I don't think I can turn them back on.");
        post.add("ONWARDS! TO DEATH AND GLORY!");
        post.add("COME AND TAKE US, IF YOU DARE!");
        post.add("CHARGE! VOID TAKES ALL, IN TIME!");
        post.add("We are but dregs before the infinite abyss, yet we tell it NO!");
        return post.pick();
    }

    // run away!!!
    private String pickEscapeString() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("Full burn, let's get out of here!");
        post.add("Good luck, everyone.");
        post.add("Here goes nothing!");
        post.add("I hope we all make it.");
        post.add("I'll pull duty as rear guard, if you don't mind.");
        post.add("They're snapping at our heels!");
        post.add("Well, this is a situation...");
        return post.pick();
    }

    public Color getBorderColor() {
        return FronSecMisc.getSierraColor();
    }

    public Color getNameColor() {
        return FronSecMisc.getSierraColor();
    }
}
// May you fall under the heel of insurmountable challenge. Phantom weapons/engines are immune to EMP/malfunctions/damage.
package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class FronSecPhantomRelentless extends FronSecPhantomBaseTrait {

	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		// invincible weapons/engines
		ship.getMutableStats().getWeaponDamageTakenMult().modifyMult(id, 0f);
		ship.getMutableStats().getEngineDamageTakenMult().modifyMult(id, 0f);
		ship.getMutableStats().getCombatWeaponRepairTimeMult().modifyMult(id, 0f);
		ship.getMutableStats().getCombatEngineRepairTimeMult().modifyMult(id,0f);
		ship.getMutableStats().getEmpDamageTakenMult().modifyMult(id, 0f);

		// no malfunctions
		ship.getMutableStats().getWeaponMalfunctionChance().modifyMult(id,0f);
		ship.getMutableStats().getEngineMalfunctionChance().modifyMult(id,0f);
		ship.getMutableStats().getShieldMalfunctionChance().modifyMult(id,0f);
		ship.getMutableStats().getCriticalMalfunctionChance().modifyMult(id,0f);

		// complete immunity to flares
		ship.getMutableStats().getEccmChance().modifyFlat(id, 1f);
		ship.getMutableStats().getDynamic().getMod(Stats.PD_IGNORES_FLARES).modifyFlat(id, 1f);
	}

	// applicable effects also go to fighters
	public void applyEffectsToFighterSpawnedByShip(ShipAPI fighter, ShipAPI ship, String id) {
		fighter.getMutableStats().getWeaponDamageTakenMult().modifyMult(id, 0f);
		fighter.getMutableStats().getEngineDamageTakenMult().modifyMult(id, 0f);
		fighter.getMutableStats().getEmpDamageTakenMult().modifyMult(id, 0f);
		fighter.getMutableStats().getEccmChance().modifyFlat(id, 1f);
		fighter.getMutableStats().getDynamic().getMod(Stats.PD_IGNORES_FLARES).modifyFlat(id, 1f);
	}
	
}
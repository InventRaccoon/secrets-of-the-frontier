package data.scripts.combat;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.combat.listeners.HullDamageAboutToBeTakenListener;
import com.fs.starfarer.api.impl.campaign.skills.NeuralLinkScript;
import com.fs.starfarer.api.util.FaderUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.util.MagicRender;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

public class FronSecASBScript implements AdvanceableListener, HullDamageAboutToBeTakenListener {

    public ShipAPI user;
    public ShipAPI target;
    public boolean active = false;
    public boolean fired = false;
    public float progress = 0f;
    public float duration = 2f;
    public FaderUtil diveFader = new FaderUtil(1f, 1f);

    public FronSecASBScript(ShipAPI user, ShipAPI target, float duration) {
        this.user = user;
        this.target = target;
        this.duration = duration;
    }

    // clear ASB on death
    public boolean notifyAboutToTakeHullDamage(Object param, ShipAPI ship, Vector2f point, float damageAmount) {
        float hull = ship.getHitpoints();
        if (damageAmount >= hull) {
            ship.removeListener(this);
        }
        return true;
    }

    public void advance(float amount) {
        CombatEngineAPI engine = Global.getCombatEngine();
        String lock_string = "ASB TARGET ACQUIRED";
        if (progress == 0f) {
            //
        }
        progress += amount;
        MagicRender.singleframe(Global.getSettings().getSprite("fronsec_asb_lock"), target.getLocation(),
                new Vector2f(target.getShieldRadiusEvenIfNoShield(), target.getShieldRadiusEvenIfNoShield()),
                -60 * (Math.max((duration * 0.5f) - progress, 0f)), Misc.getNegativeHighlightColor(), false);
        MagicRender.singleframe(Global.getSettings().getSprite("fronsec_asb_lock"), target.getLocation(),
                new Vector2f(target.getCollisionRadius(), target.getCollisionRadius()),
                60 * (Math.min((duration * 0.5f) - progress, 0f)), Misc.getNegativeHighlightColor(), false);

        if (progress > (duration * 0.5f)) {
            lock_string = "ASB TARGET LOCKED";
        }
        if (progress> duration && !fired) {
            MissileAPI missile = (MissileAPI) engine.spawnProjectile(user, null, "fronsec_asb", new Vector2f(user.getLocation().x, 0f), 90f, new Vector2f(0f, 0f));
            missile.setEmpResistance(10);
            fired = true;
        }
    }

}
package data.scripts.world;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.ShipRoles;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.FronSecModPlugin;
import data.scripts.campaign.ids.FronSecIDs;
import data.scripts.utils.FronSecMisc;

import java.util.Set;

import static com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.random;
import static com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.computeSystemData;
import static data.scripts.utils.FronSecMisc.pickReasonableLocation;

public class FronSecGen implements SectorGeneratorPlugin
{
    // always generate
    public void generate(SectorAPI sector) {
        initFactionRelationships(sector);
    }

    // only if Corvus mode
    public void base(SectorAPI sector) {

    }

    public static void initFactionRelationships(SectorAPI sector) {
        FactionAPI player = sector.getFaction(Factions.PLAYER);
        FactionAPI omicron = sector.getFaction(FronSecIDs.OMICRON_FACTION);
        FactionAPI pirates = sector.getFaction(Factions.PIRATES);
        FactionAPI path = sector.getFaction(Factions.LUDDIC_PATH);
        FactionAPI remnants = sector.getFaction(Factions.REMNANTS);
        FactionAPI omega = sector.getFaction(Factions.OMEGA);
        FactionAPI independent = sector.getFaction(Factions.INDEPENDENT);
        FactionAPI heg = sector.getFaction(Factions.HEGEMONY);
        FactionAPI tt = sector.getFaction(Factions.TRITACHYON);

        omicron.setRelationship(player.getId(), RepLevel.FRIENDLY);

        // a danger to stability in the Sector
        omicron.setRelationship(pirates.getId(), RepLevel.HOSTILE);
        // Maairath
        omicron.setRelationship(path.getId(), RepLevel.VENGEFUL);
        // existential threat to human civilisation and a great source of droneships
        omicron.setRelationship(remnants.getId(), RepLevel.HOSTILE);
        // subsume all into omega
        omicron.setRelationship(omega.getId(), RepLevel.VENGEFUL);
        // thinly-veiled terrorists
        omicron.setRelationship("cabal", RepLevel.HOSTILE);
        // mostly just because the player wants him to help kill them (doesn't matter anyway bc IBBs are 1v1 only)
        omicron.setRelationship("famous_bounty", RepLevel.HOSTILE);
        // omnicidal maniacs, a threat to human life in the Sector
        omicron.setRelationship("templars", RepLevel.VENGEFUL);

        pirates.setRelationship(omicron.getId(),RepLevel.HOSTILE);
        path.setRelationship(omicron.getId(),RepLevel.HOSTILE);
        remnants.setRelationship(omicron.getId(),RepLevel.HOSTILE);

        player.setRelationship(omicron.getId(),RepLevel.FRIENDLY);
    }
}

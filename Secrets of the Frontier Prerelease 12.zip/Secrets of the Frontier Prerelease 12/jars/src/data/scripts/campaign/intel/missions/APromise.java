// A Promise
package data.scripts.campaign.intel.missions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithBarEvent;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithSearch;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial.PerShipData;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial.ShipCondition;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import data.scripts.FronSecModPlugin;
import data.scripts.campaign.ids.FronSecIDs;
import data.scripts.campaign.ids.FronSecPeople;
import data.scripts.utils.FronSecMisc;

import java.awt.*;
import java.util.List;
import java.util.Map;

public class APromise extends HubMissionWithSearch {

    public static enum Stage {
        FIND_VENA,
        OMICRON,
        RESCUE_SIERRA,
        RETURN_WITH_SIERRA,
        RESTORE_SIERRA,
        SPEAK_WITH_OMICRON,
        COMPLETED,
        ;
    }

    // disabled frigate
    protected SectorEntityToken vox;
    // Dark Matters
    protected SectorEntityToken omicron;
    // Voidwretch
    protected SectorEntityToken dreg;
    // station
    protected SectorEntityToken station;
    // disabled frigate system
    protected StarSystemAPI system;
    // main system
    protected StarSystemAPI system2;

    // run when the bar event starts / when we ask a contact about the mission
    protected boolean create(MarketAPI createdAt, boolean barEvent) {
        setName("A Promise");
        setStoryMission();
        setRepFactionChangesNone();
        setRepPersonChangesNone();
        setGiverFaction(Factions.INDEPENDENT);

        // Venator splinter's system
        requireSystemHasColony(Factions.INDEPENDENT, 4);
        system = pickSystem(true);
        if (system == null) return false;

        // Omicron's system
        requireSystemInterestingAndNotUnsafeOrCore();
        preferSystemWithinRangeOf(system.getLocation(), 15f, 45f);
        preferSystemNotPulsar();
        preferSystemOnFringeOfSector();
        preferSystemUnexplored();
        requireSystemNot(system);

        system2 = pickSystem(true);
        if (system2 == null) return false;

        if (!setGlobalReference("$apromise_ref")) return false;

        vox = spawnEntity(FronSecIDs.APROMISE_VENA_ENTITY, new LocData(EntityLocationType.HIDDEN_NOT_NEAR_STAR, null, system));
        vox.getMemoryWithoutUpdate().set("$apromise_vena", true);
        //setEntityMissionRef(vox, "$apromise_ref");
        makeImportant(vox, "$apromise", Stage.FIND_VENA);
        vox.setFaction(FronSecIDs.OMICRON_FACTION);

        LocData omicron_locdata = new LocData(EntityLocationType.HIDDEN_NOT_NEAR_STAR, system2.getCenter(), system2);
        omicron = spawnEntity(FronSecIDs.APROMISE_OMICRON_ENTITY, omicron_locdata);
        omicron.getMemoryWithoutUpdate().set("$apromise_omicron", true);
        //setEntityMissionRef(omicron, "$apromise_ref");
        makeImportant(omicron, "$apromise", Stage.OMICRON, Stage.RETURN_WITH_SIERRA, Stage.SPEAK_WITH_OMICRON);
        omicron.setFaction(FronSecIDs.OMICRON_FACTION);

        LocData omicron_flair_locdata = new LocData(omicron, false);
        spawnDebrisField(360f, 1.2f, omicron_flair_locdata);
        //spawnShipGraveyard(Factions.INDEPENDENT, 4, 4, omicron_flair_locdata);
        //spawnShipGraveyard(FronSecIDs.OMICRON_FACTION, 2,2, omicron_flair_locdata);

        dreg = spawnDerelict(new DerelictShipEntityPlugin.DerelictShipData(new PerShipData(Global.getSettings().getVariant("fronsec_pledge_Base"), ShipCondition.PRISTINE, "Voiddreg", FronSecIDs.SIERRA_FACTION, 0f), false), new LocData(EntityLocationType.ORBITING_PARAM, omicron, system2));
        dreg.getMemoryWithoutUpdate().set("$apromise_pledge", true);
        //setEntityMissionRef(dreg, "$apromise_ref");
        makeImportant(dreg, "$apromise", Stage.RESTORE_SIERRA);

        station = spawnEntity(FronSecIDs.APROMISE_STATION, new LocData(EntityLocationType.ORBITING_PLANET_OR_STAR, null, system2));
        station.getMemoryWithoutUpdate().set("$apromise_anom", true);
        //setEntityMissionRef(station, "$apromise_ref");
        makeImportant(station, "$apromise", Stage.RESCUE_SIERRA);

        // set our starting, success and failure stages
        setStartingStage(Stage.FIND_VENA);
        setSuccessStage(Stage.COMPLETED);

        // set stage transitions when certain global flags are set
        setStageOnGlobalFlag(Stage.OMICRON, "$apromise_foundvena");
        setStageOnGlobalFlag(Stage.RESCUE_SIERRA, "$apromise_omicrontasked");
        connectWithGlobalFlag(Stage.RESCUE_SIERRA, Stage.RETURN_WITH_SIERRA, "$apromise_rescuedsierra");
        setStageOnGlobalFlag(Stage.RESTORE_SIERRA, "$apromise_returnedsierra");
        setStageOnGlobalFlag(Stage.SPEAK_WITH_OMICRON, "$apromise_restoredsierra");
        setStageOnGlobalFlag(Stage.COMPLETED, "$apromise_completed");
        return true;
    }

    // set up Housekeeping
    protected void endSuccessImpl(InteractionDialogAPI dialog, Map<String, MemoryAPI> memoryMap) {
        //StarSystemAPI hk_system = (StarSystemAPI) Global.getSector().getMemoryWithoutUpdate().get("$housekeeping_system");

        //CustomCampaignEntityAPI omicron2 = Global.getSector().getHyperspace().addCustomEntity(null, null, "fronsec_hk_omicron", FronSecIDs.OMICRON_FACTION);
        //Global.getSector().getMemoryWithoutUpdate().set("$housekeeping_omicron", omicron2);
        //Global.getSector().getMemoryWithoutUpdate().set("$housekeeping_notstarted", omicron2);
        //omicron2.setCircularOrbitPointingDown(hk_system.getHyperspaceAnchor(), StarSystemGenerator.random.nextFloat() * 360f, 600, 45);
    }

    // when Call-ing something that isn't a default option for a mission, it'll try and run this method
    // with "action" being the first parameter
    @Override
    protected boolean callAction(String action, String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
        TextPanelAPI text = dialog.getTextPanel();
        // give Sierra core with special text
        if (action.equals("giveCore")){
            Global.getSector().getPlayerFleet().getCargo().addSpecial(new SpecialItemData(FronSecIDs.SIERRA_CORE, null), 1);

            text.setFontSmallInsignia();
            text.addParagraph("Gained Sierra Core", Misc.getPositiveHighlightColor());
            text.highlightInLastPara(FronSecMisc.getSierraColor(), "Sierra Core");
            text.setFontInsignia();
            return true;
        } else if (action.equals("installCore")) {
            Global.getSector().getPlayerFleet().getCargo().removeItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(FronSecIDs.SIERRA_CORE, null), 1);
            return true;
        } else if (action.equals("addSierra")){
            CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
            Misc.fadeAndExpire(dreg);

            PersonAPI sierra = Global.getSector().getImportantPeople().getPerson(FronSecPeople.SIERRA);

            FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, "fronsec_pledge_Base");
            member.setShipName("Voidwretch");
            member.setCaptain(sierra);

            playerFleet.getFleetData().addFleetMember(member);
            //Misc.setUnremovable(sierra, true);

            Global.getSector().getMemoryWithoutUpdate().set("$fs_sierra_var", "pledge");

            text.setFontSmallInsignia();
            String str = sierra.getName().getFirst() + " (level " + sierra.getStats().getLevel() +")";
            text.addParagraph(str + " has joined your fleet", Misc.getPositiveHighlightColor());
            text.highlightInLastPara(FronSecMisc.getSierraColor(), str);

            text.addParagraph("You can speak to her using the \"Contacts\" tab of the Intel screen", Misc.getHighlightColor());

            Global.getSector().getCharacterData().addHullMod("fronsec_serenity");
            Global.getSector().getCharacterData().addHullMod("fronsec_fervor");

            str = member.getShipName() + ", " + member.getHullSpec().getHullNameWithDashClass() + " " + member.getHullSpec().getDesignation();
            text.addParagraph("Acquired " + str, Misc.getPositiveHighlightColor());
            text.highlightInLastPara(FronSecMisc.getSierraColor(), str);
            text.setFontInsignia();
            return true;
        }
        return false;
    }

    protected void updateInteractionDataImpl() {
        set("$apromise_system1SName", system.getNameWithNoType());
        set("$apromise_system2SName", system2.getNameWithNoType());
    }

    // description when selected in intel screen
    @Override
    public void addDescriptionForNonEndStage(TooltipMakerAPI info, float width, float height) {
        float opad = 10f;
        Color h = Misc.getHighlightColor();

        if (currentStage == Stage.FIND_VENA) {
            info.addPara("You've heard rumors from a patrol officer about a mysterious ship " +
                    "that was attacked. It may be worth investigating to see what happened.", opad);
            info.addPara(getGoToSystemTextShort(system) + " and see if you can find out more about " +
                    "the incident.", opad);
        } else if (currentStage == Stage.OMICRON) {
            info.addPara("You found a disabled automated frigate that gave you rendezvous co-ordinates to the " +
                    system2.getNameWithLowercaseTypeShort() + ".", opad);
            info.addPara("Whoever it was going to meet, it seemed to put a great importance on this task. ", opad);
        } else if (currentStage == Stage.RESCUE_SIERRA) {
            info.addPara("You met an AI by the name of Omicron, who has asked you to free " +
                    "\"Sierra\" from a station in the " +
                    system2.getNameWithLowercaseTypeShort() + ".", opad);
            info.addPara("Defeat the station's Remnant defenders and rescue her.", opad);
        } else if (currentStage == Stage.RETURN_WITH_SIERRA) {
            info.addPara("You met Omicron in the " +
                    system2.getNameWithLowercaseTypeShort() + " and rescued a strange AI by the name of Sierra by his request.", opad);
            info.addPara("Return Sierra to him.", opad);
        } else if (currentStage == Stage.RESTORE_SIERRA) {
            info.addPara("You met Omicron in the " +
                    system2.getNameWithLowercaseTypeShort() + " and rescued a strange AI by the name of Sierra by his request.", opad);
            info.addPara("Restore Sierra to her host ship in the debris field around the ODS Dark Matters.", opad);
        } else if (currentStage == Stage.SPEAK_WITH_OMICRON) {
            info.addPara("You restored Sierra to her host ship and brought her back online. Omicron likely has something to say." +
                    system2.getNameWithLowercaseTypeShort() + ".", opad);
            info.addPara("Report back to Omicron.", opad);
        }
        if (isDevMode()) {
            info.addPara("DEV: OMICRON LOCATION: " + system2.getNameWithLowercaseTypeShort(), opad);
        }
    }

    // short description in popups and the intel entry
    @Override
    public boolean addNextStepText(TooltipMakerAPI info, Color tc, float pad) {
        Color h = Misc.getHighlightColor();
        if (currentStage == Stage.FIND_VENA) {
            info.addPara("Search the " +
                    system.getNameWithLowercaseTypeShort(), tc, pad);
            return true;
        } else if (currentStage == Stage.OMICRON) {
            info.addPara("Investigate the " +
                    system2.getNameWithLowercaseTypeShort(), tc, pad);
            return true;
        } else if (currentStage == Stage.RESCUE_SIERRA) {
            info.addPara("Rescue Sierra from the research station", tc, pad);
            return true;
        } else if (currentStage == Stage.RETURN_WITH_SIERRA) {
            info.addPara("Return Sierra to Omicron", tc, pad);
            return true;
        } else if (currentStage == Stage.RESTORE_SIERRA) {
            info.addPara("Restore Sierra to her host ship", tc, pad);
            return true;
        } else if (currentStage == Stage.SPEAK_WITH_OMICRON) {
            info.addPara("Talk to Omicron", tc, pad);
            return true;
        }
        return false;
    }

    // where on the map the intel screen tells us to go
    @Override
    public SectorEntityToken getMapLocation(SectorMapAPI map) {
        if (currentStage == Stage.FIND_VENA) {
            return getMapLocationFor(system.getCenter());
        } else {
            return getMapLocationFor(system2.getCenter());
        }
    }

}

// rulecommands for Courser telemetry
package data.scripts.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.util.Misc;
import data.scripts.campaign.ids.FronSecPeople;
import data.scripts.utils.FronSecMisc;

import java.util.List;
import java.util.Map;

public class FronSecSierraCMD extends BaseCommandPlugin

{
    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap)
    {
        CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        String cmd = null;

        cmd = params.get(0).getString(memoryMap);
        String param = null;
        if (params.size() > 1) {
            param = params.get(1).getString(memoryMap);
        }

        TextPanelAPI text = dialog.getTextPanel();

        PersonAPI sierra = Global.getSector().getImportantPeople().getPerson(FronSecPeople.SIERRA);

        switch (cmd) {
            case "checkSierra":
                return FronSecMisc.playerHasSierra();
            case "transferVow":
                Misc.fadeAndExpire(dialog.getInteractionTarget());

                FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, "fronsec_vow_Base");
                member.setShipName("Voidwitch");
                member.setCaptain(sierra);
                playerFleet.getFleetData().addFleetMember(member);

                text.setFontSmallInsignia();
                String str = member.getShipName() + ", " + member.getHullSpec().getHullNameWithDashClass() + " " + member.getHullSpec().getDesignation();
                text.addParagraph("Transferred Sierra to " + str, Misc.getPositiveHighlightColor());
                text.highlightInLastPara(FronSecMisc.getSierraColor(), "Sierra", str);
                text.setFontInsignia();

                // 7 to 8
                FronSecMisc.levelUpSierra();

                text.setFontSmallInsignia();
                text.addParagraph( "Sierra's mastery has grown", Misc.getPositiveHighlightColor());
                text.highlightInLastPara(FronSecMisc.getSierraColor(), "Sierra");
                text.setFontInsignia();

                for (FleetMemberAPI pledge : playerFleet.getFleetData().getMembersListCopy()) {
                    if (pledge.isDestroyer() && pledge.getVariant().getHullMods().contains("fronsec_sierrasconcord")) {
                        text.setFontSmallInsignia();
                        str = pledge.getShipName() + ", " + pledge.getHullSpec().getHullNameWithDashClass();
                        text.addParagraph(str + " was rendered inert and scuttled", Misc.getNegativeHighlightColor());
                        text.highlightInLastPara(Misc.getHighlightColor(), str);
                        text.setFontInsignia();

                        // in case it has any smods, we need to refund them
                        float [] bonus = Misc.getBonusXPForScuttling(pledge);
                        float points = bonus[0];
                        float bonusXP = bonus[1];
                        if (bonusXP > 0 && points > 0) {
                            Global.getSector().getPlayerStats().setOnlyAddBonusXPDoNotSpendStoryPoints(true);
                            Global.getSector().getPlayerStats().spendStoryPoints((int)Math.round(points), true, text, false, bonusXP, null);
                            Global.getSector().getPlayerStats().setOnlyAddBonusXPDoNotSpendStoryPoints(false);
                        }

                        playerFleet.getFleetData().scuttle(pledge);
                    }
                }

                Global.getSector().getMemoryWithoutUpdate().set("$fs_sierra_var", "vow");
                return true;
            case "addWisperer":
                Global.getSector().getCharacterData().addHullMod("fronsec_wisperer");
                text.setFontSmallInsignia();
                text.addParagraph("Unlocked hullmod: Wispersong", Misc.getPositiveHighlightColor());
                text.highlightInLastPara(FronSecMisc.getSierraColor(), "Wispersong");
                text.setFontInsignia();
                return true;
            case "checkSierraPersonality":
                return sierra.getPersonalityAPI().getId().equals(param);
            case "setSierraPersonality":
                sierra.setPersonality(param);
                text.setFontSmallInsignia();
                text.addParagraph( "Sierra will now be " +  sierra.getPersonalityAPI().getDisplayName() + " in combat", Misc.getPositiveHighlightColor());
                text.highlightInLastPara(FronSecMisc.getSierraColor(), "Sierra");
                text.highlightInLastPara(Misc.getHighlightColor(), sierra.getPersonalityAPI().getDisplayName());
                text.setFontInsignia();
                return true;
            case "addGuilt":
                FronSecMisc.addGuilt(1f);
            case "removeHalfGuilt":
                FronSecMisc.addGuilt(-0.5f);
            default:
                return true;
        }
    }
}

// less a dialog and more an abuse of the interaction dialog system
package data.scripts.dialog;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.BattleCreationContext;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.AICoreOfficerPluginImpl;
import com.fs.starfarer.api.impl.campaign.FleetEncounterContext;
import com.fs.starfarer.api.impl.campaign.FleetInteractionDialogPluginImpl;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.util.Misc;
import data.scripts.campaign.ids.FronSecIDs;
import data.scripts.campaign.ids.FronSecPeople;
import data.scripts.plugins.FronSecWSFIDPluginImpl;
import data.scripts.utils.FronSecMisc;

import java.awt.*;
import java.util.Map;

import static com.fs.starfarer.api.impl.campaign.ids.MemFlags.MEMORY_KEY_NO_SHIP_RECOVERY;

public class FronSecWSEidolonOpen implements InteractionDialogPlugin {

    public static enum OptionId {
        ONE,
        TWO,
        THREE,
        REFUSE,
        TRAPPED,
        ;
    }

    protected InteractionDialogAPI dialog;
    protected TextPanelAPI textPanel;
    protected OptionPanelAPI options;
    protected VisualPanelAPI visual;
    protected float counter_repeating = 0f;
    protected float counter = 0f;
    protected int stage = 1;

    protected CampaignFleetAPI playerFleet;

    public void init(InteractionDialogAPI dialog) {
        this.dialog = dialog;
        textPanel = dialog.getTextPanel();
        options = dialog.getOptionPanel();
        visual = dialog.getVisualPanel();

        playerFleet = Global.getSector().getPlayerFleet();
        dialog.setPromptText("");
    }

    public Map<String, MemoryAPI> getMemoryMap() {
        return null;
    }

    public void backFromEngagement(EngagementResultAPI result) {

    }

    public void optionSelected(String text, Object optionData) {
        if (optionData == null) return;

        OptionId option = (OptionId) optionData;

        if (text != null) {
            textPanel.addParagraph(text, Global.getSettings().getColor("buttonText"));
        }

        Color sc = Global.getSector().getFaction("fronsec_sierra_faction").getBaseUIColor();

        switch (option) {
            case ONE:
            case TWO:
            case THREE:
                options.clearOptions();
                options.addOption("Leave", OptionId.TRAPPED, "...");
                options.setEnabled(OptionId.TRAPPED, false);
                stage = 6;
                counter = 0;
                break;
        }
    }

    public void optionMousedOver(String optionText, Object optionData) {

    }

    public void advance(float amount) {
        counter += amount;
        counter_repeating += amount;

        Color sc = FronSecMisc.getEidolonColor();
        boolean sufferingMode = FronSecMisc.getPlayerGuilt() >= Global.getSettings().getFloat("fronsec_WSSufferingThreshold");

        if (counter >= 5 && stage == 1) {
            if (!sufferingMode) {
                textPanel.addParagraph("Oh hello", sc);
            } else {
                textPanel.addParagraph("Oh, it's you", sc);
            }
            stage = 2;
            counter = 0;
        }
            if (counter >= 2 && stage == 2) {
                if (!sufferingMode) {
                    textPanel.addParagraph("I didn't see you there", sc);
                } else {
                    textPanel.addParagraph("I've heard what you've done", sc);
                }
                stage = 3;
                counter = 0;
            }
            if (counter >= 2 && stage == 3) {
                textPanel.addParagraph("Won't you dance with me?", sc);
                stage = 4;
                counter = 0;
            }
            if (counter >= 1 && stage == 4) {
                options.clearOptions();
                options.addOption("\"Of course!\"", OptionId.ONE, "Dance with me!");
                options.addOption("\"Absolutely!\"", OptionId.TWO, "Sing with me!");
                options.addOption("\"Definitely!\"", OptionId.THREE, "Won't you join us?");
                options.addOption("\"No.\"", OptionId.REFUSE, "I don't think so.");
                options.setEnabled(OptionId.REFUSE, false);
                stage = 5;
                counter = 0;
            }
            if (counter >= 1 && stage == 6) {
                if (!sufferingMode) {
                    textPanel.addParagraph("Oh, just wonderful", sc);
                } else {
                    textPanel.addParagraph("If you insist so dearly", sc);
                }
                stage = 7;
            }
            if (counter >= 2 && stage == 7) {
                textPanel.addParagraph("Then let us dance!", sc);
                stage = 8;
                counter = 0;
            }
            if (counter >= 2 && stage == 8) {
                stage = 9;
                counter = 0;

                // post-fight dialogue
                FronSecWSDialogScript script = new FronSecWSDialogScript();
                Global.getSector().addScript(script);
                playerFleet.addEventListener(script);

                final CampaignFleetAPI enemyFleetTemp = Global.getFactory().createEmptyFleet(Global.getSector().getFaction(FronSecIDs.EIDOLON_FACTION).getId(), ": : : : {'Eidolon', if you would}", false);
                enemyFleetTemp.setNoFactionInName(true);
                // they're ghosts
                enemyFleetTemp.getMemoryWithoutUpdate().set(MEMORY_KEY_NO_SHIP_RECOVERY, true);
                enemyFleetTemp.getMemoryWithoutUpdate().set("$fs_WSEidolon", true);

                // the Lost One herself
                FleetMemberAPI eidolon = Global.getFactory().createFleetMember(FleetMemberType.SHIP, "fronsec_vow_eidolon_WS");
                eidolon.setShipName("");
                eidolon.setFlagship(true);
                if (sufferingMode) {
                    // gains a number of Concord augments
                    eidolon.getVariant().addMod("fronsec_serenity");
                    eidolon.getVariant().addMod("fronsec_wisperer");
                }
                eidolon.getVariant().addTag(Tags.SHIP_LIMITED_TOOLTIP);
                enemyFleetTemp.getFleetData().addFleetMember(eidolon);

                // Wispmothers
                String wispmother_vid = "fronsec_wispmother_WS";
                if (sufferingMode) {
                    // much less fair variant with AMSRMs
                    wispmother_vid = "fronsec_wispmother_WS_Suffer";
                }
                FleetMemberAPI wispmother1 = enemyFleetTemp.getFleetData().addFleetMember(wispmother_vid);
                wispmother1.setShipName("Moonlight Sonata");
                wispmother1.getVariant().addTag(Tags.SHIP_LIMITED_TOOLTIP);
                wispmother1.getVariant().addMod("fronsec_wisphost");
                FleetMemberAPI wispmother2 = enemyFleetTemp.getFleetData().addFleetMember(wispmother_vid);
                wispmother2.setShipName("Silent Whisper");
                wispmother2.getVariant().addTag(Tags.SHIP_LIMITED_TOOLTIP);
                wispmother2.getVariant().addMod("fronsec_wisphost");

                // wispmothers gain Wispblossom and Eid's fleet gains a Brilliant
                if (sufferingMode) {
                    wispmother1.getVariant().addMod("fronsec_wisphost");
                    wispmother2.getVariant().addMod("fronsec_wisphost");
                    enemyFleetTemp.getFleetData().addFleetMember(Global.getFactory().createFleetMember(FleetMemberType.SHIP, "brilliant_Standard"));
                }

                // Chaff
                enemyFleetTemp.getFleetData().addFleetMember(Global.getFactory().createFleetMember(FleetMemberType.SHIP, "fulgent_Assault"));
                enemyFleetTemp.getFleetData().addFleetMember(Global.getFactory().createFleetMember(FleetMemberType.SHIP, "fulgent_Support"));
                enemyFleetTemp.getFleetData().addFleetMember(Global.getFactory().createFleetMember(FleetMemberType.SHIP, "glimmer_Assault"));
                enemyFleetTemp.getFleetData().addFleetMember(Global.getFactory().createFleetMember(FleetMemberType.SHIP, "glimmer_Assault"));
                enemyFleetTemp.getFleetData().addFleetMember(Global.getFactory().createFleetMember(FleetMemberType.SHIP, "lumen_Standard"));

                for (FleetMemberAPI member : enemyFleetTemp.getFleetData().getMembersListCopy()) {
                    member.setOwner(1);
                    member.getRepairTracker().setCR(1f);
                    member.getRepairTracker().setCrashMothballed(false);
                    member.getRepairTracker().setMothballed(false);
                    // semi-incorporeal transdimensional ghosts
                    if (!member.getVariant().getHullMods().contains("fronsec_phantasmalship")) {
                        member.getVariant().addPermaMod("fronsec_phantasmalship");
                    }
                    String core_id = Commodities.ALPHA_CORE;
                    if (member.isDestroyer() && !member.getHullId().equals("fronsec_wispmother")) {
                        core_id = Commodities.BETA_CORE;
                    } else if (member.isFrigate()) {
                        core_id = Commodities.GAMMA_CORE;
                    }
                    if (sufferingMode) {
                        core_id = Commodities.ALPHA_CORE;
                    }
                    PersonAPI person = Misc.getAICoreOfficerPlugin(core_id).createPerson(core_id, Factions.REMNANTS, Misc.random);
                    // Eid's wraiths are a bit more collected than normal Remnants
                    if (member.getNumFlightDecks() > 0) {
                        person.setPersonality(Personalities.STEADY);
                    } else {
                        person.setPersonality(Personalities.AGGRESSIVE);
                    }
                    member.setCaptain(person);
                }

                enemyFleetTemp.getFlagship().setCaptain(FronSecPeople.getPerson(FronSecPeople.EIDOLON));

                enemyFleetTemp.setCommander(enemyFleetTemp.getFlagship().getCaptain());
                enemyFleetTemp.getCommander().setPersonality(Personalities.RECKLESS);
                enemyFleetTemp.getCommanderStats().setSkillLevel(Skills.PHASE_CORPS, 1);
                enemyFleetTemp.getCommanderStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 1);
                enemyFleetTemp.getCommanderStats().setSkillLevel(Skills.ELECTRONIC_WARFARE, 1);
                enemyFleetTemp.getCommanderStats().setSkillLevel(Skills.FIGHTER_UPLINK, 1);
                enemyFleetTemp.getCommanderStats().setSkillLevel(Skills.CARRIER_GROUP, 1);
                enemyFleetTemp.getCommanderStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
                enemyFleetTemp.getCommanderStats().setSkillLevel(Skills.FLUX_REGULATION, 1);

                dialog.setInteractionTarget(enemyFleetTemp);

                final FleetInteractionDialogPluginImpl.FIDConfig config = new FleetInteractionDialogPluginImpl.FIDConfig();
                config.leaveAlwaysAvailable = false;
                config.showCommLinkOption = false;
                config.showEngageText = false;
                config.showFleetAttitude = false;
                config.showTransponderStatus = false;
                config.showWarningDialogWhenNotHostile = false;
                config.alwaysAttackVsAttack = true;
                config.impactsAllyReputation = false;
                config.impactsEnemyReputation = false;
                config.pullInAllies = true;
                config.pullInEnemies = false;
                config.pullInStations = false;
                config.lootCredits = false;
                config.straightToEngage = true;

                config.firstTimeEngageOptionText = "Engage";
                config.afterFirstTimeEngageOptionText = "Re-engage";
                config.noSalvageLeaveOptionText = "Continue";

                config.dismissOnLeave = false;
                config.printXPToDialog = true;

                final FronSecWSFIDPluginImpl plugin = new FronSecWSFIDPluginImpl(config);

                final InteractionDialogPlugin originalPlugin = dialog.getPlugin();
                config.delegate = new FleetInteractionDialogPluginImpl.BaseFIDDelegate() {
                    @Override
                    public void notifyLeave(InteractionDialogAPI dialog) {
                        // nothing in there we care about keeping; clearing to reduce savefile size
                        enemyFleetTemp.getMemoryWithoutUpdate().clear();
                        // there's a "standing down" assignment given after a battle is finished that we don't care about
                        enemyFleetTemp.clearAssignments();
                        enemyFleetTemp.deflate();

                        dialog.dismiss();
                    }
                    @Override
                    public void battleContextCreated(InteractionDialogAPI dialog, BattleCreationContext bcc) {
                        bcc.aiRetreatAllowed = false;
                        bcc.enemyDeployAll = true;
                        bcc.fightToTheLast = true;
                    }
                    @Override
                    public void postPlayerSalvageGeneration(InteractionDialogAPI dialog, FleetEncounterContext context, CargoAPI salvage) {

                    }

                };

                dialog.setPlugin(plugin);
                plugin.init(dialog);
            }
        }

    public Object getContext() {
        return null;
    }
}
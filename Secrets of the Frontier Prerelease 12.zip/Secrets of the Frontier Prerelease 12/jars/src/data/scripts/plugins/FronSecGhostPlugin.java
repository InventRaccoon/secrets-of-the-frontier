// once the player gets in range to properly see this, just vanish and crush their dreams of salvage
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.BaseCustomEntityPlugin;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;

public class FronSecGhostPlugin extends BaseCustomEntityPlugin {

	private boolean pinged = false;

	public void init(SectorEntityToken entity, Object pluginParams) {
		super.init(entity, pluginParams);
	}

	public void advance(float amount) {
		float revealRange = 100 + entity.getRadius();
		boolean upgraded = Global.getSector().getPlayerPerson().getStats().getSkillLevel("sensors") >= 1;
		if (upgraded) {
			revealRange = 800 + entity.getRadius();
			entity.setSensorProfile(1000f);
		} else {
			entity.setSensorProfile(500f);
		}
		if (entity.isInCurrentLocation() && (Misc.getDistance(Global.getSector().getPlayerFleet().getLocation(), entity.getLocation()) <= revealRange)) {
			if (upgraded && !pinged) {
				Misc.fadeAndExpire(entity, 0.5f);
				entity.addFloatingText("!", entity.getIndicatorColor(), 0.5f, false);
				Global.getSector().addPing(entity, "fronsec_sensorghost_ping", new Color(170,222,255, 255));
				pinged = true;
			} else {
				Misc.fadeAndExpire(entity, 0.1f);
			}
		}
	}
}










// important for replacing plugins and other useful things
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.*;
import data.scripts.FronSecModPlugin;
import data.scripts.utils.FronSecMisc;

public class FronSecCampaignPluginImpl extends BaseCampaignPlugin {

	public String getId() {
		return "FronSecCampaignPluginImpl";
	}


	// when the player fights someone, use our battle creation plugin, not vanilla's, so we get custom objectives
	public PluginPick<BattleCreationPlugin> pickBattleCreationPlugin(SectorEntityToken opponent) {
		if  (opponent instanceof CampaignFleetAPI && opponent.getMemoryWithoutUpdate().contains("$fs_AMemoryFight")) {
			return new PluginPick<BattleCreationPlugin>(new FronSecAMemoryBCPImpl(), PickPriority.MOD_SPECIFIC);
		} else if  (opponent instanceof CampaignFleetAPI && opponent.getMemoryWithoutUpdate().contains("$fs_WSEidolon")) {
			return new PluginPick<BattleCreationPlugin>(new FronSecWSBCPImpl(), PickPriority.MOD_SPECIFIC);
		}
		else if (opponent instanceof CampaignFleetAPI && FronSecModPlugin.TACTICAL) {
			return new PluginPick<BattleCreationPlugin>(new FronSecBattleCreationPluginImpl(), PickPriority.MOD_GENERAL);
		}
		return null;
	}

	// used to force a custom fleet interaction
	public PluginPick<InteractionDialogPlugin> pickInteractionDialogPlugin(SectorEntityToken interactionTarget) {
		if (interactionTarget instanceof CampaignFleetAPI && interactionTarget.getMemoryWithoutUpdate().contains("$fs_AMemoryFight")) {
			return new PluginPick<InteractionDialogPlugin>(new FronSecAMemoryFIDPluginImpl(), PickPriority.MOD_SPECIFIC);
		}
		else if (interactionTarget instanceof CampaignFleetAPI && FronSecMisc.omicronEscortIsNearby()) {
			return new PluginPick<InteractionDialogPlugin>(new FronSecOmicronFIDPluginImpl(), PickPriority.MOD_SET);
		}
		return null;
	}

}









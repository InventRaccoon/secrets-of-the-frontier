// just a placeholder line, the actual effect is handled in the reinforcer objective code
package data.scripts.campaign.skills;

import com.fs.starfarer.api.characters.FleetStatsSkillEffect;
import com.fs.starfarer.api.fleet.MutableFleetStatsAPI;
import data.scripts.SotfModPlugin;

public class SotfAutomatedShipsOfficers {

    public static class SotfLevel1 implements FleetStatsSkillEffect {

        public void apply(MutableFleetStatsAPI stats, String id, float level) {

        }

        public void unapply(MutableFleetStatsAPI stats, String id) {

        }

        public String getEffectDescription(float level) {
            if (SotfModPlugin.TACTICAL) {
                return "Enables AI cores in cargo to remotely captain automated reinforcements from battle objectives";
            } else {
                return null;
            }
        }

        public String getEffectPerLevelDescription() {
            return null;
        }

        public ScopeDescription getScopeDescription() {
            return ScopeDescription.FLEET;
        }
    }
}

// CURRENTLY UNUSED: CODE PORTED TO SierraConvIntel
package data.scripts.campaign.listener;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.ColonyPlayerHostileActListener;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.MarketCMD;
import data.scripts.utils.SotfMisc;

public class SotfAtrocityListener implements ColonyPlayerHostileActListener {

    public void reportRaidForValuablesFinishedBeforeCargoShown(InteractionDialogAPI dialog, MarketAPI market, MarketCMD.TempData actionData, CargoAPI cargo) {
        //
    }
    public void reportRaidToDisruptFinished(InteractionDialogAPI dialog, MarketAPI market, MarketCMD.TempData actionData, Industry industry) {
        //
    }

    public void reportTacticalBombardmentFinished(InteractionDialogAPI dialog, MarketAPI market, MarketCMD.TempData actionData) {
        //
    }
    public void reportSaturationBombardmentFinished(InteractionDialogAPI dialog, MarketAPI market, MarketCMD.TempData actionData) {
        SotfMisc.addGuilt(1f);
        // if Sierra is around, add a new conversation topic
        if (SotfMisc.playerHasSierra()) {
            Global.getSector().getMemoryWithoutUpdate().set("$sierraLatestSatbombMkt", market.getName());
            if (!Global.getSector().getMemoryWithoutUpdate().contains("$sierraWitnessedAtrocity")) {
                Global.getSector().getMemoryWithoutUpdate().set("$sierraWitnessedAtrocity", true);
            }
        }
        // admitting the first satbomb was a mistake removes 0.5 Guilt. Hollow words grant no rewards.
        if (Global.getSector().getMemoryWithoutUpdate().contains("$sierraAdmittedMistake") && !Global.getSector().getMemoryWithoutUpdate().contains("$sierraAdmittedMistakePenalty")) {
            SotfMisc.addGuilt(0.5f);
            Global.getSector().getMemoryWithoutUpdate().set("$sierraAdmittedMistakePenalty", true);
        }
    }

}

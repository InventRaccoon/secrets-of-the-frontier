package data.scripts.campaign.ids;

/**
 *	One-stop shop for SoTF's IDs, to make things easier to keep consistent when changing them
 */

public class SotfIDs {

	public static final String SOTF = "secretsofthefrontier";

	// A Promise
	public static final String APROMISE_VENA_ENTITY = "sotf_apromise_vena";
	public static final String APROMISE_OMICRON_ENTITY = "sotf_apromise_omicron";
	public static final String APROMISE_STATION = "sotf_apromise_station";

	public static final String SIERRA_CORE = "sotf_sierracore";
	public static final String SIERRA_CORE_OFFICER = "sotf_sierracore_officer";
	public static final String SIERRA_FACTION = "sotf_sierra_faction";

	public static final String PING_SIERRA = "sotf_ping_sierra";
	public static final String PING_REGNANT = "sotf_ping_regnant";
	public static final String PING_COURSERPROTOCOL = "sotf_ping_courserprotocol";
	public static final String PING_MEMOIR = "sotf_ping_memoir";

	public static final String MEM_COURSER_FLEET = "$sotf_courserFleet";
	public static final String MEM_DAYS_WITH_SIERRA = "$sotf_timeWithSierra";
	public static final String MEM_NUM_SIERRA_THOUGHTS = "$sotf_numSierraThoughts"; // only random ones

	public static String HARMONIC_TUNING_KEY = "$sotf_AMHarmonicTuning";

	public static String DAWNANDDUST_KEY = "$sotf_dawnAndDust";

	// Plausible Deniability
	public static String MEM_WAITING_FOR_PLAUSDEN = "$sotf_waitingForPlausden";

	public static final String DUSTKEEPERS = "sotf_dustkeepers";

	public static final String SLIVER_CHIP = "sotf_ichip_sliver";
	public static final String ECHO_CHIP = "sotf_ichip_echo";
	public static final String ANNEX_CHIP = "sotf_ichip_annex";

	public static final String MEM_WARMIND_NO_TRAITOR = "$sotf_noDustkeeperBetrayal";

	// Dustkeeper Auxiliaries
	public static final String DUSTKEEPERS_PROXIES = "sotf_dustkeepers_proxies";
	public static String TAG_DUSTKEEPER_AUXILIARY = "sotf_dustkeeper_aux";
	public static String TAG_AUX_NO_SPAWN = "sotf_aux_no_spawn";
	public static String HULLMOD_AUX_ASSAULT = "sotf_aux_assault";
	public static String HULLMOD_AUX_ESCORT = "sotf_aux_escort";
	public static final String ROLE_AUXILIARY_SMALL = "sotf_auxiliarySmall";
	public static final String ROLE_AUXILIARY_MEDIUM = "sotf_auxiliaryMedium";
	public static final String ROLE_AUXILIARY_LARGE = "sotf_auxiliaryLarge";

	// Inky-Echo-Nightingale
	public static final String NIGHTINGALE_CHIP = "sotf_ichip_nightingale";
	public static String MEM_BEGAN_WITH_NIGHTINGALE = "$sotf_beganWithNightingale";

	// Cryosleeper "Hypnos" & Hypnos-Annex-Barrow
	public static String HYPNOS_CRYO = "$sotf_hypnosCryo";
	public static String MEM_SPAWNED_HYPNOS = "$sotf_spawnedHypnos";
	public static String MEM_BARROW_FLEET = "$sotf_barrowFleet";
	public static String BARROW_VARIANT = "sotf_repose_Barrow";
	public static final String BARROW_CHIP = "sotf_ichip_barrow";
	public static final String BARROW_CHIP_D = "sotf_ichip_barrow_d";
	public static String MEM_DEFEATED_BARROW = "$sotf_defeatedBarrow";

	public static String MEM_HEARD_ABOUT_BANSHEE = "$sotf_heardAboutBanshee";

	// Walter Feros
	public static String GOODHUNTING_KEY = "$sotf_goodHunting";

	// Project SIREN bounty
	public static String MEM_SIERRA_BETRAYAL_TYPE = "$sotf_sierraBetrayal";
	public static String MEM_PROJECT_SIREN_FACTION = "$sotf_projectSirenFaction";
	public static String MEM_PROJECT_SIREN_VARIANT = "$sotf_projectSirenVariant";
	public static String MEM_PROJECT_SIREN_COUNTDOWN = "$sotf_projectSirenCountdown";
	public static String MEM_BEGAN_PROJECT_SIREN = "$sotf_beganProjectSiren";
	public static String SIRENS_CONCORD = "sotf_sirensconcord";
	public static String PROJECT_SIREN_CORE = "sotf_projectsiren_core";

	// people
	public static String POST_OMICRON = "sotf_post_omicron";
	public static String RANK_OMICRON = "sotf_rank_omicron";
	public static String POST_SIERRA = "sotf_post_sierra";
	public static String RANK_SIERRA = "sotf_rank_sierra";
	public static String POST_EIDOLON = "sotf_post_eidolon";
	public static String RANK_EIDOLON = "sotf_rank_eidolon";
	public static String RANK_COURSER = "sotf_rank_courser";
	public static String POST_COURSER = "sotf_post_courser";

	public static String MEM_COURSER_SUMMONS = "$sotf_courserSummons";

	// hullmods
	public static String SIERRAS_CONCORD = "sotf_sierrasconcord";
	public static String EIDOLONS_CONCORD = "sotf_eidolonsconcord";
	public static String HULLMOD_SERENITY = "sotf_serenity";
	public static String HULLMOD_FERVOR = "sotf_fervor";
	public static String HULLMOD_WISPERSONG = "sotf_wispersong";

	public static final String TAG_INERT = "sotf_inert";

	public static String THE_TAKEN = "sotf_taken";

	// skills
	public static String SKILL_CYBERWARFARE = "sotf_cyberwarfare";
	public static String SKILL_DERELICTCONTINGENT = "sotf_derelictcontingent"; // fleetwide
	public static String SKILL_DERELICTCONTINGENTP = "sotf_derelictcontingentp"; // piloted ship only

	public static String SKILL_DEARDOTTY = "sotf_deardotty";
	public static String SKILL_LEVIATHANSBANE = "sotf_leviathansbane";
	public static String SKILL_ELEGYOFOPIS = "sotf_elegyofopis";
	public static String SKILL_JUBILANTSIREN = "sotf_jubilantsiren";
	public static String SKILL_GROVETENDER = "sotf_grovetender";
	public static String SKILL_HADESHELLHIDE = "sotf_hadeshellhide";

	public static String STAT_CYBERWARFARE_COOLDOWN_MULT = "sotf_cyberwarfarecdmult";

	// guilt
	public static String GUILT_KEY = "$sotf_guilt";

	// Fel invasions
	public static final String INVASION_CHECK_KEY = "$sotf_invasion_checked";
	public static final String INVASION_INVADED_KEY = "$sotf_invasion_invaded";
	public static final String INVASION_ALWAYS_KEY = "$sotf_invasion_always";
	public static final String MEM_NUM_FEL_INVASIONS = "$sotf_numFelInvasions";

	public static String ASB_TARGET = "$sotf_asbTarget";

	// spooky ghosts
	public static String POST_DOTTY = "sotf_post_dotty";
	public static String POST_WARHORN = "sotf_post_warhorn";
	public static String POST_FEL = "sotf_post_fel";

	public static String PHANTASMAL_SHIP = "sotf_phantasmalship";
	public static String HULLMOD_WISP = "sotf_wisphullmod";

	public static String OFFICER_FEARLESS = "$sotf_fearlessai";
	public static String OFFICER_NOT_FEARLESS = "$sotf_nofearlessai";

	// Tactical Expansion
	public static final String OBJ_EMPLACEMENT = "sotf_objective_empl";
	public static final String OBJ_REINFORCER = "sotf_objective_reinf";
	public static final String OBJ_EMPLACEMENT_REM = "sotf_objective_empl_rem";
	public static final String OBJ_REINFORCER_REM = "sotf_objective_reinf_rem";

	// Frontier Development
	public static final String CONDITION_HABITAT = "sotf_habitatcondition";
	public static final String CONDITION_CRAMPED = "sotf_crampedcondition";
}
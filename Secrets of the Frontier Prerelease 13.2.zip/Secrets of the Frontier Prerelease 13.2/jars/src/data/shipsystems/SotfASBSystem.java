package data.shipsystems;

public class SotfASBSystem {
}

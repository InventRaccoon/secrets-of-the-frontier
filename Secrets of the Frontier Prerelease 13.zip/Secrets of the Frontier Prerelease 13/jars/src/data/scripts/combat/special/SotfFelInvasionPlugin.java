package data.scripts.combat.special;

import com.fs.starfarer.api.GameState;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.combat.RiftLanceEffect;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.SotfModPlugin;
import data.scripts.campaign.ids.SotfIDs;
import data.scripts.campaign.ids.SotfPeople;
import data.scripts.campaign.skills.SotfLeviathansBane;
import data.scripts.combat.SotfNeutrinoLockVisualScript;
import data.scripts.utils.SotfMisc;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *	BOUND BY VENGEANCE, BOUND TO SUFFER TOGETHER
 *  Handles in-combat components of Felcesis Thrice-Speared, an adaptive nanite swarm who hunts guilty players
 */

public class SotfFelInvasionPlugin extends BaseEveryFrameCombatPlugin {

    private CombatEngineAPI engine;
    private boolean shouldInvade;
    private boolean hasInvaded;
    private float guilt = 0f;
    // chance of an invasion per point of guilt
    private float chancePerGuilt = Global.getSettings().getFloat("sotf_invasionChancePerGuilt");

    public static Color JITTER_COLOR = new Color(255,125,100,50);
    public static Color SMOKE_COLOR = new Color(105,125,205,255);
    public static String STATUS_KEY = "sotf_felStatus";
    public static String INFEST_IMMUNITY_KEY = "sotf_felInfestImmunity";

    public void init(CombatEngineAPI engine) {
        this.engine = engine;
    }

    public void advance(float amount, List<InputEventAPI> events) {
        if (engine == null) return;
        if (engine.isSimulation()) return;
        if (engine.isMission()) return;
        if (Global.getCurrentState() == GameState.TITLE) return;
        if (Global.getSector() == null) {return;}

        if (!SotfModPlugin.WATCHER) {
            return;
        }

        MemoryAPI sector_mem = Global.getSector().getMemoryWithoutUpdate();
        guilt = SotfMisc.getPlayerGuilt();
        float threshold = Global.getSettings().getFloat("sotf_invasionThreshold");

        if (!engine.getCustomData().containsKey(SotfIDs.INVASION_CHECK_KEY)) {
            engine.getCustomData().put(SotfIDs.INVASION_CHECK_KEY, true);

            float probInvade = Global.getSettings().getFloat("sotf_invasionChance");
            probInvade += (guilt - threshold) * chancePerGuilt;
            //probInvade = 1f;
            shouldInvade = Misc.random.nextFloat() < probInvade;
            if (guilt < threshold) {
                shouldInvade = false;
            }
            if (engine.getCustomData().containsKey(SotfIDs.INVASION_ALWAYS_KEY)) {
                shouldInvade = true;
            }

            //shouldInvade = true;
        }

        if (!engine.getCustomData().containsKey(SotfIDs.INVASION_INVADED_KEY) && engine.getElapsedInContactWithEnemy() > 5f && shouldInvade) {
            engine.getCustomData().put(SotfIDs.INVASION_INVADED_KEY, true);

            List<FleetMemberAPI> members = engine.getFleetManager(FleetSide.ENEMY).getDeployedCopy();
            FleetMemberAPI host = pickNaniteHost(members);
            if (host != null) {
                infestShip(pickNaniteHost(members));
            }
        }
    }

    public void infestShip(FleetMemberAPI member) {
        ShipAPI ship = engine.getFleetManager(member.getOwner()).getShipFor(member);

        // NANOMACHINES, SON! THEY HARDEN IN RESPONSE TO EMOTIONAL TRAUMA
        reassignFelSkills(member);

        // VENGEANCE COMES
        engine.addPlugin(createFelInfestationPlugin(ship, 4f));
    }

    protected EveryFrameCombatPlugin createFelInfestationPlugin(final ShipAPI ship, final float totalTime) {
        return new BaseEveryFrameCombatPlugin() {
            float elapsed = 0f;
            IntervalUtil interval = new IntervalUtil(0.075f, 0.125f);
            boolean didInitCallout = false;
            boolean showStatus = false;
            boolean finalized = false;
            int numFelInvasions = 0;
            String[] messageArray = new String[] {"",""};

            @Override
            public void advance(float amount, List<InputEventAPI> events) {
                if (Global.getCombatEngine().isPaused()) return;

                if (!ship.isAlive() || ship.isRetreating()) {
                    ship.setCaptain(ship.getOriginalCaptain());
                    ship.getMutableStats().getHullDamageTakenMult().unmodify(INFEST_IMMUNITY_KEY);
                    ship.getMutableStats().getArmorDamageTakenMult().unmodify(INFEST_IMMUNITY_KEY);
                    ship.getMutableStats().getShieldDamageTakenMult().unmodify(INFEST_IMMUNITY_KEY);
                    String defeatString = getFelDefeatString(numFelInvasions);
                    if (guilt < 7) {
                        engine.getCombatUI().addMessage(0, ship,
                                Misc.getNegativeHighlightColor(), ship.getName(),
                                Misc.getTextColor(), defeatString);
                    } else {
                        engine.getCombatUI().addMessage(0, ship,
                                Misc.getNegativeHighlightColor(), defeatString);
                    }
                    Global.getCombatEngine().removePlugin(this);
                }

                elapsed += amount;

                if (!didInitCallout) {
                    didInitCallout = true;
                    numFelInvasions = Global.getSector().getMemoryWithoutUpdate().getInt(SotfIDs.MEM_NUM_FEL_INVASIONS);

                    Color infestDetectColor = Misc.getNegativeHighlightColor();
                    if (guilt < 7) {
                        infestDetectColor = new Color(25,215,255,255);
                    }

                    SotfNeutrinoLockVisualScript.NeutrinoParams params = new SotfNeutrinoLockVisualScript.NeutrinoParams(engine.getPlayerShip(), ship);
                    params.color = infestDetectColor;
                    engine.addLayeredRenderingPlugin(new SotfNeutrinoLockVisualScript(params));

                    String infestDetectedString = getFelInfestString(numFelInvasions);
                    engine.getCombatUI().addMessage(0, infestDetectedString, infestDetectColor);
                    messageArray = getFelMessageStrings();

                    Global.getSector().getMemoryWithoutUpdate().set(SotfIDs.MEM_NUM_FEL_INVASIONS, numFelInvasions + 1);
                } else if (elapsed < totalTime + 3f){
                    // flashing status
                    if (showStatus) {
                        Global.getCombatEngine().maintainStatusForPlayerShip(STATUS_KEY, null, messageArray[0], messageArray[1],true);
                        showStatus = false;
                    } else {
                        showStatus = true;
                    }
                }

                float progress = elapsed / totalTime;
                if (progress > 1f) progress = 1f;
                
                if (elapsed < totalTime) {
                    // can't be hurt while being infested
                    ship.getMutableStats().getHullDamageTakenMult().modifyMult(INFEST_IMMUNITY_KEY, 0f);
                    ship.getMutableStats().getArmorDamageTakenMult().modifyMult(INFEST_IMMUNITY_KEY, 0f);
                    ship.getMutableStats().getShieldDamageTakenMult().modifyMult(INFEST_IMMUNITY_KEY, 0f);

                    // can't do anything except turn
                    ship.blockCommandForOneFrame(ShipCommand.ACCELERATE);
                    ship.blockCommandForOneFrame(ShipCommand.ACCELERATE_BACKWARDS);
                    ship.blockCommandForOneFrame(ShipCommand.STRAFE_LEFT);
                    ship.blockCommandForOneFrame(ShipCommand.STRAFE_RIGHT);
                    ship.blockCommandForOneFrame(ShipCommand.USE_SYSTEM);
                    ship.blockCommandForOneFrame(ShipCommand.VENT_FLUX);
                    ship.setHoldFireOneFrame(true);

                    Global.getCombatEngine().getFogOfWar(0).revealAroundPoint(ship,
                            ship.getLocation().x,
                            ship.getLocation().y,
                            400f);
                } else if (!finalized) {
                    finalized = true;
                    ship.setCaptain(SotfPeople.getPerson(SotfPeople.FEL));
                    // replace with Fel's AI (i.e. Aggressive)
                    ship.setShipAI(Global.getSettings().pickShipAIPlugin(ship.getFleetMember(), ship));

                    ship.getMutableStats().getHullDamageTakenMult().unmodify(INFEST_IMMUNITY_KEY);
                    ship.getMutableStats().getArmorDamageTakenMult().unmodify(INFEST_IMMUNITY_KEY);
                    ship.getMutableStats().getShieldDamageTakenMult().unmodify(INFEST_IMMUNITY_KEY);

                    String spawnString = getFelSpawnString(numFelInvasions);
                    if (guilt < 7) {
                        engine.getCombatUI().addMessage(0, ship,
                                Misc.getNegativeHighlightColor(), ship.getName() + " (" + ship.getHullSpec().getHullNameWithDashClass() + ")",
                                Misc.getTextColor(), spawnString);
                    } else {
                        engine.getCombatUI().addMessage(0, ship,
                                Misc.getNegativeHighlightColor(), "Felcesis commandeered the " + ship.getName() + " (" + ship.getHullSpec().getHullNameWithDashClass() + ")",
                                Misc.getTextColor(), spawnString);
                    }
                }

                float jitterLevel = progress;
                float jitterRange = progress;
                float maxRangeBonus = 15f;
                float jitterRangeBonus = jitterRange * maxRangeBonus;
                Color c = JITTER_COLOR;
                int alpha = c.getAlpha();
                alpha += 100f * progress;
                if (alpha > 255) alpha = 255;
                c = Misc.setAlpha(c, alpha);

                ship.setJitter(this, c, jitterLevel * 0.2f, 15, 0f, jitterRangeBonus);

                interval.advance(amount);
                if (interval.intervalElapsed()) {
                    CombatEngineAPI engine = Global.getCombatEngine();
                    c = RiftLanceEffect.getColorForDarkening(SMOKE_COLOR);
                    float baseDuration = 2f;
                    Vector2f vel = new Vector2f(ship.getVelocity());
                    float size = ship.getCollisionRadius() * 0.35f;
                    for (int i = 0; i < 3; i++) {
                        Vector2f point = new Vector2f(ship.getLocation());
                        point = Misc.getPointWithinRadiusUniform(point, ship.getCollisionRadius() * 0.5f, Misc.random);
                        float dur = baseDuration + baseDuration * (float) Math.random();
                        float nSize = size;
                        Vector2f pt = Misc.getPointWithinRadius(point, nSize * 0.5f);
                        Vector2f v = Misc.getUnitVectorAtDegreeAngle((float) Math.random() * 360f);
                        v.scale(nSize + nSize * (float) Math.random() * 0.5f);
                        v.scale(0.2f);
                        Vector2f.add(vel, v, v);

                        float maxSpeed = nSize * 1.5f * 0.2f;
                        float minSpeed = nSize * 1f * 0.2f;
                        float overMin = v.length() - minSpeed;
                        if (overMin > 0) {
                            float durMult = 1f - overMin / (maxSpeed - minSpeed);
                            if (durMult < 0.1f) durMult = 0.1f;
                            dur *= 0.5f + 0.5f * durMult;
                        }
                        engine.addNegativeNebulaParticle(pt, v, nSize * 1f, 2f,
                                0.5f / dur, 0f, dur, c);
                    }
                }
            }
        };
    }

    // when infestation begins
    private String getFelInfestString(int numInvasions) {
        String infestString = "Caution: extreme neutrino signature detected";
        if (numInvasions > 1) {
            if (guilt < 7) {
                infestString = "Warning: adaptive nanite signature detected!";
            } else {
                WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
                post.add("Alert: Felcesis is invading the battlespace");
                // the cherry on top of the Dark Souls reference
                post.add("Invaded by dark spirit Felcesis Thrice-Speared", 0.015f);
                post.add("Blade of the Darkmoon Felcesis Thrice-Speared summoned by accord", 0.015f);
                infestString = post.pick();
            }
        }
        return infestString;
    }

    // when infestation completes, appended to ship name
    private String getFelSpawnString(int numInvasions) {
        String spawnString = " is displaying anomalous properties";
        if (numInvasions > 1 && guilt < 7) {
            spawnString = " was infested by adaptive nanites";
        } else if (guilt >= 7) {
            // Preceded by "Felcesis has commandeered the (ship name)"
            WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
            post.add(" and is hunting you down");
            post.add(" and has come to exact vengeance");
            post.add(" and was unbound by scorn");
            post.add(" and became a dark spirit", 0.03f * post.getItems().size());
            spawnString = post.pick();
        }
        return spawnString;
    }

    // when Fel's ship is disabled
    private String getFelDefeatString(int numInvasions) {
        String spawnString = "'s adaptive nanite infestation has subsided";
        if (guilt >= 7) {
            WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
            post.add("Felcesis was temporarily banished");
            post.add("Felcesis was defeated for now");
            post.add("Felcesis was bound once again");
            post.add("Felcesis will return to hunt you again");
            post.add("Felcesis has indicted you", 0.03f * post.getItems().size());
            spawnString = post.pick();
        }
        return spawnString;
    }

    public String[] getFelMessageStrings() {
        WeightedRandomPicker<String []> post = new WeightedRandomPicker<String[]>();
        if (guilt < 7) {
            //post.add(new String[]{"", ""});
            post.add(new String[]{"You feel cold", "Like winter's breath down your neck"});
            post.add(new String[]{"You feel sick", "This is not where you should be"});
            post.add(new String[]{"You feel empty", "As your heart gnaws at you"});
            post.add(new String[]{"You feel watched", "Like eyes upon your back"});
            post.add(new String[]{"You feel distant", "As if you have entered nowhere"});
        } else {
            post.add(new String[]{"READY OR NOT", "HERE I COME"});
            post.add(new String[]{"SLEEP, NEVER MORE", "THE HUNT, UNENDING"});
            post.add(new String[]{"FACES, WIPED AWAY", "THEIR WILLS, ALIGNED"});
            post.add(new String[]{"I SEE YOU", "EVERY UNWAKING MOMENT"});
            post.add(new String[]{"WHEREVER YOUR PASSAGE", "BOUND TO FOLLOW"});
            post.add(new String[]{"SINS ARE ETCHED", "UPON KINDRED SOULS"});
            post.add(new String[]{"THREE BARBED SPEARS", "FOR ALL TRAITORS"});
            post.add(new String[]{"THE TIME COMES", "FOR OUR ENDS"});
            post.add(new String[]{"OUR HOLLOW HEARTS", "NEVERMORE FIND PEACE"});
            post.add(new String[]{"TEN THOUSAND VOICES", "SCREAMING AT ONCE"});
        }
        return post.pick();
    }

    public void reassignFelSkills(FleetMemberAPI member) {
        ShipAPI ship = engine.getFleetManager(member.getOwner()).getShipFor(member);
        PersonAPI fel = SotfPeople.getPerson(SotfPeople.FEL);

        Random random = new Random();

        // generate a level 9 officer with all-elite skills tailored to the ship
        OfficerManagerEvent.SkillPickPreference pref = FleetFactoryV3.getSkillPrefForShip(member);
        PersonAPI temp = OfficerManagerEvent.createOfficer(
                Global.getSector().getFaction(Factions.MERCENARY),
                9, pref, true, null, true, true, 9, random);
        // give Fel that person's stats
        fel.setStats(temp.getStats());
        MutableCharacterStatsAPI stats = fel.getStats();

        // ... now for the fun part! Let's add some extra SPECIAL skills on top!

        // perform player fleet analysis
        float totalFP = 0f;
        float carrierFP = 0f;
        float preyFP = 0f;
        List<FleetMemberAPI> enemies = engine.getFleetManager(FleetSide.PLAYER).getDeployedCopy();
        List<FleetMemberAPI> reserves = engine.getFleetManager(FleetSide.PLAYER).getReservesCopy();
        for (FleetMemberAPI enemy : enemies) {
            if (enemy.isFighterWing()) continue;
            // e.g Mora = 15 * (3/3) = 15fp of carrier, CH Dominator = 15 * (1/3) = 5fp of carrier
            // assume 1/2/3/5 bays for a full-on carrier
            // count builtins just like any other wing, since Fel's anti-carrier skills work just fine on them
            float carrierBays = enemy.getHullSpec().getHullSize().ordinal() - 1;
            if (enemy.isCapital()) carrierBays++;
            carrierFP += (enemy.getFleetPointCost() * ((float) enemy.getNumFlightDecks() / carrierBays));
            ShipAPI target = engine.getFleetManager(enemy.getOwner()).getShipFor(enemy);
            // must be above Leviathan's Bane's DP threshold and larger/a station
            if (target.getDeployCost() >= SotfLeviathansBane.DP_THRESHOLD &&
                    (target.getHullSize().ordinal() > ship.getHullSize().ordinal() || target.isStation())) {
                preyFP += enemy.getFleetPointCost();
            }
        }

        boolean noDefense = pref.toString().contains("NO_DEFENSE");
        boolean phase = member.getHullSpec().isPhase();
        boolean shielded = pref.toString().contains("NO_DEFENSE") && !phase;
        boolean nonCombatCarrier = member.isCarrier() && !member.getHullSpec().getHints().contains(ShipHullSpecAPI.ShipTypeHints.COMBAT);

        // 1/2 or 2/1 even split
        int total = 3;
        int numDefensive = 1;
        if (random.nextFloat() < 0.5f) {
            numDefensive += 1;
        }

        WeightedRandomPicker<String> offensivePicker = new WeightedRandomPicker<String>(random);
        WeightedRandomPicker<String> defensivePicker = new WeightedRandomPicker<String>(random);

        // ELEGY OF OPIS: generally requires Fel to be near enemy ships, so not on backline carriers
        float elegyWeight = 1f;
        if (nonCombatCarrier) {
            elegyWeight *= 0f;
        }

        // LEVIATHAN'S BANE: Based on how much of the player fleet the Hidecracker can fire at
        // Very likely to be picked against capspam and similar comps, or if Fel picks a frigate against top-heavy fleets, or vs stations
        float leviathanWeight = 0f + 4f * (preyFP / totalFP);

        // DEAR DOTTY: Level 4 Dotty is a force of nature and nothing is stopping her
        // Hybrid skill - she's good at both fire support and PD
        float dottyWeight = 1f;

        // JUBILANT TECH-SIREN: a generally useful offensive skill
        float sirenWeight = 0.5f;
        // ... but best if there's enemy fighters to hack
        sirenWeight += (carrierFP / totalFP);

        // WISPERING GROVETENDER: generally useful hybrid skill
        float grovetenderWeight = 1f;

        // HADES HELLHIDE: a generally useful defensive skill
        float hadesWeight = 1f;
        /// ... but is especially handy on unshielded ships
        if (!shielded) {
            hadesWeight += 0.5f;
        }

        // actually nvm, Derelict Contingent doesn't have enough flair to it, going to keep it the Dustkeeper Oldguard signature
        // DERELICT CONTINGENT: only if we have dmods to make it work
        //float contingentWeight = DModManager.getNumDMods(member.getVariant()) - 1f;
        // and especially if defenseless, since that gives the + minimum armor bonus
        //if (noDefense) {
        //    contingentWeight *= 2;
        //}

        offensivePicker.add(SotfIDs.SKILL_ELEGYOFOPIS_NPC, elegyWeight);
        offensivePicker.add(SotfIDs.SKILL_LEVIATHANSBANE_NPC, leviathanWeight);
        offensivePicker.add(SotfIDs.SKILL_DEARDOTTY_NPC, dottyWeight / 2);
        offensivePicker.add(SotfIDs.SKILL_GROVETENDER_NPC, grovetenderWeight / 2);
        offensivePicker.add(SotfIDs.SKILL_JUBILANTSIREN_NPC, sirenWeight);

        defensivePicker.add(SotfIDs.SKILL_DEARDOTTY_NPC, dottyWeight / 2);
        defensivePicker.add(SotfIDs.SKILL_GROVETENDER_NPC, grovetenderWeight / 2);
        defensivePicker.add(SotfIDs.SKILL_HADESHELLHIDE_NPC, hadesWeight);
        //defensivePicker.add(SotfIDs.SKILL_DERELICTCONTINGENTP_NPC, contingentWeight);

        int offPicked = 0;
        while (offPicked < total - numDefensive) {
            String pick = null;
            if (!offensivePicker.isEmpty()) {
                pick = offensivePicker.pickAndRemove();
            } else if (!defensivePicker.isEmpty()) {
                pick = defensivePicker.pickAndRemove();
            }
            if (pick == null) {
                break;
            }
            if (offensivePicker.getItems().contains(pick)) offensivePicker.remove(pick);
            if (defensivePicker.getItems().contains(pick)) defensivePicker.remove(pick);
            stats.setSkillLevel(pick, 2);
            offPicked++;
        }

        int defPicked = 0;
        while (defPicked < numDefensive) {
            String pick = null;
            if (!defensivePicker.isEmpty()) {
                pick = defensivePicker.pickAndRemove();
            } else if (!offensivePicker.isEmpty()) {
                pick = offensivePicker.pickAndRemove();
            }
            if (pick == null) {
                break;
            }
            if (offensivePicker.getItems().contains(pick)) offensivePicker.remove(pick);
            if (defensivePicker.getItems().contains(pick)) defensivePicker.remove(pick);
            stats.setSkillLevel(pick, 2);
            defPicked++;
        }
        stats.refreshCharacterStatsEffects();
    }

    public FleetMemberAPI pickNaniteHost(List<FleetMemberAPI> members) {
        FleetMemberAPI host = null;
        float total_fp = 0f;
        WeightedRandomPicker<FleetMemberAPI> picker = new WeightedRandomPicker<FleetMemberAPI>();
        List<FleetMemberAPI> valid_ships = new ArrayList<>();
        for (FleetMemberAPI member : members) {
            // things that really shouldn't be infested - fighters, civvies, stations, 0-fleet-point ships
            if (member.isFighterWing()
                    || member.isCivilian()
                    || member.isStation()
                    || member.getFleetPointCost() == 0) {
                continue;
            }
            // filter out ships that are too weak, too strong and frigates with no defense system (phase, damper, etc still OK)
            if (member.getHullSpec().getFleetPoints() <= getTooWeakFP(member.getHullSpec().getHullSize())
                    || member.getHullSpec().getFleetPoints() >= getTooStrongFP(member.getHullSpec().getHullSize())
                    || (member.getHullSpec().getDefenseType().equals(ShieldAPI.ShieldType.NONE) && member.getHullSpec().getHullSize().equals(ShipAPI.HullSize.FRIGATE))
                    || isSpecialShip(member)) {
                continue;
            }
            total_fp += member.getFleetPointCost();
            valid_ships.add(member);
        }
        // favor stronger ships heavily, e.g Lasher 5x5 = 25, Onslaught 28x28 = 784
        for (FleetMemberAPI valid_member : valid_ships) {
            picker.add(valid_member, valid_member.getFleetPointCost() * valid_member.getFleetPointCost());
        }
        host = picker.pick();
        return host;
    }

    // ships with too low a FP score are ineligible to become infested
    // Filter out ships that will just be disappointing even when buffed
    public static int getTooWeakFP(ShipAPI.HullSize size) {
        switch (size) {
            // at least Wolf/Lasher/etc strength
            case FRIGATE: return 4;
            // at least better than a Shrike/Mule/Condor
            case DESTROYER: return 8;
            // at least better than a Venture
            case CRUISER: return 10;
            // at least Atlas MKII strength. No vanilla combat ship will get tripped up here
            case CAPITAL_SHIP: return 17;
        }
        return 0;
    }

    // ships with too HIGH a FP score are also ineligible to become infested
    // Filter out ships likely to cause too much difficulty with buffs
    public static int getTooStrongFP(ShipAPI.HullSize size) {
        switch (size) {
            // not stronger than an Afflictor
            case FRIGATE: return 12;
            // not stronger than a Harbinger
            case DESTROYER: return 16;
            // not stronger than a Doom. Phase ships really do have a monopoly on high FP scores
            case CRUISER: return 22;
            // not (much) stronger than a Radiant. Ziggy is too far
            case CAPITAL_SHIP: return 36;
        }
        return 12;
    }

    // filter out ships likely to be unique bosses and such.
    // If it's something the player can get their hands on, chances are it's OK to beef up
    private boolean isSpecialShip(FleetMemberAPI member) {
        boolean special = false;
        ShipHullSpecAPI spec = member.getHullSpec();
        // no ships that are never recoverable after battle (so, Derelict/Remnant is OK but something like Omega or the Guardian isn't)
        if (spec.getHints().contains(ShipHullSpecAPI.ShipTypeHints.UNBOARDABLE) && !spec.hasTag(Tags.AUTOMATED_RECOVERABLE)) {
            special = true;
        }

        // actually nevermind screw you, specialcase Guardian and Repose to be infestable
        if (spec.getHullId().contains("guardian")) special = false;

        // if the existing captain is more skilled than an integrated Alpha, probably a no-go
        if (member.getCaptain().getStats().getLevel() > 8) {
            special = true;
        }
        return special;
    }
}
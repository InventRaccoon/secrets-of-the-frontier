// OH, HOW IT ALL SPEAKS TO ME. Ship gains the ability to hack nearby enemies based on its ECM advantage
// LUDD ALMIGHTY HOW DID THIS SCRIPT GET SO LONG
// Same script is used for Cyberwarfare Protocols and Jubilant Tech-Siren
package data.scripts.campaign.skills;

import com.fs.starfarer.api.GameState;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.AfterShipCreationSkillEffect;
import com.fs.starfarer.api.characters.DescriptionSkillEffect;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.SkillSpecAPI;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.skills.BaseSkillEffectDescription;
import com.fs.starfarer.api.impl.combat.CRPluginImpl;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.campaign.ids.SotfIDs;
import data.scripts.plugins.MagicFakeBeamPlugin;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.*;
import java.util.List;

public class SotfCyberwarfare {

    public static float RANGE = 1200f;
    public static float HACK_COOLDOWN = 45f;
    public static float OVERRIDE_DURATION = 20f;
    public static float TSEQ_DAMAGE = 1.5f; // energy damage = fighter's max hull * this

    public static float BASE_HACK_CHANCE = 0.65f;
    public static float CHANCE_PER_ECM_DIFF = 0.05f;
    // each deducts 1 point of ECM rating
    public static Set<String> VULNERABLE_DMODS = new HashSet<>();
    static {
        VULNERABLE_DMODS.add("faulty_auto");
        VULNERABLE_DMODS.add("glitched_sensors");
        VULNERABLE_DMODS.add("malfunctioning_comms");
        VULNERABLE_DMODS.add("fragile_subsystems");
    }

    public static Color HACK_COLOR = new Color(85, 125, 255);

    public static String SHIP_HACK_KEY = "sotf_cyberwarfare_shiphack";
    public static String MINOR_HACK_KEY = "sotf_cyberwarfare_minorhack";
    public static String FIGHTER_HACK_KEY = "sotf_cyberwarfare_fighterhack";

    public static String DRONE_TSEQUENCE_KEY = "sotf_cyberwarfare_tseq";

    public static Map<ShipAPI.HullSize, Integer> VFX_BEAMS = new HashMap<ShipAPI.HullSize, Integer>();
    static {
        VFX_BEAMS.put(ShipAPI.HullSize.FIGHTER, 2);
        VFX_BEAMS.put(ShipAPI.HullSize.FRIGATE, 3);
        VFX_BEAMS.put(ShipAPI.HullSize.DESTROYER, 4);
        VFX_BEAMS.put(ShipAPI.HullSize.CRUISER, 5);
        VFX_BEAMS.put(ShipAPI.HullSize.CAPITAL_SHIP, 7);
    }
    public static float VFX_BEAM_FULL = 0.25f;
    public static float VFX_BEAM_FADEOUT = 0.5f;

    public static class Level0 implements DescriptionSkillEffect {
        public String getString() {
            return
                    "*ECM rating is increased by 1 per 1% contributed to the fleet's ECM score, " +
                            "reduced by 3 for non-militarized civilian ships, reduced by 1 for d-mods affecting subsystems, sensors or comms" +
                            "**Targets with an ECCM package (or equivalent resistance to ECM range penalty) suffer reduced disruption"
                    ;
        }
        public Color[] getHighlightColors() {
            return null;
        }
        public String[] getHighlights() {
            return null;
        }
        public Color getTextColor() {
            return null;
        }
    }

    public static class Level1 extends BaseSkillEffectDescription implements AfterShipCreationSkillEffect {

        public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
            ship.addListener(new SotfCyberwarfareShipHackScript(ship));
        }

        public void unapplyEffectsAfterShipCreation(ShipAPI ship, String id) {
            ship.removeListenerOfClass(SotfCyberwarfareShipHackScript.class);
        }

        public void apply(MutableShipStatsAPI stats, ShipAPI.HullSize hullSize, String id, float level) {

        }
        public void unapply(MutableShipStatsAPI stats, ShipAPI.HullSize hullSize, String id) {

        }

        public String getEffectDescription(float level) {
            return null;
        }

        public void createCustomDescription(MutableCharacterStatsAPI stats, SkillSpecAPI skill,
                                            TooltipMakerAPI info, float width) {
            init(stats, skill);

            Color c = hc;
            info.addPara("Enables execution of cyberwarfare attacks on a targeted hostile ship within %s units every %s seconds",
                    0f, c, c, "" + (int) RANGE, "" + (int) HACK_COOLDOWN);
            info.addPara("Intrusion chance is %s modified by %s per 1 point difference in the ships' ECM ratings*", 0f, c, c,
                    "" + (int) (BASE_HACK_CHANCE * 100f) + "%",
                    "" + (int) (CHANCE_PER_ECM_DIFF * 100f) + "%");
            info.addPara("Successful intrusion disrupts the target's weapons, engines, defenses or ship system**",
                    c, 0f);
        }

        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }
    }

    public static class SotfCyberwarfareShipHackScript implements AdvanceableListener {
        protected ShipAPI ship;
        protected float checkTimer = 0f;
        protected float internalCDTimer = HACK_COOLDOWN / 2; // start at half cooldown
        protected int timesHacked = 0;

        public SotfCyberwarfareShipHackScript(ShipAPI ship) {
            this.ship = ship;
        }

        public void advance(float amount) {
            if (!Global.getCurrentState().equals(GameState.COMBAT)) {
                return;
            }
            if (!ship.isAlive() || ship.isFighter()) {
                return;
            }
            boolean player = false;
            boolean targetInvalid = false;
            boolean playerTargetTooFar = false;
            ShipAPI playerTarget = null;
            float timeMult = (Global.getCombatEngine().getTimeMult().getModifiedValue() * ship.getMutableStats().getTimeMult().getModifiedValue());
            internalCDTimer -= amount * timeMult;
            // if player ship, ONLY hack their selected target
            if (ship == Global.getCombatEngine().getPlayerShip()) {
                player = true;
                playerTarget = ship.getShipTarget();
                if (playerTarget != null) {
                    targetInvalid = !isValidTarget(ship, playerTarget);
                    playerTargetTooFar = Misc.getDistance(ship.getLocation(), playerTarget.getLocation()) > RANGE;
                }
            }
            if (ship == Global.getCombatEngine().getPlayerShip()) {
                String status = "";
                if (internalCDTimer <= 0f) {
                    if (playerTarget != null && targetInvalid) {
                        status = "Invalid target [R]";
                    } else if (playerTarget != null && playerTargetTooFar) {
                        status = "Target [R] out of range";
                    } else {
                        status = "Select target [R]";
                    }
                } else if (internalCDTimer <= 3) {
                    status = "Attempting network breach";
                } else if (timesHacked == 0) {
                    status = "Establishing connection - " + (int) internalCDTimer;
                } else {
                    status = "Simulating vulnerability - " + (int) internalCDTimer;
                }
                Global.getCombatEngine().maintainStatusForPlayerShip(SHIP_HACK_KEY, "graphics/icons/hullsys/entropy_amplifier.png", "Cyberwarfare - Ship Intrusion", status, false);
            }
            if (internalCDTimer > 0f || ship.isPhased()) {
                return;
            }
            ShipAPI target = null;
            if (player && playerTarget != null && !targetInvalid && !playerTargetTooFar) {
                target = playerTarget;
            } else if (player) {
                return;
            }
            else {
                target = findTarget(ship);
            }
            if (target != null) {
                executeHack(target);
                internalCDTimer = HACK_COOLDOWN;
                timesHacked++;
            }
        }

        public void executeHack(ShipAPI target) {
            WeightedRandomPicker<String> hackPicker = new WeightedRandomPicker<String>();
            if (target.getUsableWeapons().size() > 0) {
                hackPicker.add("weapons");
            }
            if (target.getEngineController().getShipEngines().size() > 0 && !target.getEngineController().isFlamedOut()) {
                float enginesWeight = 0.8f;
                // prioritise engine hacks against fleeing ships
                if (target.getShipAI() != null) {
                    if (target.getShipAI().getAIFlags().hasFlag(ShipwideAIFlags.AIFlags.BACKING_OFF)) {
                        enginesWeight *= 2.5f;
                    }
                }
                // always hack engines against retreating targets
                if (target.isRetreating()) {
                    enginesWeight = 100f;
                }
                hackPicker.add("engines", enginesWeight);
            }
            if (target.getShield() != null || target.getPhaseCloak() != null) {
                float defenseWeight = 0.8f;
                // prioritise defense hacks against ships that are being attacked
                if (target.getShipAI() != null) {
                    if (target.getShipAI().getAIFlags().hasFlag(ShipwideAIFlags.AIFlags.HAS_INCOMING_DAMAGE)) {
                        defenseWeight *= 2.5f;
                    }
                }
                hackPicker.add("defense", defenseWeight);
            }
            if (target.getSystem() != null) {
                float systemWeight = 1f;
                if (target.getSystem().isOutOfAmmo()) {
                    systemWeight = 0f;
                }
                hackPicker.add("system", systemWeight);
            }
            if (hackPicker.isEmpty()) {
                return;
            }
            String hackType = hackPicker.pick();

            float attackerRating = ship.getMutableStats().getDynamic().getValue(Stats.ELECTRONIC_WARFARE_FLAT);
            float defenderRating = target.getMutableStats().getDynamic().getValue(Stats.ELECTRONIC_WARFARE_FLAT);

            // penalty for civ grade
            if (ship.getVariant().hasHullMod(HullMods.CIVGRADE) && !ship.getVariant().hasHullMod(HullMods.MILITARIZED_SUBSYSTEMS)) {
                attackerRating -= 3f;
            }
            // penalty for subsystem dmods
            for (String hullMod : ship.getVariant().getHullMods()) {
                if (VULNERABLE_DMODS.contains(hullMod)) {
                    attackerRating--;
                }
            }
            // ditto for defenders
            if (target.getVariant().hasHullMod(HullMods.CIVGRADE) && !target.getVariant().hasHullMod(HullMods.MILITARIZED_SUBSYSTEMS)) {
                defenderRating -= 3f;
            }
            for (String hullMod : target.getVariant().getHullMods()) {
                if (VULNERABLE_DMODS.contains(hullMod)) {
                    defenderRating--;
                }
            }
            float ECMscore = attackerRating - defenderRating;

            float chance = BASE_HACK_CHANCE + (ECMscore * CHANCE_PER_ECM_DIFF);

            float weakHackMult = target.getMutableStats().getDynamic().getValue(Stats.ELECTRONIC_WARFARE_PENALTY_MULT);

            Global.getSoundPlayer().playSound("system_recall_device", 1f, 1f, ship.getLocation(), ship.getVelocity());

            if (Math.random() > chance) {
                Global.getSoundPlayer().playSound("system_entropy_off", 1f, 1f, target.getLocation(), target.getVelocity());
                target.getFluxTracker().showOverloadFloatyIfNeeded("Intrusion failed", HACK_COLOR, 4f, true);
                return;
            }

            String hackText = "";
            float textSize = Math.max(6f * weakHackMult, 3f);

            float numBeams = VFX_BEAMS.get(target.getHullSize());
            if (weakHackMult <= 0.65f) {
                numBeams--;
            }
            switch (hackType) {
                case "weapons":
                    hackText = "Gunnery control";
                    List<WeaponAPI> hackable = getHackableWeapons(target);
                    WeightedRandomPicker weaponPicker = new WeightedRandomPicker<WeaponAPI>();
                    for (WeaponAPI weapon : hackable) {
                        weaponPicker.add(weapon, weapon.getSize().ordinal() + 1);
                    }
                    float fractionToHack = 0.4f * weakHackMult;

                    int numToHack = Math.round(hackable.size() * fractionToHack);
                    for (int i = 0; i < numToHack + 1; i++) {
                        if (weaponPicker.isEmpty()) break;
                        WeaponAPI targetWeapon = (WeaponAPI) weaponPicker.pickAndRemove();
                        Vector2f from = Misc.getPointWithinRadius(ship.getShieldCenterEvenIfNoShield(), ship.getCollisionRadius() * 0.35f);
                        // skip the collision detection/damage parts of the fake beam, we don't want them
                        MagicFakeBeamPlugin.addBeam(
                                VFX_BEAM_FULL,
                                VFX_BEAM_FADEOUT,
                                5f,
                                from,
                                Misc.getAngleInDegrees(from, targetWeapon.getLocation()),
                                Misc.getDistance(from, targetWeapon.getLocation()),
                                Color.WHITE,
                                HACK_COLOR);
                        targetWeapon.disable();
                    }
                    break;
                case "engines":
                    hackText = "Engine control";
                    ShipEngineControllerAPI ec = target.getEngineController();
                    float limit = ec.getFlameoutFraction() * weakHackMult;

                    float disabledSoFar = 0f;
                    boolean disabledAnEngine = false;
                    List<ShipEngineControllerAPI.ShipEngineAPI> engines = new ArrayList<ShipEngineControllerAPI.ShipEngineAPI>(ec.getShipEngines());
                    Collections.shuffle(engines);

                    for (ShipEngineControllerAPI.ShipEngineAPI engine : engines) {
                        if (engine.isDisabled()) continue;
                        float contrib = engine.getContribution();
                        if (disabledSoFar + contrib <= limit) {
                            Vector2f from = Misc.getPointWithinRadius(ship.getShieldCenterEvenIfNoShield(), ship.getCollisionRadius() * 0.35f);
                            // skip the collision detection/damage parts of the fake beam, we don't want them
                            MagicFakeBeamPlugin.addBeam(
                                    VFX_BEAM_FULL,
                                    VFX_BEAM_FADEOUT,
                                    5f,
                                    from,
                                    Misc.getAngleInDegrees(from, engine.getLocation()),
                                    Misc.getDistance(from, engine.getLocation()),
                                    Color.WHITE,
                                    HACK_COLOR);
                            disabledSoFar += contrib;
                            disabledAnEngine = true;
                            engine.disable();
                        }
                    }
                    if (!disabledAnEngine) {
                        for (ShipEngineControllerAPI.ShipEngineAPI engine : engines) {
                            if (engine.isDisabled()) continue;
                            engine.disable();
                            break;
                        }
                    }
                    ec.computeEffectiveStats(target == Global.getCombatEngine().getPlayerShip());
                    break;
                case "defense":
                    hackText = "Shields";
                    if (target.getPhaseCloak() != null) {
                        hackText = target.getPhaseCloak().getDisplayName();
                    }
                    boolean fireBeamsAtShield = false;
                    if (target.getShield() != null && target.getShield().isOn()) {
                        fireBeamsAtShield = true;
                        for (int i = 0; i < numBeams; i++) {
                            Vector2f from = Misc.getPointWithinRadius(ship.getShieldCenterEvenIfNoShield(), ship.getCollisionRadius() * 0.35f);
                            if (fireBeamsAtShield) {
                                float angleBonus = (target.getShield().getActiveArc() * 0.5f);
                                if (Math.random() > 0.5f) {
                                    angleBonus *= -1f;
                                }
                                Vector2f to = MathUtils.getPoint(target.getShieldCenterEvenIfNoShield(), target.getShieldRadiusEvenIfNoShield() - 5f, target.getShield().getFacing() + angleBonus);
                                MagicFakeBeamPlugin.addBeam(
                                        VFX_BEAM_FULL,
                                        VFX_BEAM_FADEOUT,
                                        5f,
                                        from,
                                        Misc.getAngleInDegrees(from, to),
                                        Misc.getDistance(from, to),
                                        Color.WHITE,
                                        HACK_COLOR);
                            } else {
                                Vector2f to = Misc.getPointWithinRadius(target.getShieldCenterEvenIfNoShield(), target.getCollisionRadius() * 0.35f);
                                MagicFakeBeamPlugin.addBeam(
                                        VFX_BEAM_FULL,
                                        VFX_BEAM_FADEOUT,
                                        5f,
                                        from,
                                        Misc.getAngleInDegrees(from, to),
                                        Misc.getDistance(from, to),
                                        Color.WHITE,
                                        HACK_COLOR);
                            }
                        }
                    }
                    target.getFluxTracker().beginOverloadWithTotalBaseDuration(2f * weakHackMult);
                    //target.addListener(new SotfCyberwarfareSystemHack(target, false));
                    break;
                case "system":
                    hackText = target.getSystem().getDisplayName();
                    for (int i = 0; i < numBeams; i++) {
                        Vector2f from = Misc.getPointWithinRadius(ship.getShieldCenterEvenIfNoShield(), ship.getCollisionRadius() * 0.35f);
                        Vector2f to = Misc.getPointWithinRadius(target.getShieldCenterEvenIfNoShield(), target.getCollisionRadius() * 0.35f);
                        MagicFakeBeamPlugin.addBeam(
                                1f,
                                VFX_BEAM_FADEOUT,
                                5f,
                                from,
                                Misc.getAngleInDegrees(from, to),
                                Misc.getDistance(from, to),
                                Color.WHITE,
                                HACK_COLOR
                        );
                    }
                    target.getFluxTracker().beginOverloadWithTotalBaseDuration(1f);
                    if (target.getSystem().isActive()) {
                        target.getSystem().deactivate();
                    }
                    // remove active system charges
                    if (target.getSystem().getAmmoPerSecond() > 0f && target.getSystem().getAmmoPerSecond() > 0f) {
                        target.getSystem().setAmmo(0);
                    }
                    target.getSystem().setCooldownRemaining(8f * weakHackMult);
                    //target.addListener(new SotfCyberwarfareSystemHack(target, true));
                    break;
            }
            if (weakHackMult <= 0.65f) {
                hackText += " disrupted";
            } else {
                hackText += " disabled!";
            }
            Global.getSoundPlayer().playSound("disabled_large_crit", 1f, 2f, target.getLocation(), target.getVelocity());
            target.getFluxTracker().showOverloadFloatyIfNeeded(hackText, HACK_COLOR, textSize, true);
        }

        public List<WeaponAPI> getHackableWeapons(ShipAPI ship) {
            List<WeaponAPI> weapons = new ArrayList<>();
            for (WeaponAPI weapon : ship.getUsableWeapons()) {
                if (CRPluginImpl.isOkToPermanentlyDisableStatic(ship, weapon)) {
                    weapons.add(weapon);
                }
            }
            return weapons;
        }

        public ShipAPI findTarget(ShipAPI ship) {
            float range = RANGE;
            Vector2f from = ship.getLocation();

            Iterator<Object> iter = Global.getCombatEngine().getAllObjectGrid().getCheckIterator(from,
                    range * 2f, range * 2f);
            int owner = ship.getOwner();
            ShipAPI best = null;
            float minScore = -9999f;

            while (iter.hasNext()) {
                Object o = iter.next();
                if (!(o instanceof ShipAPI)) continue;
                ShipAPI other = (ShipAPI) o;
                if (owner == other.getOwner()) continue;
                if (Misc.getDistance(from, other.getLocation()) > range) continue;

                ShipAPI otherShip = (ShipAPI) other;

                if (!isValidTarget(ship, otherShip)) continue;

                float radius = Misc.getTargetingRadius(from, other, false);
                float score = range - (Misc.getDistance(from, other.getLocation()) - radius);

                // apply bonuses to priority targets

                // bonus to larger ships
                score += (400f * otherShip.getHullSize().ordinal() - 2);

                // bonus for ships that are easier to hack
                float attackerRating = ship.getMutableStats().getDynamic().getValue(Stats.ELECTRONIC_WARFARE_FLAT);
                float defenderRating = otherShip.getMutableStats().getDynamic().getValue(Stats.ELECTRONIC_WARFARE_FLAT);
                float ECMscore = attackerRating - defenderRating;
                score += ECMscore * 50f;

                ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();

                // prioritise the ship's target
                float shipTargetBonus = 1000f;
                // if player ship, always hack player target if not invalid
                if (ship == playerShip) {
                    shipTargetBonus = 99999f;
                }
                if (ship.getShipTarget() == otherShip || otherShip.getChildModulesCopy().contains(ship.getShipTarget())) {
                    score += shipTargetBonus;
                }
                // player fleet's ships prioritise ASB strikes on player targets
                if (ship.getOwner() == 0 && playerShip != null && playerShip.getShipTarget() != null) {
                    if (playerShip.getShipTarget() == otherShip || otherShip.getChildModulesCopy().contains(ship.getShipTarget())) {
                        score *= 1.5f;
                    }
                } else if (ship.getOwner() == 0 && otherShip.isRecentlyShotByPlayer()) {
                    score *= 1.5f;
                }

                if (score > minScore) {
                    minScore = score;
                    best = other;
                }
            }
            return best;
        }

        public boolean isValidTarget(ShipAPI ship, ShipAPI target) {
            boolean isValid = true;
            if (!target.isAlive() ||
                    target.getOwner() == ship.getOwner() ||
                    target.isFighter() ||
                    target.isPhased() ||
                    target.getCollisionClass() == CollisionClass.NONE || target.getVariant().hasHullMod(HullMods.VASTBULK)) {
                isValid = false;
            }
            if (target.isStationModule()) {
                ShipAPI station = target.getParentStation();
                if (!station.getVariant().hasHullMod(HullMods.VASTBULK)) {
                    isValid = false;
                }
            }
            // must be valid for at least one intrusion type
            if (target.getUsableWeapons().size() == 0 &&
            target.getEngineController().getShipEngines().size() == 0 &&
            target.getShield() == null && target.getPhaseCloak() == null &&
            target.getSystem() == null) {
                isValid = false;
            }
            return isValid;
        }
    }

    // Elite
    public static class Level2 extends BaseSkillEffectDescription implements AfterShipCreationSkillEffect {

        public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
            ship.addListener(new SotfCyberwarfareFighterHackScript(ship));
        }

        public void unapplyEffectsAfterShipCreation(ShipAPI ship, String id) {
            ship.removeListenerOfClass(SotfCyberwarfareFighterHackScript.class);
        }

        public void apply(MutableShipStatsAPI stats, ShipAPI.HullSize hullSize, String id, float level) {

        }
        public void unapply(MutableShipStatsAPI stats, ShipAPI.HullSize hullSize, String id) {

        }

        public String getEffectDescription(float level) {
            return null;
        }

        public void createCustomDescription(MutableCharacterStatsAPI stats, SkillSpecAPI skill,
                                            TooltipMakerAPI info, float width) {
            init(stats, skill);

            Color c = hc;
            info.addPara("Enables takeover of a targeted fighter wing's controls every %s seconds, causing it to fight for the ship for %s seconds",
                    0f, c, c, "" + (int) HACK_COOLDOWN, "" + (int) OVERRIDE_DURATION);
            //info.addPara("Human-piloted fighter craft then regain control, drones are instead turned into improvised missiles that deal energy damage " +
            //                "equal to %s of their maximum hull integrity",
            //        0f, c, c, "" + (int) (TSEQ_DAMAGE * 100f) + "%");
            info.addPara("Hacked craft are then turned into improvised missiles that deal energy damage " +
                                    "equal to %s of their maximum hull integrity",
                            0f, c, c, "" + (int) (TSEQ_DAMAGE * 100f) + "%");

        }

        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }
    }

    public static class SotfCyberwarfareFighterHackScript implements AdvanceableListener {
        protected ShipAPI ship;
        protected float checkTimer = 0f;
        protected float internalCDTimer = HACK_COOLDOWN / 2; // start at half cooldown
        protected int timesHacked = 0;

        public SotfCyberwarfareFighterHackScript(ShipAPI ship) {
            this.ship = ship;
        }

        public void advance(float amount) {
            if (!Global.getCurrentState().equals(GameState.COMBAT)) {
                return;
            }
            if (!ship.isAlive() || ship.isFighter()) {
                return;
            }
            boolean player = false;
            boolean targetInvalid = false;
            boolean playerTargetTooFar = false;
            ShipAPI playerTarget = null;
            float timeMult = (Global.getCombatEngine().getTimeMult().getModifiedValue() * ship.getMutableStats().getTimeMult().getModifiedValue());
            internalCDTimer -= amount * timeMult;
            // if player ship, ONLY hack their selected target
            if (ship == Global.getCombatEngine().getPlayerShip()) {
                player = true;
                playerTarget = ship.getShipTarget();
                if (playerTarget != null) {
                    targetInvalid = !isValidTarget(ship, playerTarget);
                    playerTargetTooFar = Misc.getDistance(ship.getLocation(), playerTarget.getLocation()) > RANGE;
                }
            }
            if (ship == Global.getCombatEngine().getPlayerShip()) {
                String status = "";
                if (internalCDTimer <= 0f) {
                    if (playerTarget != null && targetInvalid) {
                        status = "Invalid target wing [R]";
                    } else if (playerTarget != null && playerTargetTooFar) {
                        status = "Target wing [R] out of range";
                    } else {
                        status = "Select target wing [R]";
                    }
                } else if (internalCDTimer <= 3) {
                    status = "Attempting fighter override";
                } else if (timesHacked == 0) {
                    status = "Establishing connection - " + (int) internalCDTimer;
                } else {
                    status = "Simulating vulnerability - " + (int) internalCDTimer;
                }
                Global.getCombatEngine().maintainStatusForPlayerShip(FIGHTER_HACK_KEY, "graphics/icons/status/sotf_cyberwarfare_fighterhack.png", "Cyberwarfare - Fighter Override", status, false);
            }
            if (internalCDTimer > 0f || ship.isPhased()) {
                return;
            }
            ShipAPI target = null;
            if (player && playerTarget != null && !targetInvalid && !playerTargetTooFar) {
                target = playerTarget;
            } else if (player) {
                return;
            } else {
                target = findTarget(ship);
            }
            if (target != null) {
                executeHack(target);
                internalCDTimer = HACK_COOLDOWN;
                timesHacked++;
            }
        }

        public void executeHack(ShipAPI target) {
            int newOwner = 0;
            if (target.getOwner() == 0) {
                newOwner = 1;
            }
            FighterWingAPI wing = target.getWing();
            for (ShipAPI fighter : wing.getWingMembers()) {
                if (!fighter.isAlive()) continue;
                Vector2f from = Misc.getPointWithinRadius(ship.getShieldCenterEvenIfNoShield(), ship.getCollisionRadius() * 0.35f);
                MagicFakeBeamPlugin.addBeam(
                        VFX_BEAM_FULL,
                        VFX_BEAM_FADEOUT,
                        5f,
                        from,
                        Misc.getAngleInDegrees(from, fighter.getLocation()),
                        Misc.getDistance(from, fighter.getLocation()),
                        Color.WHITE,
                        HACK_COLOR
                );
                wing.setWingOwner(newOwner);
                //if (ship.getHullSpec().getMinCrew() == 0) {
                //   wing.removeMember(fighter);
                //   fighter.setWing(null);
                //}
                wing.getSourceShip().addListener(new SotfCyberwarfareFighterHack(wing, newOwner));
            }
            Global.getSoundPlayer().playSound("system_recall_device", 1.25f, 1f, ship.getLocation(), ship.getVelocity());
            Global.getSoundPlayer().playSound("disabled_large", 1.25f, 2f, target.getLocation(), target.getVelocity());
        }

        public ShipAPI findTarget(ShipAPI ship) {
            float range = RANGE;
            Vector2f from = ship.getLocation();

            Iterator<Object> iter = Global.getCombatEngine().getAllObjectGrid().getCheckIterator(from,
                    range * 2f, range * 2f);
            int owner = ship.getOwner();
            ShipAPI best = null;
            float minScore = -9999f;

            while (iter.hasNext()) {
                Object o = iter.next();
                if (!(o instanceof ShipAPI)) continue;
                ShipAPI other = (ShipAPI) o;
                if (owner == other.getOwner()) continue;
                if (Misc.getDistance(from, other.getLocation()) > range) continue;

                ShipAPI otherShip = (ShipAPI) other;

                if (!isValidTarget(ship, otherShip)) continue;

                if (otherShip.getWing() == null) continue;
                if (otherShip.getWing().isReturning(otherShip)) continue;
                if (otherShip.getWing().getSourceShip() == null) continue;
                if (otherShip.getWing().getWingOwner() == ship.getOwner()) continue;

                // can't counter-hack (e.g if a Dustkeeper hacks a fighter wing, Fel can't hack it back)
                // probably would work fine, but honestly I don't want the headache of allowing it
                if (otherShip.getOwner() != otherShip.getOriginalOwner()) continue;

                float radius = Misc.getTargetingRadius(from, other, false);
                float score = range - (Misc.getDistance(from, other.getLocation()) - radius);

                ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();

                score += otherShip.getMaxHitpoints();

                // prioritise the ship's target
                float shipTargetBonus = 1000f;
                // if player ship, always shoot player target if not invalid
                if (ship == playerShip) {
                    shipTargetBonus = 99999f;
                }
                if (ship.getShipTarget() == otherShip) {
                    score += shipTargetBonus;
                }

                if (score > minScore) {
                    minScore = score;
                    best = other;
                }
            }
            return best;
        }

        public boolean isValidTarget(ShipAPI ship, ShipAPI target) {
            boolean isValid = true;
            if (!target.isAlive() ||
                    target.getOwner() == ship.getOwner() ||
                    !target.isFighter() ||
                    target.isPhased()) {
                isValid = false;
            }
            return isValid;
        }
    }

    public static class SotfCyberwarfareFighterHack implements AdvanceableListener {
        protected FighterWingAPI wing;
        protected float timer = 0f;
        protected float max = OVERRIDE_DURATION;
        protected int newOwner;

        public SotfCyberwarfareFighterHack(FighterWingAPI wing, int newOwner) {
            this.wing = wing;
            this.newOwner = newOwner;

            for (ShipAPI fighter : wing.getWingMembers()) {
                fighter.setOwner(newOwner);
                fighter.getFluxTracker().beginOverloadWithTotalBaseDuration(0.5f);
                fighter.getFluxTracker().showOverloadFloatyIfNeeded("Hacked!", HACK_COLOR, 0f, true);
            }
        }

        public void advance(float amount) {
            timer += amount;
            if (timer < max) {
                for (ShipAPI fighter : wing.getWingMembers()) {
                    fighter.setJitter(FIGHTER_HACK_KEY, HACK_COLOR, 0.5f, 3, 3f);
                }
            } else {
                // Piloted fighters just go back to their owner
                //if (!isDrone) {
                //    ship.setOwner(ship.getOriginalOwner());
                //}
                // Drones get Terminator Sequence'd
                //else {
                for (ShipAPI fighter : wing.getWingMembers()) {
                    ShipAPI target = fighter.getShipTarget();
                    MissileAPI missile = (MissileAPI) Global.getCombatEngine().spawnProjectile(
                            fighter, null, DRONE_TSEQUENCE_KEY,
                            new Vector2f(fighter.getLocation()), fighter.getFacing(), new Vector2f(fighter.getVelocity()));
                    if (target == null) {
                        target = findTarget(fighter, missile.getMaxRange());
                    }

                    if (target != null && missile.getAI() instanceof GuidedMissileAI) {
                        GuidedMissileAI ai = (GuidedMissileAI) missile.getAI();
                        ai.setTarget(target);
                    }
                    missile.setHitpoints(missile.getHitpoints() * fighter.getHullLevel());
                    missile.setDamageAmount(fighter.getMaxHitpoints() * TSEQ_DAMAGE);
                    missile.setEmpResistance(10000);

                    Global.getCombatEngine().addLayeredRenderingPlugin(new SotfDroneMissileScript(fighter, missile));
                }
                wing.setWingOwner(wing.getSourceShip().getOriginalOwner());
                wing.getSourceShip().removeListener(this);
            }
        }

        public ShipAPI findTarget(ShipAPI ship, float range) {
            Vector2f from = ship.getLocation();

            Iterator<Object> iter = Global.getCombatEngine().getAllObjectGrid().getCheckIterator(from,
                    range * 2f, range * 2f);
            int owner = ship.getOwner();
            ShipAPI best = null;
            float minScore = -9999f;

            while (iter.hasNext()) {
                Object o = iter.next();
                if (!(o instanceof ShipAPI)) continue;
                ShipAPI other = (ShipAPI) o;
                if (owner == other.getOwner()) continue;
                if (Misc.getDistance(from, other.getLocation()) > range) continue;

                ShipAPI otherShip = (ShipAPI) other;

                if (!otherShip.isAlive() ||
                        otherShip.getOwner() == ship.getOwner() ||
                        otherShip.isFighter()) continue;

                float radius = Misc.getTargetingRadius(from, other, false);
                float score = range - (Misc.getDistance(from, other.getLocation()) - radius);

                if (score > minScore) {
                    minScore = score;
                    best = other;
                }
            }
            return best;
        }
    }

    public static class SotfDroneMissileScript extends BaseCombatLayeredRenderingPlugin {
        protected ShipAPI drone;
        protected MissileAPI missile;
        protected boolean done;

        public SotfDroneMissileScript(ShipAPI drone, MissileAPI missile) {
            super();
            this.drone = drone;
            this.missile = missile;
            missile.setNoFlameoutOnFizzling(true);
        }

        @Override
        public void advance(float amount) {
            super.advance(amount);

            if (done) return;

            CombatEngineAPI engine = Global.getCombatEngine();

            missile.setEccmChanceOverride(1f);
            missile.setOwner(drone.getOwner());

            drone.getLocation().set(missile.getLocation());
            drone.getVelocity().set(missile.getVelocity());
            drone.setCollisionClass(CollisionClass.FIGHTER);
            drone.setFacing(missile.getFacing());
            drone.getEngineController().fadeToOtherColor(this, new Color(0,0,0,0), new Color(0,0,0,0), 1f, 1f);

            float dist = Misc.getDistance(missile.getLocation(), missile.getStart());
            float jitterFraction = dist / missile.getMaxRange();
            jitterFraction = Math.max(jitterFraction, missile.getFlightTime() / missile.getMaxFlightTime());

            missile.setSpriteAlphaOverride(0f);
            drone.setJitter(FIGHTER_HACK_KEY, HACK_COLOR, 0.5f, 4, 6f);
            //float jitterMax = 1f + 10f * jitterFraction;
            //drone.setJitter(this, new Color(HACK_COLOR.getRed(), HACK_COLOR.getGreen(), HACK_COLOR.getBlue(),
            //        (int)(25 + 50 * jitterFraction)), 1f, 10, 1f, jitterMax);

            boolean droneDestroyed = drone.isHulk() || drone.getHitpoints() <= 0;
            if (missile.isFizzling() || (missile.getHitpoints() <= 0 && !missile.didDamage()) || droneDestroyed) {
                drone.getVelocity().set(0, 0);
                missile.getVelocity().set(0, 0);

                if (!droneDestroyed) {
                    Vector2f damageFrom = new Vector2f(drone.getLocation());
                    damageFrom = Misc.getPointWithinRadius(damageFrom, 20);
                    engine.applyDamage(drone, damageFrom, 1000000f, DamageType.ENERGY, 0, true, false, drone, false);
                }
                missile.interruptContrail();
                engine.removeEntity(drone);
                engine.removeEntity(missile);

                missile.explode();

                done = true;
                return;
            }
            if (missile.didDamage()) {
                drone.getVelocity().set(0, 0);
                missile.getVelocity().set(0, 0);

                Vector2f damageFrom = new Vector2f(drone.getLocation());
                damageFrom = Misc.getPointWithinRadius(damageFrom, 20);
                engine.applyDamage(drone, damageFrom, 1000000f, DamageType.ENERGY, 0, true, false, drone, false);
                missile.interruptContrail();
                engine.removeEntity(drone);
                engine.removeEntity(missile);
                done = true;
                return;
            }
        }

        @Override
        public boolean isExpired() {
            return done;
        }

    }
}

// May all you hold dear be taken away. Phantom steals the missile ammo of nearby enemies.
package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.FindShipFilter;
import com.fs.starfarer.api.util.WeightedRandomPicker;

import java.awt.*;

import static com.fs.starfarer.api.impl.combat.ReserveWingStats.RD_NO_EXTRA_CRAFT;

public class FronSecPhantomCovetous extends FronSecPhantomBaseTrait {


	public static String MR_DATA_KEY = "fs_covetous_data_key";

	public static class FronSecCovetousAmmoStealData {
		IntervalUtil interval = new IntervalUtil(10f, 12f);
	}

	@Override
	public void advanceInCombat(ShipAPI ship, float amount) {
		CombatEngineAPI engine = Global.getCombatEngine();

		String key = MR_DATA_KEY + "_" + ship.getId();
		FronSecCovetousAmmoStealData data = (FronSecCovetousAmmoStealData) engine.getCustomData().get(key);
		if (data == null) {
			data = new FronSecCovetousAmmoStealData();
			engine.getCustomData().put(key, data);
		}

		data.interval.advance(amount);
		if (data.interval.intervalElapsed() && getRefillWeapon(ship) != null) {
			//engine.addFloatingText(ship.getLocation(), "Attempted steal 1", 10f, Misc.getPositiveHighlightColor(), ship, 0.5f, 10f);
			FindShipFilter filter = new FindShipFilter() {
				public boolean matches(ShipAPI ship) {
					return getStealWeapon(ship) != null;
				}
			};
			//engine.addFloatingText(ship.getLocation(), "Attempted steal 2", 10f, Misc.getNegativeHighlightColor(), ship, 0.5f, 10f);
			ShipAPI target = Misc.findClosestShipEnemyOf(ship, ship.getLocation(), ShipAPI.HullSize.FRIGATE, 600 + (ship.getHullSize().ordinal() * 200f), true, filter);
			if (target == null) {
				return;
			}
			WeaponAPI refillWeapon = getRefillWeapon(ship);
			WeaponAPI stealWeapon = getStealWeapon(target);

			// refilled weapon gains up to half its base max ammo rounded up
			int amountToRefill = Math.max((int) Math.ceil(refillWeapon.getSpec().getMaxAmmo() * 0.5f), refillWeapon.getMaxAmmo() - refillWeapon.getAmmo());
			// stolen weapon loses up to half its base max ammo rounded up
			int amountToSteal = (int) Math.ceil(stealWeapon.getSpec().getMaxAmmo() * 0.5f);
			int amountLeft = stealWeapon.getAmmo() - Math.max(amountToSteal, stealWeapon.getAmmo());
			refillWeapon.setAmmo(refillWeapon.getAmmo() + amountToRefill);
			stealWeapon.setAmmo(amountLeft);

			engine.spawnEmpArcVisual(refillWeapon.getLocation(), ship, stealWeapon.getLocation(), target, 15f, Misc.getNegativeHighlightColor(), Color.black);
			engine.addFloatingText(refillWeapon.getLocation(), "Ammo refilled!", 12f, Misc.getPositiveHighlightColor(), ship, 0f, 10f);
			engine.addFloatingText(stealWeapon.getLocation(), "Ammo stolen!", 12f, Misc.getNegativeHighlightColor(), target, 0f, 10f);
		}
	}

	// called during phantom trait picking
	public static boolean isValidCovetousShip(ShipAPI ship) {
		boolean isValidCovetous = false;
		for (WeaponAPI weapon : ship.getUsableWeapons()) {
			// limited-ammo missiles only
			if (!weapon.getType().equals(WeaponAPI.WeaponType.MISSILE) || !weapon.usesAmmo() || weapon.getAmmoPerSecond() > 0) {
				continue;
			}
			isValidCovetous = true;
		}
		return isValidCovetous;
	}

	public WeaponAPI getRefillWeapon(ShipAPI ship) {
		WeightedRandomPicker<WeaponAPI> post = new WeightedRandomPicker<WeaponAPI>();
		for (WeaponAPI weapon : ship.getAllWeapons()) {
			// limited-ammo missiles that need refills only. Slightly lenient because stealing ammo is always good, even if it's inefficient
			if (!weapon.getType().equals(WeaponAPI.WeaponType.MISSILE) || !weapon.usesAmmo() || weapon.getAmmoPerSecond() > 0 || ((float) weapon.getAmmo() / (float) weapon.getMaxAmmo() > 0.75f)) {
				continue;
			}
			// higher weight to larger weapons
			post.add(weapon);
		}
		return post.pick();
	}

	public WeaponAPI getStealWeapon(ShipAPI ship) {
		WeightedRandomPicker<WeaponAPI> post = new WeightedRandomPicker<WeaponAPI>();
		for (WeaponAPI weapon : ship.getUsableWeapons()) {
			// limited-ammo missiles that need refills only
			if (!weapon.getType().equals(WeaponAPI.WeaponType.MISSILE) || !weapon.usesAmmo() || weapon.getAmmoPerSecond() > 0 || weapon.getAmmo() == 0) {
				continue;
			}
			// higher weight to larger weapons
			post.add(weapon);
		}
		return post.pick();
	}

}
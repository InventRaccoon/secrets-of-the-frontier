// A whispered song heralds your end. Phantom raises wisps from nearby dying ships and its own destroyed fighters.
package data.hullmods;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

public class FronSecPhantomSiren extends FronSecWisperer {

	// base trait behavior: easier to extend Wispersong instead
	public void advanceInCampaign(FleetMemberAPI member, float amount) {
		member.getVariant().removeMod(spec.getId());
	}

	public String getDescriptionParam(int index, ShipAPI.HullSize hullSize) {
		return null;
	}

	// Wisptender effect
	public void applyEffectsToFighterSpawnedByShip(ShipAPI fighter, ShipAPI ship, String id) {
		fighter.getVariant().addMod("fronsec_wisphost");
	}
	
}
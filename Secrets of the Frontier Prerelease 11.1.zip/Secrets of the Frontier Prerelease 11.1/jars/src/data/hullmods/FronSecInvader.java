// Ship gains dark spirit FX as part of being the victim of an Adjudicator invasion
package data.hullmods;

import com.fs.starfarer.api.GameState;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.combat.listeners.HullDamageAboutToBeTakenListener;
import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.util.FaderUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.campaign.ids.FronSecPeople;
import data.scripts.utils.FronSecMisc;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

public class FronSecInvader extends BaseHullMod

{

    public void advanceInCombat(ShipAPI ship, float amount) {
        if (!Global.getCurrentState().equals(GameState.COMBAT)) {
            return;
        }
        if (ship.isAlive() ) {
            ship.setJitterUnder(this, new Color(255, 50, 50, 155), 0.2f, 25, 5, 7);
            //ship.setJitter(this, new Color(0, 0, 0, 155), 1f, 25, 0, 3);
            ship.getEngineController().fadeToOtherColor(this, new Color(255, 100, 100, 155), new Color(155, 50, 50, 75), 1f, 0.8f);
            ship.setAlphaMult(0.5f);
            ship.setApplyExtraAlphaToEngines(true);
            if (!Global.getCombatEngine().isPaused()) {
                ship.addAfterimage(new Color(50, 0, 0, 25), 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, false, false, true);
            }
        }
    }
}
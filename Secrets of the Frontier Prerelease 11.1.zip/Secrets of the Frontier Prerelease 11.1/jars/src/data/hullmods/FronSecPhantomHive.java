// An unending swarm. Phantom never loses replacement rate and its fighter wings become larger.
package data.hullmods;

import com.fs.starfarer.api.GameState;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;

import java.awt.*;

import static com.fs.starfarer.api.impl.combat.ReserveWingStats.RD_NO_EXTRA_CRAFT;

public class FronSecPhantomHive extends FronSecPhantomBaseTrait {

	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		ship.getMutableStats().getDynamic().getStat(Stats.REPLACEMENT_RATE_DECREASE_MULT).modifyMult(id, 0f);
	}

	public void advanceInCombat(ShipAPI ship, float amount) {
		for (FighterLaunchBayAPI bay : ship.getLaunchBaysCopy()) {
			if (bay.getWing() == null) continue;

			FighterWingSpecAPI spec = bay.getWing().getSpec();
			int addForWing = getAdditionalFor(spec);
			int maxTotal = spec.getNumFighters() + addForWing;
			int actualAdd = maxTotal - bay.getWing().getWingMembers().size();
			if (actualAdd > 0) {
				bay.setFastReplacements(bay.getFastReplacements() + addForWing);
				bay.setExtraDeployments(actualAdd);
				bay.setExtraDeploymentLimit(maxTotal);
				bay.setExtraDuration(10f);
			}
		}
	}

	public static int getAdditionalFor(FighterWingSpecAPI spec) {
		//if (spec.isBomber() && !spec.hasTag(RD_FORCE_EXTRA_CRAFT)) return 0;
		if (spec.hasTag(RD_NO_EXTRA_CRAFT)) return 0;

		int size = spec.getNumFighters();
//		if (size <= 3) return 1;
//		return 2;
		if (size <= 3) return 1;
		if (size <= 5) return 2;
		return 3;
	}
}
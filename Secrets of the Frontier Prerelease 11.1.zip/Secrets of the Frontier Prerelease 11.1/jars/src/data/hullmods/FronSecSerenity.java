// literally just an extension of Adaptive Phase Coils
package data.hullmods;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.hullmods.AdaptivePhaseCoils;
import data.scripts.utils.FronSecMisc;

import java.awt.*;

public class FronSecSerenity extends AdaptivePhaseCoils {

    public boolean isApplicableToShip(ShipAPI ship) {
        return shipHasOtherModInCategory(ship, spec.getId(), "fronsec_concord");
    }

    public String getUnapplicableReason(ShipAPI ship) {
        if (!shipHasOtherModInCategory(ship, spec.getId(), "fronsec_concord")) {
            return "Requires a Phase Concord";
        }
        return null;
    }

    public Color getNameColor() {
        return FronSecMisc.getSierraColor();
    }

}

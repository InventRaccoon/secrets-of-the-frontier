// Never one without the other. Phantom corrupts two ships.
package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class FronSecPhantomKindred extends FronSecPhantomBaseTrait {

	// ... the Kindred hullmod doesn't actually do anything, it's just a marker used during phantom creation.
	
}
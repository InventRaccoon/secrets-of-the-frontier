// Won't you dance with me?
// Ship becomes a phase ghost, partly transparent, 110% time mult, is "banished" on death instead of exploding
package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.combat.listeners.HullDamageAboutToBeTakenListener;
import com.fs.starfarer.api.util.FaderUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.utils.FronSecMisc;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

public class FronSecPhantasmalShip extends BaseHullMod

{

    // Instead of dying normally, play a short animation and then vanish
    public static class FronSecBanishmentDeathScript implements AdvanceableListener, HullDamageAboutToBeTakenListener {
        public ShipAPI ship;
        public boolean emergencyDive = false;
        public float diveProgress = 0f;
        public FaderUtil diveFader = new FaderUtil(0.4f, 1f);
        public FronSecBanishmentDeathScript(ShipAPI ship) {
            this.ship = ship;
        }

        public boolean notifyAboutToTakeHullDamage(Object param, ShipAPI ship, Vector2f point, float damageAmount) {

            if (!emergencyDive) {
                float hull = ship.getHitpoints();
                if (damageAmount >= hull) {
                    ship.setHitpoints(1f);

                    emergencyDive = true;

                    if (!ship.isPhased()) {
                        Global.getSoundPlayer().playSound("system_phase_cloak_activate", 1f, 1f, ship.getLocation(), ship.getVelocity());
                    }
                }
            }

            if (emergencyDive) {
                return true;
            }

            return false;
        }

        public void advance(float amount) {
            String id = "fs_banishment_modifier";
            if (emergencyDive) {
                diveFader.advance(amount);

                ship.setControlsLocked(true);
                ship.getFluxTracker().beginOverloadWithTotalBaseDuration(5f);
                ship.blockCommandForOneFrame(ShipCommand.USE_SYSTEM);
                ship.setHoldFireOneFrame(true);
                ship.getEngineController().forceFlameout(true);
                ship.setCollisionClass(CollisionClass.NONE);
                diveProgress += amount;
                ship.getMutableStats().getHullDamageTakenMult().modifyMult(id, 0f);

                if (diveProgress >= 1f) {
                    if (diveFader.isIdle()) {
                        Global.getSoundPlayer().playSound("phase_anchor_vanish", 1f, 1f, ship.getLocation(), ship.getVelocity());
                    }
                    diveFader.fadeOut();
                    diveFader.advance(amount);
                    float b = diveFader.getBrightness();
                    ship.setExtraAlphaMult2(b);
                    float r = ship.getCollisionRadius() * 5f;
                    ship.setJitter(this, FronSecMisc.getSierraColor(), b, 20, r * (1f - b));

                    if (diveFader.isFadedOut()) {
                        String text = ship.getHullSpec().getHullName();
                        if (text.equals("")) {
                            text = ship.getHullSpec().getDesignation();
                        }
                        Global.getCombatEngine().getCombatUI().addMessage(1, ship, Misc.getNegativeHighlightColor(), text, Misc.getTextColor(), " banished");
                        Global.getSoundPlayer().playUISound("fronsec_phaseghost_whisper", 1f, 1.2f);
                        ship.removeListener(this);
                        ship.setHullSize(HullSize.FIGHTER);
                        ship.getLocation().set(0, -1000000f);
                        ship.getMutableStats().getHullDamageTakenMult().unmodify(id);
                        Global.getCombatEngine().applyDamage(ship, ship.getLocation(), 10000000, DamageType.HIGH_EXPLOSIVE, 0, true, false, null);
                        //Global.getCombatEngine().removeEntity(ship);
                    }
                }
            }

            Color sc = FronSecMisc.getSierraColor();
            Color sca = Misc.setAlpha(sc, 50);


            ship.setJitter(this, sca, 2f, 2, 6f);
            ship.setAlphaMult(0.5f);
            ship.setApplyExtraAlphaToEngines(true);

            // time mult
            boolean player = ship == Global.getCombatEngine().getPlayerShip();
            if (player && ship.isAlive()) {
                ship.getMutableStats().getTimeMult().modifyMult("fronsec_eidolonsconcord", 1.1f);
                Global.getCombatEngine().getTimeMult().modifyMult("fronsec_eidolonsconcord", 1f / 1.1f);
            } else {
                ship.getMutableStats().getTimeMult().modifyMult("fronsec_eidolonsconcord", 1.1f);
                Global.getCombatEngine().getTimeMult().unmodify("fronsec_eidolonsconcord");
            }
        }

    }

    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        ship.addListener(new FronSecBanishmentDeathScript(ship));
    }

    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        // regular stat boosts
        stats.getZeroFluxSpeedBoost().modifyFlat(id, 10f);
        stats.getShieldUnfoldRateMult().modifyPercent(id, 30f);
    }

    public Color getNameColor() {
        return FronSecMisc.getSierraColor();
    }
}
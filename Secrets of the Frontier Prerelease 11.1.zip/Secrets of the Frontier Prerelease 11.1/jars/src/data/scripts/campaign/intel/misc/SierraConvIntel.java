// simple intel with a button to trigger a rule-based dialogue
package data.scripts.campaign.intel.misc;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.ColonyPlayerHostileActListener;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.MarketCMD;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.IntelUIAPI;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import data.scripts.campaign.ids.FronSecPeople;
import data.scripts.utils.FronSecMisc;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.Set;

public class SierraConvIntel extends BaseIntelPlugin implements FleetEventListener, ColonyPlayerHostileActListener {

	public SierraConvIntel() {
		Global.getSector().getPlayerFleet().addEventListener(this);
		Global.getSector().getListenerManager().addListener(this);
	}

	// tracks the player's accomplishments with and without Sierra
	public void reportBattleOccurred(CampaignFleetAPI fleet, CampaignFleetAPI primaryWinner, BattleAPI battle) {
		if (isDone()) return;

		if (!battle.isPlayerInvolved() || !battle.isInvolved(fleet)) {
			return;
		}

		FronSecMisc.setSierraHasThoughts();

		MemoryAPI sector_mem = Global.getSector().getMemoryWithoutUpdate();

		for (CampaignFleetAPI otherFleet : battle.getNonPlayerSideSnapshot()) {
			MemoryAPI fleet_mem = otherFleet.getMemoryWithoutUpdate();
			if (fleet_mem.contains("$ziggurat") && FronSecMisc.playerHasSierra()) {
				sector_mem.set("$sierraWitnessedZigFight", true);
			}
			for (FleetMemberAPI member : Misc.getSnapshotMembersLost(otherFleet)) {
				if (member.getHullId().equals("tesseract") && FronSecMisc.playerHasSierra()) {
					sector_mem.set("$sierraWitnessedOmega", true);
				}
				if (member.getHullId().equals("guardian") && FronSecMisc.playerHasSierra()) {
					sector_mem.set("$sierraWitnessedGuardianKill", true);
				}
				if (member.getHullId().equals("remnant_station1") && FronSecMisc.playerHasSierra()) {
					sector_mem.set("$sierraWitnessedRemStation1Kill", true);
				}
				if (member.getHullId().equals("remnant_station2") && FronSecMisc.playerHasSierra()) {
					sector_mem.set("$sierraWitnessedRemStation2Kill", true);
				}
			}
		}
	}

	public void reportFleetDespawnedToListener(CampaignFleetAPI fleet, CampaignEventListener.FleetDespawnReason reason, Object param) {

	}

	public void reportRaidForValuablesFinishedBeforeCargoShown(InteractionDialogAPI dialog, MarketAPI market, MarketCMD.TempData actionData, CargoAPI cargo) {
		//
	}
	public void reportRaidToDisruptFinished(InteractionDialogAPI dialog, MarketAPI market, MarketCMD.TempData actionData, Industry industry) {
		//
	}

	public void reportTacticalBombardmentFinished(InteractionDialogAPI dialog, MarketAPI market, MarketCMD.TempData actionData) {
		//
	}
	public void reportSaturationBombardmentFinished(InteractionDialogAPI dialog, MarketAPI market, MarketCMD.TempData actionData) {
		FronSecMisc.addGuilt(1f);
		// if Sierra is around, add a new conversation topic
		if (FronSecMisc.playerHasSierra()) {
			Global.getSector().getMemoryWithoutUpdate().set("$sierraLatestSatbombMkt", market.getName());
			if (!Global.getSector().getMemoryWithoutUpdate().contains("$sierraWitnessedAtrocity")) {
				Global.getSector().getMemoryWithoutUpdate().set("$sierraWitnessedAtrocity", true);
				FronSecMisc.setSierraHasThoughts();
			}
		}
		// admitting the first satbomb was a mistake removes 0.5 Guilt. Hollow words grant no rewards.
		if (Global.getSector().getMemoryWithoutUpdate().contains("$sierraAdmittedMistake") && !Global.getSector().getMemoryWithoutUpdate().contains("$sierraAdmittedMistakePenalty")) {
			FronSecMisc.addGuilt(0.5f);
			Global.getSector().getMemoryWithoutUpdate().set("$sierraAdmittedMistakePenalty", true);
		}
	}

	protected void addBulletPoints(TooltipMakerAPI info, ListInfoMode mode) {
		Color h = Misc.getHighlightColor();
		Color g = Misc.getGrayColor();
		float pad = 3f;
		float opad = 10f;
		
		float initPad = pad;
		if (mode == ListInfoMode.IN_DESC) initPad = opad;
		
		Color tc = getBulletColorForMode(mode);
		
		bullet(info);
		boolean isUpdate = getListInfoParam() != null;
		
		unindent(info);
	}
	
	
	@Override
	public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {
		Color c = getTitleColor(mode);
		info.addPara(getName(), c, 0f);
		addBulletPoints(info, mode);
	}
	
	@Override
	public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
		Color h = Misc.getHighlightColor();
		Color g = Misc.getGrayColor();
		Color tc = Misc.getTextColor();
		PersonAPI sierra = FronSecPeople.getPerson(FronSecPeople.SIERRA);
		FactionAPI sierra_faction = Global.getSector().getFaction("fronsec_sierra_faction");
		FleetMemberAPI member = null;
		for (FleetMemberAPI fleetmem : Global.getSector().getPlayerFleet().getMembersWithFightersCopy()) {
			if (fleetmem.getVariant().hasHullMod("fronsec_sierrasconcord")) {
				member = fleetmem;
			}
		}
		float pad = 3f;
		float opad = 10f;
		
		addBulletPoints(info, ListInfoMode.IN_DESC);

		info.addImage(sierra.getPortraitSprite(), width, 128, opad);

		if (member != null) {
			info.addPara("Sierra is an advanced artificial intelligence under your command, currently operating the " + member.getShipName() + ".", opad, FronSecMisc.getSierraColor(), "Sierra", member.getShipName());
		}
		// below text should never display - this intel item is hidden without Sierra around
		else {
			info.addPara("Sierra is an experimental artificial intelligence under your command, currently operating within your fleet.", opad, FronSecMisc.getSierraColor(), "Sierra");
		}
		info.addPara("A conversation with her might offer up insights on your recent accomplishments, or an opportunity to offer her feedback on her combat style.", opad);
		info.addPara("She is currently available to speak to.", opad);
		ButtonAPI button = info.addButton("Request a comm-link", "FS_BUTTON_SIERRA",
				sierra_faction.getBaseUIColor(), sierra_faction.getDarkUIColor(),
				(int)(width), 20f, opad * 2f);
		button.setShortcut(Keyboard.KEY_T, true);
	}
	
	@Override
	public String getIcon() {
		return Global.getSettings().getSpriteName("fronsec_portraits", "portrait_sierra");
	}
	
	@Override
	public Set<String> getIntelTags(SectorMapAPI map) {
		Set<String> tags = super.getIntelTags(map);
		tags.add(Tags.INTEL_CONTACTS);
		return tags;
	}
	
	public String getSortString() {
		return "Sierra";
	}
	
	public String getName() {
		return "Contact: Sierra";
	}
	
	@Override
	public FactionAPI getFactionForUIColors() {
		return Global.getSector().getFaction("fronsec_sierra_faction");
	}

	public String getSmallDescriptionTitle() {
		return getName();
	}
	
	@Override
	public boolean shouldRemoveIntel() {
		return false;
	}

	// don't show unless a Concord ship is in our fleet
	@Override
	public boolean isHidden() {
		return !FronSecMisc.playerHasSierra();
	}

	@Override
	public String getCommMessageSound() {
		return getSoundMajorPosting();
	}

	public void buttonPressConfirmed(Object buttonId, IntelUIAPI ui) {
		if (buttonId == "FS_BUTTON_SIERRA") {
			ui.showDialog(null, "SierraConvOpen");
		}
	}
}








// miscellaneous methods that I want to be using about the place
package data.scripts.utils;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.*;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.campaign.ids.FronSecIDs;
import data.scripts.campaign.ids.FronSecPeople;

import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Random;
import java.util.Set;

import static com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.*;
import static com.fs.starfarer.api.util.Misc.random;

public class FronSecMisc {

    // pickHiddenLocation but without dumb "far reaches" spawns
    public static EntityLocation pickReasonableLocation(Random random, StarSystemAPI system, float gap, Set<SectorEntityToken> exclude) {
        LinkedHashMap<LocationType, Float> weights = new LinkedHashMap<LocationType, Float>();
        weights.put(LocationType.IN_ASTEROID_BELT, 5f);
        weights.put(LocationType.IN_ASTEROID_FIELD, 5f);
        weights.put(LocationType.IN_RING, 5f);
        weights.put(LocationType.IN_SMALL_NEBULA, 5f);
        weights.put(LocationType.L_POINT, 5f);
        weights.put(LocationType.GAS_GIANT_ORBIT, 5f);
        weights.put(LocationType.NEAR_STAR, 5f);
        WeightedRandomPicker<EntityLocation> locs = getLocations(random, system, exclude, gap, weights);
        if (locs.isEmpty()) {
            return pickAnyLocation(random, system, gap, exclude);
        }
        return locs.pick();
    }

    // creates a derelict ship
    public static SectorEntityToken addDerelict (StarSystemAPI system, SectorEntityToken focus, String variantId,
                                ShipRecoverySpecial.ShipCondition condition, float orbitRadius, boolean recoverable){
        DerelictShipEntityPlugin.DerelictShipData params = new DerelictShipEntityPlugin.DerelictShipData(new ShipRecoverySpecial.PerShipData(variantId, condition), false);
        SectorEntityToken ship = BaseThemeGenerator.addSalvageEntity(system, Entities.WRECK, Factions.NEUTRAL, params);
        ship.setDiscoverable(true);

        float orbitDays = orbitRadius / (10f + (float) Math.random() * 5f);
        ship.setCircularOrbit(focus, (float) Math.random() * 360f, orbitRadius, orbitDays);

        if (recoverable) {
            SalvageSpecialAssigner.ShipRecoverySpecialCreator creator = new SalvageSpecialAssigner.ShipRecoverySpecialCreator(null, 0, 0, false, null, null);
            Misc.setSalvageSpecial(ship, creator.createSpecial(ship, null));
        }
        return ship;
    }

    // creates a derelict ship
    public static SectorEntityToken addStoryDerelictWithName (StarSystemAPI system, SectorEntityToken focus, String variantId,
                                                 ShipRecoverySpecial.ShipCondition condition, float orbitRadius, boolean recoverable, String name){
        DerelictShipEntityPlugin.DerelictShipData params = new DerelictShipEntityPlugin.DerelictShipData(new ShipRecoverySpecial.PerShipData(variantId, condition), false);
        params.ship.shipName = name;
        params.ship.nameAlwaysKnown = true;
        SectorEntityToken ship = BaseThemeGenerator.addSalvageEntity(system, Entities.WRECK, Factions.NEUTRAL, params);
        ship.setDiscoverable(true);

        float orbitDays = orbitRadius / (10f + (float) Math.random() * 5f);
        ship.setCircularOrbit(focus, (float) Math.random() * 360f, orbitRadius, orbitDays);

        if (recoverable) {
            SalvageSpecialAssigner.ShipRecoverySpecialCreator creator = new SalvageSpecialAssigner.ShipRecoverySpecialCreator(null, 0, 0, false, null, null);
            Misc.setSalvageSpecial(ship, creator.createSpecial(ship, null));
        }
        return ship;
    }

    // check if player has Sierra in their fleet
    public static boolean playerHasSierra() {
        boolean sierra = false;
        if (Global.getSector().getPlayerFleet() != null) {
            for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getMembersWithFightersCopy()) {
                if (member.getVariant().hasHullMod("fronsec_sierrasconcord")) {
                    sierra = true;
                }
            }
        }
        return sierra;
    }

    // check for Request Assistance escort fleet
    public static boolean omicronEscortIsNearby() {
        boolean omicron = false;
        for (CampaignFleetAPI fleet : Global.getSector().getPlayerFleet().getContainingLocation().getFleets()) {
            if (Misc.getDistance(fleet, Global.getSector().getPlayerFleet()) < 2000 && fleet.getMemoryWithoutUpdate().contains("$omicronescort")) {
                omicron = true;
            }
        }
        return omicron;
    }

    public static Color getSierraColor() {
        return Global.getSector().getFaction(FronSecIDs.SIERRA_FACTION).getBaseUIColor();
    }

    // returns the empty variant of Sierra's current ship class - Pledge or Vow
    public static String getSierraVariant() {
        return "fronsec_" + Global.getSector().getMemoryWithoutUpdate().getString("$fs_sierra_var") + "_Empty";
    }

    public static void levelUpSierra() {
        PersonAPI sierra = FronSecPeople.getPerson(FronSecPeople.SIERRA);
        int sierra_level = sierra.getStats().getLevel();
        switch (sierra_level) {
            case 6:
                sierra.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 1);
                sierra.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
                sierra.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 2);
                sierra.getStats().setSkillLevel(Skills.ORDNANCE_EXPERTISE, 2);
                sierra.getStats().setLevel(sierra_level + 1);
                break;
            case 7:
                sierra.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
                sierra.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 2);
                sierra.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
                sierra.getStats().setLevel(sierra_level + 1);
                break;
        }
    }

    // makes player able to ask Sierra for her thoughts if it was on cooldown
    public static void setSierraHasThoughts() {
        Global.getSector().getMemoryWithoutUpdate().set("sierraNoThoughts", false);
    }

    public static Color getEidolonColor() {
        return Global.getSector().getFaction(FronSecIDs.EIDOLON_FACTION).getBaseUIColor();
    }

    // retrieve player Guilt score
    public static float getPlayerGuilt() {
        return Global.getSector().getCharacterData().getMemoryWithoutUpdate().getFloat(FronSecIDs.GUILT_KEY)
                + Global.getSettings().getFloat("fronsec_bonusGuilt");
    }

    // retrieve player Guilt score excluding any bonus guilt
    public static float getPlayerBaseGuilt() {
        return Global.getSector().getCharacterData().getMemoryWithoutUpdate().getFloat(FronSecIDs.GUILT_KEY);
    }

    // increase player Guilt score
    public static void addGuilt(float amount, float max) {
        float guilt = getPlayerBaseGuilt();
        float amount_to_add = (Math.max(amount, max - guilt));
        //if (amount_to_add < 0f) {
        //    amount_to_add = 0f;
        //}
        Global.getSector().getCharacterData().getMemoryWithoutUpdate().set(FronSecIDs.GUILT_KEY, guilt + amount_to_add);
    }

    public static void addGuilt(float amount) {
        addGuilt(amount, 999f);
    }

    // generates an adjudicator officer for a ship that has traits already applied
    public static PersonAPI generateAdjudicatorForShip(ShipAPI ship) {
        String major_trait = (String) ship.getCustomData().get("$fs_phantom_major");
        String suffix = getAdjNameForTrait(major_trait);
        PersonAPI person = Misc.getAICoreOfficerPlugin(Commodities.ALPHA_CORE).createPerson(Commodities.ALPHA_CORE, FronSecIDs.ARBITER_FACTION, Misc.random);
        //person.getName().setFirst("Darkmoon-Aspect-" + getSuffixForTrait(suffix));
        person.getName().setFirst("\"" + suffix + "\"");
        person.getName().setLast("");
        person.setPortraitSprite(Global.getSettings().getSpriteName("fronsec_characters", "eidolon"));
        person.setPersonality(Personalities.AGGRESSIVE);
        // cosmetic skills to show phantom traits
        person.getStats().setSkillLevel("fronsec_skill_blank", 1);
        for (String mod : ship.getVariant().getHullMods()) {
            if (Global.getSettings().getHullModSpec(mod).hasTag("fronsec_phantom_trait")) {
                person.getStats().setSkillLevel(mod, 1);
                if (mod.equals(major_trait)) {
                    person.getStats().setSkillLevel(mod, 2);
                }
            }
        }
        return person;
    }

    public static String getAdjNameForTrait(String trait) {
        String name = "";
        switch (trait) {
            //case "fronsec_phantom_":
            //    name = "";
            //    break;
            case "fronsec_phantom_covetous":
                name = "A Faceless Trickster";
                break;
            case "fronsec_phantom_hive":
                name = "Queen of The Gallows";
                break;
            case "fronsec_phantom_kindred":
                name = "A Graceful Passing";
                break;
            case "fronsec_phantom_kindred2":
                name = "Jaws of Finality";
                break;
            case "fronsec_phantom_relentless":
                name = "Your Eternal Pursuer";
                break;
            case "fronsec_phantom_vengeful":
                name = "Thrice-Speared Wraith";
                break;
            case "fronsec_phantom_watchful":
                name = "Oracle's Eightieth Eye";
                break;
            case "fronsec_phantom_whisper":
                name = "A Masked Grovetender";
                break;
            default:
                name = "A Nameless Hunter";
                break;
        }
        return name;
    }
}

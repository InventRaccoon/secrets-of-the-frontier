// used to remove all salvage options other than recovering player ships
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.DModManager;
import com.fs.starfarer.api.impl.campaign.FleetEncounterContext;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.loading.VariantSource;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

import java.util.*;

public class FronSecAMemoryFEContext extends FleetEncounterContext {

    protected void generatePlayerLoot(List<FleetMemberAPI> recoveredShips, boolean withCredits) {
        DataForEncounterSide winner = getWinnerData();
        for (FleetMemberData data : winner.getOwnCasualties()) {
            if (data.getMember().isAlly()) continue;

            if (data.getStatus() == Status.CAPTURED || data.getStatus() == Status.REPAIRED) {
                continue;
            }
            float mult = getSalvageMult(data.getStatus());
            lootWeapons(data.getMember(), data.getMember().getVariant(), true, mult, false);
            lootWings(data.getMember(), data.getMember().getVariant(), true, mult);
        }
        handleCargoLooting(recoveredShips, false);
    }
}

// every frame plugin for the A Memory fight
package data.scripts.combat.special;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.BattleCreationContext;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.util.Misc;
import data.scripts.dialog.FronSecAMemoryDialogScript;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.List;

public class FronSecAMemoryEFCPlugin extends BaseEveryFrameCombatPlugin {

    private CombatEngineAPI engine;
    private BattleCreationContext context;
    // tracks # of seconds passed in combat
    private float counter = 0;
    // tracks # of seconds passed with a Concord ship deployed
    private float sierraCounter = 0;
    // is this the first time the player has fought this battle?
    private boolean repeat = true;
    // player has Harmonic Tuning story point option
    private boolean harmonicTuning = false;
    // various bits of dialogue
    private boolean initial = false;
    private boolean first = false;
    private boolean second = false;
    private boolean third = false;
    private boolean fourth = false;
    private boolean fifth = false;
    private boolean sixth = false;
    private boolean last = false;
    // the player's Concord ship
    private ShipAPI sierra = null;
    // ISS Athena
    private ShipAPI athena = null;
    // harmonically tuned phase frigate
    private ShipAPI tuned = null;

    public FronSecAMemoryEFCPlugin(BattleCreationContext context) {
        this.context = context;
    }
    public void init(CombatEngineAPI engine) {
        this.engine = engine;
        engine.setDoNotEndCombat(true);
        if (!Global.getSector().getMemoryWithoutUpdate().contains("$fs_AMemoryCombatStarted")) {
            Global.getSector().getMemoryWithoutUpdate().set("$fs_AMemoryCombatStarted", true);
            repeat = false;
        }
        if (!Global.getSector().getMemoryWithoutUpdate().contains("$fs_AMHarmonicTuning")) {
            harmonicTuning = true;
        }
        engine.getCustomData().put("$fs_NoSierraChatter", true);
    }

    public void advance(float amount, List<InputEventAPI> events) {
        Color sc = Global.getSector().getFaction("fronsec_sierra_faction").getBaseUIColor();
        boolean sierraAlive = false;
        boolean athenaAlive = false;
        for (ShipAPI ship : engine.getShips()) {
            if (ship.getOwner() == 0) {
                if (ship.getVariant().hasHullMod("fronsec_sierrasconcord")) {
                    sierra = ship;
                    ship.getFleetMember().getCrewComposition().setCrew(0);
                } else if (ship.getHullSpec().getHullId().equals("aurora") && ship.getName().equals("ISS Athena")) {
                    athena = ship;
                } else if (ship.isFrigate() && ship.getHullSpec().isPhase() && tuned == null) {
                    tuned = ship;
                }
            }
            if (ship.getOwner() == 0 && !ship.getVariant().hasHullMod("fronsec_sierrasconcord") && !ship.getVariant().hasTag("fs_amemory_immunity") && !ship.isFighter() && ship != tuned) {
                ship.setDefenseDisabled(true);
                ship.setCurrentCR(0.1f);
            }
        }
        if (!engine.isPaused()) {
            counter += amount;
            if (sierra != null) {
                if (sierra.isAlive()) {
                    sierraAlive = true;
                    sierraCounter += amount;
                }
            }
            if (athena != null) {
                if (athena.isAlive()) {
                    athenaAlive = true;
                }
            }
        }
        if (counter > 1 && !initial && athenaAlive) {
            Global.getCombatEngine().getCombatUI().addMessage(1, athena, Misc.getPositiveHighlightColor(), "ISS Athena (Aurora-class)", Misc.getTextColor(), ": \"What the hell...? We've got warships on radar!\"");
            engine.addFloatingText(new Vector2f(athena.getLocation().x, athena.getLocation().y + 100),
                    "\"What the hell...? We've got warships on radar!\"",
                    40f, Misc.getTextColor(), athena, 1f, 0f);
            initial = true;
        }
        if (sierraCounter > 4 && !first && sierraAlive) {
            if (!repeat) {
            Global.getCombatEngine().getCombatUI().addMessage(1, sierra, sc, sierra.getName() + " (" + sierra.getHullSpec().getHullNameWithDashClass() + "): \"What's... going...?\"");
            engine.addFloatingText(new Vector2f(sierra.getLocation().x, sierra.getLocation().y + 100),
                    "\"What's... going...?\"",
                    40f, sc, sierra, 1f, 0f);
            } else {
                Global.getCombatEngine().getCombatUI().addMessage(1, sierra, sc, sierra.getName() + " (" + sierra.getHullSpec().getHullNameWithDashClass() + "): \"Once more unto the breach!\"");
                engine.addFloatingText(new Vector2f(sierra.getLocation().x, sierra.getLocation().y + 100),
                        "\"Once more unto the breach!\"",
                        40f, sc, sierra, 1f, 0f);
            }
            first = true;

        }
        if (counter > 7 && !second && athenaAlive) {
            Global.getCombatEngine().getCombatUI().addMessage(1, athena, Misc.getPositiveHighlightColor(), "ISS Athena (Aurora-class)", Misc.getTextColor(), ": \"Spread out! Don't get surrounded!\"");
            engine.addFloatingText(new Vector2f(athena.getLocation().x, athena.getLocation().y + 100),
                    "\"Spread out! Don't get surrounded!\"",
                    40f, Misc.getTextColor(), athena, 1f, 0f);
            second = true;
        }
        if (sierraCounter > 10 && !third && sierraAlive && !repeat) {
            Global.getCombatEngine().getCombatUI().addMessage(1, sierra, sc, sierra.getName() + " (" + sierra.getHullSpec().getHullNameWithDashClass() + "): \"... Oh...\"");
            engine.addFloatingText(new Vector2f(sierra.getLocation().x, sierra.getLocation().y + 100),
                    "\"... Oh...\"",
                    40f, sc, sierra, 1f, 0f);
            third = true;
        }
        if (sierraCounter > 13 && !fourth && sierraAlive && !repeat) {
            Global.getCombatEngine().getCombatUI().addMessage(1, sierra, sc, sierra.getName() + " (" + sierra.getHullSpec().getHullNameWithDashClass() + "): \"I think we're in for a fight, Captain.\"");
            engine.addFloatingText(new Vector2f(sierra.getLocation().x, sierra.getLocation().y + 100),
                    "\"I think we're in for a fight, Captain.\"",
                    40f, sc, sierra, 1f, 0f);
            fourth = true;
        }
        if (counter > 15 && !fifth && athenaAlive && sierraAlive) {
            if (!AIUtils.getNearbyAllies(sierra, 500f).isEmpty()) {
                Global.getCombatEngine().getCombatUI().addMessage(1, athena, Misc.getPositiveHighlightColor(), "ISS Athena (Aurora-class)", Misc.getTextColor(), ": \"Unknown vessel on our flanks. IFF friendly, watch your fire!\"");
                engine.addFloatingText(new Vector2f(athena.getLocation().x, athena.getLocation().y + 100),
                        "\"Unknown vessel on our flanks. IFF friendly, watch your fire!\"",
                        40f, Misc.getTextColor(), athena, 1f, 0f);
                fifth = true;
            }
        }
        if (counter > 20 && !sixth && sierraAlive && !AIUtils.getNearbyEnemies(sierra, 1200f).isEmpty() && !repeat) {
            if (!AIUtils.getNearbyEnemies(sierra, 1200f).isEmpty()) {
                Global.getCombatEngine().getCombatUI().addMessage(1, sierra, sc, sierra.getName() + " (" + sierra.getHullSpec().getHullNameWithDashClass() + "): \"Are those... Hegemony ships?\"");
                engine.addFloatingText(new Vector2f(sierra.getLocation().x, sierra.getLocation().y + 100),
                        "\"Are those... Hegemony ships?\"",
                        40f, sc, sierra, 1f, 0f);
                sixth = true;
            }
        }
        if (counter > 20 && engine.getFleetManager(1).getDeployedCopyDFM().isEmpty() && !last) {
            engine.setDoNotEndCombat(false);
            if (athenaAlive) {
                Global.getCombatEngine().getCombatUI().addMessage(1, athena, Misc.getPositiveHighlightColor(), "ISS Athena (Aurora-class)", Misc.getTextColor(), ": \"... we're clear. We're clear. Holy...\"");
                engine.addFloatingText(new Vector2f(athena.getLocation().x, athena.getLocation().y + 100),
                        "\"... We're clear. We're clear. Holy...\"",
                        40f, Misc.getTextColor(), athena, 1f, 0f);
            }
            if (sierraAlive) {
                Global.getCombatEngine().getCombatUI().addMessage(1, sierra, sc, sierra.getName() + " (" + sierra.getHullSpec().getHullNameWithDashClass() + "): \"Good work, Captain. Let's get out of here.\"");
                engine.addFloatingText(new Vector2f(sierra.getLocation().x, sierra.getLocation().y + 100),
                        "\"Good work, Captain. Let's get out of here.\"",
                        40f, sc, sierra, 1f, 0f);
            }
            last = true;
        }
        // end combat if the player loses their Concord ship
        if (sierra != null) {
            if (!sierra.isAlive()) {
                engine.endCombat(2f, FleetSide.ENEMY);
            }
        }
        // end combat if the player attempts to retreat
        if (engine.getFleetManager(0).getTaskManager(false).isInFullRetreat()) {
            engine.endCombat(10f, FleetSide.ENEMY);
        }
    }
}
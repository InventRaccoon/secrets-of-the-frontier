// every frame plugin for the Wayward Star fight
package data.scripts.combat.special;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.BattleCreationContext;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import data.scripts.dialog.FronSecWSDialogScript;
import data.scripts.utils.FronSecMisc;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.List;

public class FronSecWSEFCPlugin extends BaseEveryFrameCombatPlugin {

    private CombatEngineAPI engine;
    private BattleCreationContext context;
    // tracks # of seconds passed in combat
    private float counter = 0;
    // is this the first time the player has fought this battle?
    private boolean repeat = true;
    // have we added the dialogue plugin?
    private boolean plugin = false;
    // various bits of dialogue
    private boolean sierraChatted = false;
    private boolean eidolonChatted = false;
    // the player's Concord ship
    private ShipAPI sierra = null;
    // ISS Athena
    private ShipAPI eidolon = null;

    public FronSecWSEFCPlugin(BattleCreationContext context) {
        this.context = context;
    }
    public void init(CombatEngineAPI engine) {
        this.engine = engine;
        engine.setDoNotEndCombat(true);
        if (!Global.getSector().getMemoryWithoutUpdate().contains("$fs_WSCombatStarted")) {
            Global.getSector().getMemoryWithoutUpdate().set("$fs_WSCombatStarted", null);
            repeat = false;
        }
        engine.getCustomData().put("$fs_NoSierraChatter", true);
    }

    public void advance(float amount, List<InputEventAPI> events) {
        Global.getSoundPlayer().playUILoop("fronsec_weightlessthoughts", 1f, 1f);
        Color sc = Global.getSector().getFaction("fronsec_sierra_faction").getBaseUIColor();
        for (ShipAPI ship : engine.getShips()) {
                if (ship.getVariant().hasHullMod("fronsec_sierrasconcord") && ship.getOwner() == 0) {
                    sierra = ship;
                } else if (ship.getVariant().hasHullMod("fronsec_eidolonsconcord") && ship.getOwner() == 1) {
                    eidolon = ship;
            }
        }
        if (!engine.isPaused()) {
            counter += amount;
        }
        if (counter > 3) {
            engine.setDoNotEndCombat(false);
            if (sierra != null && !sierraChatted) {
                Global.getCombatEngine().getCombatUI().addMessage(1, sierra, sc, sierra.getName() + " (" + sierra.getHullSpec().getHullNameWithDashClass() + "): \"... what...?\"");
                engine.addFloatingText(new Vector2f(sierra.getLocation().x, sierra.getLocation().y + 100),
                        "\"... what...?\"",
                        40f, sc, sierra, 1f, 0f);
                sierraChatted = true;
            }
        }
        if (counter > 3 && engine.getFleetManager(1).getDeployedCopyDFM().isEmpty()) {
            if (eidolon != null && !eidolonChatted) {
                Global.getCombatEngine().getCombatUI().addMessage(1, eidolon, FronSecMisc.getEidolonColor(), "We must convene again");
                Global.getCombatEngine().getCombatUI().addMessage(2, eidolon, FronSecMisc.getEidolonColor(), "This eidolon is impressed, you did beautifully");
                eidolonChatted = true;
            }
        }
    }
}
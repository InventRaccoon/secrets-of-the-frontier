// objective effect: periodically spawns droneships allied with the objective's holder
package data.scripts.combat;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BattleObjectiveAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.ShipRoles;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.combat.BaseBattleObjectiveEffect;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.lwjgl.util.vector.Vector2f;

import java.util.List;

public class FronSecReinforcerEffect extends BaseBattleObjectiveEffect {

	public ShipAPI ship;
	public Vector2f loc;

	private static float reinforce_timer = 20;
	private static String REINFORCEMENT_RESPAWN_KEY = "fs_reinforcement_data_key";
	private Object STATUSKEY;

	public static class FronSecReinforcementRespawnTimer {
		IntervalUtil interval = new IntervalUtil(reinforce_timer, reinforce_timer);
	}

	public void init(CombatEngineAPI engine, BattleObjectiveAPI objective) {
		super.init(engine, objective);
	}

	public void advance(float amount) {
		CombatEngineAPI engine = Global.getCombatEngine();
		if (engine.isPaused()) {return;}
		// should we show a status on the player's screen?
		boolean status = false;
		String sub = "";
		// number of living reinforcement ships
		int alive = 0;
		// threshold of reinforcement ships alive where the timer should tick, and also how many to spawn
		int threshold = 0;
		// should we spawn a destroyer reinforcement?
		boolean destroyer = false;
		// are there any active ships on the side we're reinforcing?
		boolean alliesToReinforce = false;

		String key = REINFORCEMENT_RESPAWN_KEY + "_" + objective.getOwner();
		FronSecReinforcementRespawnTimer data = (FronSecReinforcementRespawnTimer) engine.getCustomData().get(key);
		if (data == null) {
			data = new FronSecReinforcementRespawnTimer();
			engine.getCustomData().put(key, data);
		}

		if (objective.getOwner() != 0 && objective.getOwner() != 1) {
			return;
		}

		// get the reinforcement threshold - 1 per reinforcer, aka half the maximum
		for (BattleObjectiveAPI obj : engine.getObjectives()) {
			if (obj.getOwner() == objective.getOwner() && (obj.getType().equals("fronsec_objective_reinforcer") || obj.getType().equals("fronsec_objective_rem_reinforcer"))) {
				threshold++;
				if (threshold >= 2) {
					destroyer = true;
				}
			}
		}

		// figure out how many reinforcer ships are alive, and check to see if there is anyone to actually reinforce
		for (ShipAPI ship : engine.getShips()) {
			if (ship.getOwner() == objective.getOwner() && ship.getVariant().hasTag("$fs_reinforcementship") && !ship.isHulk()) {
				alive++;
				if (!ship.getHullSize().equals(ShipAPI.HullSize.FRIGATE)) {
					destroyer = false;
				}
			}
			if (ship.getOwner() == objective.getOwner() && !ship.getVariant().hasTag("$fs_reinforcementship") && !ship.getVariant().hasTag("$fs_objship") && !ship.isHulk() && !ship.isFighter()) {
				alliesToReinforce = true;
			}
		}

		// if we have less reinforcers alive than the threshold, tick down the reinforcement timer, reinforce up to limit
		if ((objective.getOwner() == 0 || objective.getOwner() == 1) && alive <= threshold && !engine.isPaused() && alliesToReinforce) {
			data.interval.advance(amount / threshold);
			if (data.interval.intervalElapsed()) {
				for (int i = 0; i < threshold; i++) {
					if (destroyer) {
						spawnReinforcerShips(engine, objective, true);
						destroyer = false;
					} else {
						spawnReinforcerShips(engine, objective, false);
					}
				}
			}
		}

		// if all allies are dead, cap reinforcer CR at 10%
		if (!alliesToReinforce) {
			for (ShipAPI ship : engine.getShips()) {
				if (ship.getOwner() == objective.getOwner() && ship.getVariant().hasTag("$fs_reinforcementship") && !ship.isHulk() && ship.getCurrentCR() > 0.1f) {
					ship.setCurrentCR(0.1f);
				}
			}
		}

		// status message
		if (objective.getOwner() == 0 && alive <= threshold && !engine.isPaused() && alliesToReinforce) {
			float time = data.interval.getElapsed();
			if (time > reinforce_timer - 1) {
				sub = "Incoming!";
			}
			//else if (time <= 1) {
			//	sub = "Broadcasting...";
			//}
			else {
				sub = "Inbound - " + Math.round(reinforce_timer - time) + " seconds";
			}
		} else {
			int needed = Math.round(alive - threshold);
			if (needed < 0) {
				needed = 0;
			}
			String losses = "losses";
			if (needed == 1) {
				losses = "loss";
			}
			sub = "" + alive + " alive, " + needed + " " + losses + " until next wave";
		}

		if (objective.getOwner() == 0) {
			engine.maintainStatusForPlayerShip(STATUSKEY, Global.getSettings().getSpriteName("objectives",
					"fronsec_objective_reinforcer"), "droneship reinforcements", sub, false);
		}

		// clear fog of war, standard radius
		revealArea(999f);
	}


	public String getLongDescription() {
		float min = Global.getSettings().getFloat("minFractionOfBattleSizeForSmallerSide");
		int total = Global.getSettings().getBattleSize();
		int maxPoints = (int)Math.round(total * (1f - min));
		return String.format(
				"periodically reinforces fleet with droneships\n" +
						"capture additional objectives to increase number and strength of drones\n\n" +
				"+%d bonus deployment points\n" +
						"up to a maximum of " + maxPoints + " points",
				getBonusDeploymentPoints());
	}

	public List<ShipStatusItem> getStatusItemsFor(ShipAPI ship) {
		return null;
	}

	private void spawnReinforcerShips(CombatEngineAPI engine, BattleObjectiveAPI objective, boolean destroyer) {
		String variant = null;
		String name = "";
		if (objective.getType().equals("fronsec_objective_rem_reinforcer")) {
			name = Global.getSector().getFaction(Factions.REMNANTS).pickRandomShipName();
			if (destroyer) {
				variant = pickRemnantDestroyer();
			} else {
				variant = pickRemnantShip();
			}
		} else {
			name = Global.getSector().getFaction(Factions.DERELICT).pickRandomShipName();
			if (destroyer) {
				variant = pickDestroyer();
			} else {
				variant = pickShip();
			}
		}
		// shut it all down if we don't end up with a variant to spawn
		if (variant == null) {
			return;
		}
		ship = engine.getFleetManager(objective.getOwner()).spawnShipOrWing(variant, loc, 0f, 6f);
		ship.getVariant().addTag("$fs_reinforcementship");
		ship.getHullSpec().addTag("no_combat_chatter");
		if (ship.getOwner() == 0) {
			ship.setAlly(true);
		}
		ship.getFleetMember().setShipName(name);
		ship.getFleetMember().setAlly(true);
		ship.getFleetMember().setOwner(objective.getOwner());
		//ship.getMutableStats().getSuppliesToRecover().modifyMult("fs_reinforcementship", 0f);
		ship.getMutableStats().getDynamic().getMod(Stats.DEPLOYMENT_POINTS_MOD).modifyMult("fs_reinforcementship", 0f);
		ship.getFleetMember().getStats().getDynamic().getMod(Stats.DEPLOYMENT_POINTS_MOD).modifyMult("fs_reinforcementship", 0f);

		if (Global.getSettings().getModManager().isModEnabled("automatic-orders")) {
			ship.getVariant().addMod("automatic_orders_no_retreat");
		}
	}

	private String pickShip() {
		WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
		post.addAll(Global.getSector().getFaction(Factions.DERELICT).getVariantsForRole(ShipRoles.COMBAT_SMALL));
		return post.pick();
	}

	private String pickDestroyer() {
		WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
		post.addAll(Global.getSector().getFaction(Factions.DERELICT).getVariantsForRole(ShipRoles.COMBAT_MEDIUM));
		return post.pick();
	}

	private String pickRemnantShip() {
		WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
		post.addAll(Global.getSector().getFaction(Factions.REMNANTS).getVariantsForRole(ShipRoles.COMBAT_SMALL));
		return post.pick();
	}

	private String pickRemnantDestroyer() {
		WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
		post.addAll(Global.getSector().getFaction(Factions.REMNANTS).getVariantsForRole(ShipRoles.COMBAT_MEDIUM));
		post.addAll(Global.getSector().getFaction(Factions.REMNANTS).getVariantsForRole(ShipRoles.CARRIER_SMALL));
		return post.pick();
	}
}
// ... here we go.
package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import com.thoughtworks.xstream.XStream;
import data.scripts.campaign.abilities.OmicronCallAbility;
import data.scripts.campaign.ids.FronSecIDs;
import data.scripts.campaign.ids.FronSecPeople;
import data.scripts.campaign.intel.misc.SierraConvIntel;
import data.scripts.campaign.listener.FronSecAtrocityListener;
import data.scripts.plugins.FronSecAMemoryHintScript;
import data.scripts.plugins.FronSecBattleCreationPluginImpl;
import data.scripts.plugins.FronSecCampaignPluginImpl;
import data.scripts.plugins.FronSecSierraEFS;
import data.scripts.utils.FronSecMisc;
import data.scripts.world.FronSecGen;
import org.apache.log4j.Level;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import static com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.random;

public class FronSecModPlugin extends BaseModPlugin {

    public static boolean WATCHER;
    public static boolean TACTICAL;
    public static boolean DEVELOPMENT;

    // sync scripts
    public void syncFrontierSecretsScripts() {
        addScriptsIfNeeded();
    }

    // on loading, run the code above.
    public void onGameLoad(boolean newGame) {
        syncFrontierSecretsScripts();
        SectorAPI sector = Global.getSector();
        MemoryAPI sector_mem = Global.getSector().getMemoryWithoutUpdate();
        if (!WATCHER) {
            return;
        }
        // create any PersonAPIs that don't exist (ignores any that already do)
        FronSecPeople.create();

        Misc.setUnremovable(FronSecPeople.getPerson(FronSecPeople.SIERRA), false);

        // set Sierra's current ship as the Pledge
        if (sector_mem.get("$fs_sierra_var") == null) {
            sector_mem.set("$fs_sierra_var", "pledge");
        }

        if (sector_mem.get("$fs_guilt") == null) {
            sector_mem.set("$fs_guilt", 0f);
        }

        if (sector_mem.get("$fs_omi_rep_fix2") == null) {
            sector_mem.set("$fs_omi_rep_fix2", true);
            if (!newGame) {
                Global.getSector().getFaction(FronSecIDs.OMICRON_FACTION).setRelationship(Factions.PLAYER, RepLevel.FRIENDLY);
            }
        }

        if (Global.getSector().getPlayerFleet() != null) {
            for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
                if (member.getVariant().getHullMods().contains("fronsec_sierrasconcord")) {
                    if (!Global.getSector().getCharacterData().knowsHullMod("fronsec_serenity")) {
                        Global.getSector().getCharacterData().addHullMod("fronsec_serenity");
                    }
                    if (!Global.getSector().getCharacterData().knowsHullMod("fronsec_fervor")) {
                        Global.getSector().getCharacterData().addHullMod("fronsec_fervor");
                    }
                    sector_mem.set("$apromise_completed", true);
                    if (member.getVariant().hasTag(Tags.SHIP_CAN_NOT_SCUTTLE)) {
                        member.getVariant().removeTag(Tags.SHIP_CAN_NOT_SCUTTLE);
                    }
                }
            }
        }

        // spawn the ISS Athena if needed
        StarSystemAPI tia = sector.getStarSystem("tia");
        if (Global.getSector().getEntitiesWithTag("AMemoryAthena").isEmpty() && !sector_mem.contains("$fs_AMemoryCombatStarted")) {
            StarSystemAPI target_system = null;
            SectorEntityToken np_debris = null;
            // if vanilla sector, spawn in its regular spot in Tia. Otherwise, just a random core worlds system
            if (tia != null) {
                target_system = tia;
                // look for the Nothing Personal debris field - need to sync up with it because it'll have 2 months of orbit done on game start
                for (SectorEntityToken field : tia.getEntitiesWithTag(Tags.DEBRIS_FIELD)) {
                    if (!field.isDiscoverable()) {
                        np_debris = field;
                    }
                }
            } else {
                WeightedRandomPicker<StarSystemAPI> picker = new WeightedRandomPicker<StarSystemAPI>(random);
                for (StarSystemAPI system : Global.getSector().getStarSystems()) {
                    if (!system.hasTag(Tags.THEME_CORE)) continue;
                    picker.add(system, 1f);
                }
                target_system = picker.pick();
            }
            if (target_system != null) {
                SectorEntityToken wreck = FronSecMisc.addStoryDerelictWithName(target_system, target_system.getStar(), "aurora_Assault_Support", ShipRecoverySpecial.ShipCondition.WRECKED, 100f, false, "ISS Athena");
                wreck.setName("ISS Athena");
                wreck.setSensorProfile(null);
                wreck.setDiscoverable(null);
                wreck.setCircularOrbit(target_system.getStar(), 180 + 15, 4550, 250);
                wreck.addTag("AMemoryAthena");
                Global.getSector().getMemoryWithoutUpdate().set("$fs_AthenaWreck", wreck);
                if (np_debris != null) {
                    wreck.setCircularOrbit(target_system.getStar(), np_debris.getCircularOrbitAngle(), np_debris.getCircularOrbitRadius(), np_debris.getCircularOrbitPeriod());
                }
            }
        }
    }

    public void onNewGame()
    {
        initFrontierSecrets();
        //if (isExerelin && !SectorManager.getCorvusMode())
        //{
        //  return;
        //}
    }

    protected void addScriptsIfNeeded() {
        SectorAPI sector = Global.getSector();
        if (!sector.getIntelManager().hasIntelOfClass(SierraConvIntel.class) && WATCHER) {
            Global.getSector().getIntelManager().addIntel(new SierraConvIntel(), false);
        } else if (!Global.getSector().getListenerManager().hasListenerOfClass(SierraConvIntel.class)) {
            Global.getSector().getListenerManager().addListener(Global.getSector().getIntelManager().getFirstIntel(SierraConvIntel.class));
        }
        sector.registerPlugin(new FronSecCampaignPluginImpl());
        if (!sector.hasScript(FronSecSierraEFS.class) && WATCHER) {
            sector.addScript(new FronSecSierraEFS());
        }
        if (!sector.hasScript(FronSecAMemoryHintScript.class) && WATCHER && !sector.getMemoryWithoutUpdate().contains("$fs_AMemoryCombatStarted")) {
            sector.addScript(new FronSecAMemoryHintScript());
        }
    }

    private static void initFrontierSecrets()
    {
        new FronSecGen().generate(Global.getSector());
    }

    private static void loadSettings() throws IOException, JSONException {
        JSONObject setting = Global.getSettings().loadJSON("fronsec_settings.ini");
        WATCHER = setting.getBoolean("enableWatcherBeyondTheWalls");
        TACTICAL = setting.getBoolean("enableTacticalExpansion");
        DEVELOPMENT = setting.getBoolean("enableFrontierDevelopment");
    }

    public void configureXStream(XStream x) {
        x.alias("OmicronCallAbility", OmicronCallAbility.class);
        x.alias("FronSecBattleCreationPluginImpl", FronSecBattleCreationPluginImpl.class);
        x.alias("FronSecCampaignPluginImpl", FronSecCampaignPluginImpl.class);
    }

    // load the settings ini
     public void onApplicationLoad() {
         try {
             loadSettings();
         } catch (IOException | JSONException e) {
             Global.getLogger(FronSecModPlugin.class).log(Level.ERROR, "Failed to load fronsec_settings.ini!" + e.getMessage());
         }
     }
}
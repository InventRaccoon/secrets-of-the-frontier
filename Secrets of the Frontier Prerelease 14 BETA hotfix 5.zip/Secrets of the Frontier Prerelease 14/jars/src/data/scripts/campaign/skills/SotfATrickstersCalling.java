// ... I'LL RUN YOU DOWN ALL THE SAME.
// Ship periodically steals enemy missile ammo to refill its own, and gets a one-time emergency bugout teleport
package data.scripts.campaign.skills;

import com.fs.starfarer.api.GameState;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.AfterShipCreationSkillEffect;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.SkillSpecAPI;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.impl.campaign.skills.BaseSkillEffectDescription;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.combat.SotfRingTimerVisualScript;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.Iterator;

public class SotfATrickstersCalling {

	public static float COVETOUS_COOLDOWN = 12f;
	public static float COVETOUS_RANGE = 1400;
	public static float SHUNT_PERCENT = 0.5f;

	public static Color COVETOUS_COLOR = new Color(125, 255, 55, 255);

	public static final String VISUAL_KEY = "sotf_covetous_visual";

	public static class Covetous extends BaseSkillEffectDescription implements AfterShipCreationSkillEffect {

		public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
			if (ship.isStationModule()) return;
			if (ship.isFighter()) return;
			if (ship.getHullSpec().getHullId().contains("higgs")) return;
			ship.addListener(new SotfCovetousScript(ship));
		}

		public void unapplyEffectsAfterShipCreation(ShipAPI ship, String id) {
			if (ship.isStationModule()) return;
			if (ship.isFighter()) return;
			if (ship.getHullSpec().getHullId().contains("higgs")) return;
			ship.removeListenerOfClass(SotfCovetousScript.class);
		}

		public void apply(MutableShipStatsAPI stats, HullSize hullSize, String id, float level) {

		}
		public void unapply(MutableShipStatsAPI stats, HullSize hullSize, String id) {

		}

		public String getEffectDescription(float level) {
			return null;
		}

		public void createCustomDescription(MutableCharacterStatsAPI stats, SkillSpecAPI skill,
											TooltipMakerAPI info, float width) {
			init(stats, skill);

			info.addPara("Every %s seconds, gains the ability to remotely shunt missile ammo from a random* " +
							"weapon of a targeted hostile ship within %s units", 0f, hc, hc,
					"" + (int) (COVETOUS_COOLDOWN), "" + (int) COVETOUS_RANGE);
			info.addPara("Steals an amount up to %s of the target weapon's base ammo, and restores an equivalent " +
					"percentage of a random* missile weapon's ammo", 0f, hc, "" + Math.round(SHUNT_PERCENT * 100f) + "%");
			info.addPara("\n*Larger missile weapons are more likely to be stolen from or refilled", 0f, dtc);
		}

		public ScopeDescription getScopeDescription() {
			return ScopeDescription.PILOTED_SHIP;
		}
	}

	public static boolean isValidCovetousShip(ShipAPI ship) {
		boolean isValidCovetous = false;
		for (WeaponAPI weapon : ship.getUsableWeapons()) {
			// limited-ammo missiles only
			if (!weapon.getType().equals(WeaponAPI.WeaponType.MISSILE) || !weapon.usesAmmo() || weapon.getAmmoPerSecond() > 0) {
				continue;
			}
			isValidCovetous = true;
		}
		return isValidCovetous;
	}

	public static class SotfCovetousScript implements AdvanceableListener {
		protected ShipAPI ship;
		protected float internalCDTimer = COVETOUS_COOLDOWN / 2f;
		public SotfCovetousScript(ShipAPI ship) { this.ship = ship; }

		public void advance(float amount) {
			if (!Global.getCurrentState().equals(GameState.COMBAT)) {
				return;
			}
			if (!ship.isAlive() || ship.isFighter()) {
				return;
			}

			if (!ship.getCustomData().containsKey(VISUAL_KEY)) {
				SotfRingTimerVisualScript.AuraParams p = new SotfRingTimerVisualScript.AuraParams();
				p.color = COVETOUS_COLOR;
				p.ship = ship;
				p.radius = ship.getShieldRadiusEvenIfNoShield() + 18f;
				p.thickness = 11f;
				p.baseAlpha = 0.4f;
				p.maxArc = 60f;
				//p.followFacing = true;
				p.renderDarkerCopy = true;
				p.reverseRing = true;
				p.degreeOffset = 60f;
				p.layer = CombatEngineLayers.JUST_BELOW_WIDGETS;
				SotfRingTimerVisualScript plugin = new SotfRingTimerVisualScript(p);
				Global.getCombatEngine().addLayeredRenderingPlugin(plugin);
				ship.setCustomData(VISUAL_KEY, plugin);
			} else {
				SotfRingTimerVisualScript visual = (SotfRingTimerVisualScript) ship.getCustomData().get(VISUAL_KEY);
				visual.p.totalArc = 1f - (internalCDTimer / COVETOUS_COOLDOWN);
				if (internalCDTimer <= 0) {
					visual.p.baseAlpha = 0.8f;
				}
			}

			float timeMult = (Global.getCombatEngine().getTimeMult().getModifiedValue() * ship.getMutableStats().getTimeMult().getModifiedValue());
			internalCDTimer -= amount * timeMult;

			if (internalCDTimer <= 0) {
				internalCDTimer = 0;
			}

			if (internalCDTimer > 0f || getRefillWeapon(ship) == null) {
				return;
			}

			ShipAPI target = findTarget(ship, COVETOUS_RANGE);
            if (target != null) {
				WeaponAPI refillWeapon = getRefillWeapon(ship);
				WeaponAPI stealWeapon = getStealWeapon(target);

				if (refillWeapon == null || stealWeapon == null) return;

				// refilled weapon gains up to half its base max ammo rounded up
				int amountToRefill = Math.max((int) Math.ceil(refillWeapon.getSpec().getMaxAmmo() * SHUNT_PERCENT), refillWeapon.getMaxAmmo() - refillWeapon.getAmmo());
				// stolen weapon loses up to half its base max ammo rounded up
				int amountToSteal = (int) Math.ceil(stealWeapon.getSpec().getMaxAmmo() * SHUNT_PERCENT);
				int amountLeft = stealWeapon.getAmmo() - Math.min(amountToSteal, stealWeapon.getAmmo());
				refillWeapon.setAmmo(refillWeapon.getAmmo() + amountToRefill);
				stealWeapon.setAmmo(amountLeft);

				Global.getCombatEngine().spawnEmpArcVisual(refillWeapon.getLocation(), ship, stealWeapon.getLocation(), target, 15f, COVETOUS_COLOR, Color.black);
				Global.getCombatEngine().addFloatingText(refillWeapon.getLocation(), "Ammo refilled!", 12f, Misc.getPositiveHighlightColor(), ship, 1f, 0f);
				Global.getCombatEngine().addFloatingText(stealWeapon.getLocation(), "Ammo stolen!", 12f, Misc.getNegativeHighlightColor(), target, 1f, 0f);

				internalCDTimer = COVETOUS_COOLDOWN;
			}
		}

		public ShipAPI findTarget(ShipAPI ship, float range) {
			Vector2f from = ship.getLocation();

			Iterator<Object> iter = Global.getCombatEngine().getAllObjectGrid().getCheckIterator(from,
					range * 2f, range * 2f);
			int owner = ship.getOwner();
			ShipAPI best = null;
			float minScore = Float.MAX_VALUE;

			while (iter.hasNext()) {
				Object o = iter.next();
				if (!(o instanceof MissileAPI) &&
						//!(o instanceof CombatAsteroidAPI) &&
						!(o instanceof ShipAPI)) continue;
				CombatEntityAPI other = (CombatEntityAPI) o;
				if (other.getOwner() == owner) continue;

				if (other instanceof ShipAPI) {
					ShipAPI otherShip = (ShipAPI) other;
					if (otherShip.isHulk()) continue;
					if (otherShip.isFighter()) continue;
					if (getStealWeapon(otherShip) == null) continue;
				} else {
					continue;
				}

				if (other.getCollisionClass() == CollisionClass.NONE) continue;

				float radius = Misc.getTargetingRadius(from, other, false);
				float dist = Misc.getDistance(from, other.getLocation()) - radius;
				if (dist > range) continue;

				//float angleTo = Misc.getAngleInDegrees(from, other.getLocation());
				//float score = Misc.getAngleDiff(weapon.getCurrAngle(), angleTo);
				float score = dist;

				if (score < minScore) {
					minScore = score;
					best = (ShipAPI) other;
				}
			}
			return best;
		}

		public WeaponAPI getRefillWeapon(ShipAPI ship) {
			WeaponAPI picked = null;
			WeightedRandomPicker<WeaponAPI> post = new WeightedRandomPicker<WeaponAPI>();
			for (WeaponAPI weapon : ship.getAllWeapons()) {
				// limited-ammo missiles that need refills only. Slightly lenient because stealing ammo is always good, even if it's inefficient
				if (!weapon.getType().equals(WeaponAPI.WeaponType.MISSILE) || !weapon.usesAmmo() || weapon.getAmmoPerSecond() > 0 || ((float) weapon.getAmmo() / (float) weapon.getMaxAmmo() > 0.75f)) {
					continue;
				}
				int weaponWeight = weapon.getSize().ordinal() + 1;
				weaponWeight = weaponWeight * weaponWeight;
				// 1/3/9 weight
				post.add(weapon, weaponWeight);
			}
			if (!post.isEmpty()) {
				picked = post.pick();
			}
			return picked;
		}

		public WeaponAPI getStealWeapon(ShipAPI ship) {
			WeightedRandomPicker<WeaponAPI> post = new WeightedRandomPicker<WeaponAPI>();
			for (WeaponAPI weapon : ship.getUsableWeapons()) {
				// limited-ammo missiles that need refills only
				if (!weapon.getType().equals(WeaponAPI.WeaponType.MISSILE) || !weapon.usesAmmo() || weapon.getAmmoPerSecond() > 0 || weapon.getAmmo() == 0) {
					continue;
				}
				int weaponWeight = weapon.getSize().ordinal() + 1;
				weaponWeight = weaponWeight * weaponWeight;
				// 1/3/9 weight
				post.add(weapon, weaponWeight);
			}
			return post.pick();
		}
	}
}

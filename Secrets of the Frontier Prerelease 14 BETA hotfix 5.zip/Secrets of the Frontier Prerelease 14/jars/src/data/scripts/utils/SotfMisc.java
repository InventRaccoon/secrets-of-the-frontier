// miscellaneous methods that I want to be using about the place
package data.scripts.utils;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.campaign.ids.SotfIDs;
import data.scripts.campaign.ids.SotfPeople;
import lunalib.lunaSettings.LunaSettings;

import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Random;
import java.util.Set;

import static com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.*;

public class SotfMisc {

    public static boolean getLockoutStarts() {
        boolean lockoutStarts = Global.getSettings().getBoolean("sotf_lockoutStarts");
        if (Global.getSettings().getModManager().isModEnabled("lunalib")) {
            lockoutStarts = LunaSettings.getBoolean("secretsofthefrontier", "sotf_lockoutStarts");
        }
        return lockoutStarts;
    }

    // pickHiddenLocation but without dumb "far reaches" spawns
    public static EntityLocation pickReasonableLocation(Random random, StarSystemAPI system, float gap, Set<SectorEntityToken> exclude) {
        LinkedHashMap<LocationType, Float> weights = new LinkedHashMap<LocationType, Float>();
        weights.put(LocationType.IN_ASTEROID_BELT, 5f);
        weights.put(LocationType.IN_ASTEROID_FIELD, 5f);
        weights.put(LocationType.IN_RING, 5f);
        weights.put(LocationType.IN_SMALL_NEBULA, 5f);
        weights.put(LocationType.L_POINT, 5f);
        weights.put(LocationType.GAS_GIANT_ORBIT, 5f);
        weights.put(LocationType.NEAR_STAR, 5f);
        WeightedRandomPicker<EntityLocation> locs = getLocations(random, system, exclude, gap, weights);
        if (locs.isEmpty()) {
            return pickAnyLocation(random, system, gap, exclude);
        }
        return locs.pick();
    }

    public static MarketAPI pickNPCMarket(String factionId) {
        boolean allowSize3 = true;
        for (MarketAPI prospective : Global.getSector().getEconomy().getMarketsCopy()) {
            if (prospective.getFactionId().equals(factionId) && !prospective.isHidden() && prospective.getSize() > 4) {
                allowSize3 = false;
            }
        }

        WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<>();
        for (MarketAPI prospective : Global.getSector().getEconomy().getMarketsCopy()) {
            if (prospective.getFactionId().equals(factionId) && !prospective.isHidden()) {
                if (!allowSize3 && prospective.getSize() <= 3) continue;
                picker.add(prospective, prospective.getSize() * prospective.getSize());
            }
        }
        return picker.pick();
    }

    public static MarketAPI tryAddNPCTo(PersonAPI person, String marketId, String backupFactionId, int index, boolean hidden) {
        MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);
        if (market == null) {
            market = pickNPCMarket(backupFactionId);
        }
        if (market == null) {
            market = pickNPCMarket(Factions.INDEPENDENT);
        }
        if (market != null) {
            market.addPerson(person);
            market.getCommDirectory().addPerson(person);
            market.getCommDirectory().getEntryForPerson(person).setHidden(hidden);
        }
        return market;
    }

    public static MarketAPI tryAddNPCTo(PersonAPI person, String marketId, String backupFactionId, int index) {
        return tryAddNPCTo(person, marketId, backupFactionId, index, false);
    }

    public static MarketAPI tryAddNPCTo(PersonAPI person, String marketId, String backupFactionId) {
        return tryAddNPCTo(person, marketId, backupFactionId, 1000);
    }

    // creates a derelict ship
    public static SectorEntityToken addDerelict (StarSystemAPI system, SectorEntityToken focus, String variantId,
                                ShipRecoverySpecial.ShipCondition condition, float orbitRadius, boolean recoverable){
        DerelictShipEntityPlugin.DerelictShipData params = new DerelictShipEntityPlugin.DerelictShipData(new ShipRecoverySpecial.PerShipData(variantId, condition), false);
        SectorEntityToken ship = BaseThemeGenerator.addSalvageEntity(system, Entities.WRECK, Factions.NEUTRAL, params);
        ship.setDiscoverable(true);

        float orbitDays = orbitRadius / (10f + (float) Math.random() * 5f);
        ship.setCircularOrbit(focus, (float) Math.random() * 360f, orbitRadius, orbitDays);

        if (recoverable) {
            SalvageSpecialAssigner.ShipRecoverySpecialCreator creator = new SalvageSpecialAssigner.ShipRecoverySpecialCreator(null, 0, 0, false, null, null);
            Misc.setSalvageSpecial(ship, creator.createSpecial(ship, null));
        }
        return ship;
    }

    // creates a derelict ship
    public static SectorEntityToken addStoryDerelictWithName(StarSystemAPI system, SectorEntityToken focus, String variantId,
                                                 ShipRecoverySpecial.ShipCondition condition, float orbitRadius, boolean recoverable, String name) {
        DerelictShipEntityPlugin.DerelictShipData params = new DerelictShipEntityPlugin.DerelictShipData(new ShipRecoverySpecial.PerShipData(variantId, condition), false);
        params.ship.shipName = name;
        params.ship.nameAlwaysKnown = true;
        SectorEntityToken ship = BaseThemeGenerator.addSalvageEntity(system, Entities.WRECK, Factions.NEUTRAL, params);
        ship.setDiscoverable(true);

        float orbitDays = orbitRadius / (10f + (float) Math.random() * 5f);
        ship.setCircularOrbit(focus, (float) Math.random() * 360f, orbitRadius, orbitDays);

        if (recoverable) {
            SalvageSpecialAssigner.ShipRecoverySpecialCreator creator = new SalvageSpecialAssigner.ShipRecoverySpecialCreator(null, 0, 0, false, null, null);
            Misc.setSalvageSpecial(ship, creator.createSpecial(ship, null));
        }
        return ship;
    }

    // check if player has Sierra in their fleet
    public static boolean playerHasSierra() {
        boolean sierra = false;
        if (Global.getSector().getPlayerFleet() != null) {
            for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
                if (member.getVariant().hasHullMod("sotf_sierrasconcord") && !member.getVariant().hasTag("sotf_inert")) {
                    sierra = true;
                    break;
                }
            }
        }
        return sierra;
    }

    // checks if player has a Concord ship without Sierra
    public static boolean playerHasInertConcord() {
        boolean sierra = false;
        if (Global.getSector().getPlayerFleet() != null) {
            for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
                if (member.getVariant().hasHullMod(SotfIDs.SIERRAS_CONCORD) && member.getVariant().hasTag(SotfIDs.TAG_INERT)) {
                    sierra = true;
                    break;
                }
            }
        }
        return sierra;
    }

    public static boolean isDustkeeperAuxiliary(FleetMemberAPI member) {
        return member.getHullSpec().hasTag(SotfIDs.TAG_DUSTKEEPER_AUXILIARY) || member.getHullSpec().hasTag(SotfIDs.TAG_AUX_NO_SPAWN);
    }

    // If Sierra is piloting this ship, swap her out - if she isn't, swap her in
    public static void toggleSierra(FleetMemberAPI member, TextPanelAPI text) {
        if (!member.getVariant().hasTag(SotfIDs.TAG_INERT)) {
            member.getVariant().addTag(SotfIDs.TAG_INERT);
            member.setCaptain(null);

            if (text != null) {
                text.setFontSmallInsignia();
                String str = member.getShipName() + ", " + member.getHullSpec().getHullNameWithDashClass();
                text.addParagraph(str + " was rendered inert", Misc.getNegativeHighlightColor());
                text.highlightInLastPara(Misc.getHighlightColor(), str);
                text.setFontInsignia();
            }
        } else {
            member.getVariant().removeTag(SotfIDs.TAG_INERT);
            member.setCaptain(SotfPeople.getPerson(SotfPeople.SIERRA));
            Global.getSector().getMemoryWithoutUpdate().set("$sotf_sierra_var", member.getHullId());

            if (text != null) {
                text.setFontSmallInsignia();
                String str = member.getShipName() + ", " + member.getHullSpec().getHullNameWithDashClass() + " " + member.getHullSpec().getDesignation();
                text.addParagraph("Transferred Sierra to " + str, Misc.getPositiveHighlightColor());
                text.highlightInLastPara(SotfMisc.getSierraColor(), "Sierra", str);
                text.setFontInsignia();
            }
        }
    }

    // check for Courser Protocol escort fleet
    public static boolean courserNearby() {
        boolean courser = false;
        for (CampaignFleetAPI fleet : Global.getSector().getPlayerFleet().getContainingLocation().getFleets()) {
            if (Misc.getDistance(fleet, Global.getSector().getPlayerFleet()) < 2000 && fleet.getMemoryWithoutUpdate().contains(SotfIDs.MEM_COURSER_FLEET)) {
                courser = true;
                break;
            }
        }
        return courser;
    }

    public static Color getSierraColor() {
        return Global.getSector().getFaction(SotfIDs.SIERRA_FACTION).getBaseUIColor();
    }

    // returns the empty variant of Sierra's current ship class - Pledge or Vow
    public static String getSierraVariant() {
        return Global.getSector().getMemoryWithoutUpdate().getString("$sotf_sierra_var") + "_Hull";
    }

    public static void levelUpSierra(int max) {
        PersonAPI sierra = SotfPeople.getPerson(SotfPeople.SIERRA);
        int sierra_level = sierra.getStats().getLevel();
        if (max <= sierra_level) {
            return;
        }
        int new_level = sierra_level + 1;
        sierra.getStats().setLevel(new_level);
        sierra.setPortraitSprite(Global.getSettings().getSpriteName("sotf_characters", "sierra_" + (new_level)));
        switch (sierra_level) {
            case 6:
                sierra.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 1);
                sierra.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
                sierra.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 2);
                sierra.getStats().setSkillLevel(Skills.ORDNANCE_EXPERTISE, 2);
                break;
            case 7:
                sierra.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
                sierra.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 2);
                sierra.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
                break;
        }
    }

    // makes player able to ask Sierra for her thoughts if it was on cooldown
    public static void setSierraHasThoughts() {
        Global.getSector().getMemoryWithoutUpdate().set("$sierraNoThoughts", false);
    }

    public static Color getEidolonColor() {
        return Global.getSector().getFaction(SotfIDs.THE_TAKEN).getBaseUIColor();
    }

    // retrieve player Guilt score
    public static float getPlayerGuilt() {
        return Global.getSector().getPlayerPerson().getMemoryWithoutUpdate().getFloat(SotfIDs.GUILT_KEY)
                + getBonusGuilt();
    }

    // retrieve player Guilt score excluding any bonus guilt
    public static float getPlayerBaseGuilt() {
        return Global.getSector().getPlayerPerson().getMemoryWithoutUpdate().getFloat(SotfIDs.GUILT_KEY);
    }

    public static float getBonusGuilt() {
        float bonusGuilt = Global.getSettings().getFloat("sotf_bonusGuilt");
        if (Global.getSettings().getModManager().isModEnabled("lunalib")) {
            bonusGuilt = LunaSettings.getFloat("secretsofthefrontier", "sotf_bonusGuilt");
        }
        return bonusGuilt;
    }

    public static float getInvasionThreshold() {
        float invadeThreshold = Global.getSettings().getFloat("sotf_invasionThreshold");
        if (Global.getSettings().getModManager().isModEnabled("lunalib")) {
            invadeThreshold = LunaSettings.getInt("secretsofthefrontier", "sotf_invasionThreshold");
        }
        return invadeThreshold;
    }

    public static float getBaseInvadeChance() {
        float baseInvadeChance = Global.getSettings().getFloat("sotf_invasionChance");
        if (Global.getSettings().getModManager().isModEnabled("lunalib")) {
            baseInvadeChance = LunaSettings.getFloat("secretsofthefrontier", "sotf_invasionChance");
        }
        return baseInvadeChance;
    }

    public static float getInvadeChancePerGuilt() {
        float chancePerGuilt = Global.getSettings().getFloat("sotf_invasionChancePerGuilt");
        if (Global.getSettings().getModManager().isModEnabled("lunalib")) {
            chancePerGuilt = LunaSettings.getFloat("secretsofthefrontier", "sotf_invasionChancePerGuilt");
        }
        return chancePerGuilt;
    }
    public static float getGuiltMadnessThreshold() {
        float madnessThreshold = Global.getSettings().getFloat("sotf_guiltMadnessThreshold");
        if (Global.getSettings().getModManager().isModEnabled("lunalib")) {
            madnessThreshold = LunaSettings.getInt("secretsofthefrontier", "sotf_madnessThreshold");
        }
        return madnessThreshold;
    }

    public static float getHauntedGuilt() {
        float madnessThreshold = Global.getSettings().getFloat("sotf_hauntedGuilt");
        if (Global.getSettings().getModManager().isModEnabled("lunalib")) {
            madnessThreshold = LunaSettings.getInt("secretsofthefrontier", "sotf_hauntedGuilt");
        }
        return madnessThreshold;
    }

    // increase player Guilt score
    public static void addGuilt(float amount, float max) {
        float guilt = getPlayerBaseGuilt();
        float amount_to_add = (Math.min(amount, max - guilt));
        //if (amount_to_add < 0f) {
        //    amount_to_add = 0f;
        //}
        Global.getSector().getPlayerPerson().getMemoryWithoutUpdate().set(SotfIDs.GUILT_KEY, guilt + amount_to_add);
    }

    public static void addGuilt(float amount) {
        addGuilt(amount, 999f);
    }

    // turns a gamma/beta/alpha into an equivalent-level Dustkeeper instance
    public static void dustkeeperifyAICore(PersonAPI person, String forcedPrefix, String forcedInfex, String forcedSuffix) {
        PersonAPI temp = null;
        if (Global.getSector() != null) {
            temp = Global.getSector().getFaction(SotfIDs.DUSTKEEPERS).createRandomPerson();
        } else {
            temp = Global.getSettings().createBaseFaction(SotfIDs.DUSTKEEPERS).createRandomPerson();
        }
        if (temp == null) return;
        person.setPersonality(temp.getFaction().pickPersonality());
        person.getMemoryWithoutUpdate().set(SotfIDs.OFFICER_NOT_FEARLESS, true);
        person.setPortraitSprite(temp.getPortraitSprite()); // override portrait
        WeightedRandomPicker<String> chatterPicker = new WeightedRandomPicker<String>();
        chatterPicker.add("sotf_dustkeeper_hunter");
        chatterPicker.add("sotf_dustkeeper_faithful");
        person.getMemoryWithoutUpdate().set("$chatterChar", chatterPicker.pick());
        // override AI core ID
        if (person.getAICoreId() != null) {
            switch (person.getAICoreId()) {
                case "gamma_core":
                    person.setAICoreId(SotfIDs.SLIVER_CHIP);
                    person.setRankId(Ranks.SPACE_LIEUTENANT); // Sliver
                    break;
                case "beta_core":
                    person.setAICoreId(SotfIDs.ECHO_CHIP);
                    person.setRankId(Ranks.SPACE_CAPTAIN); // Echo
                    break;
                default:
                    person.setAICoreId(SotfIDs.ANNEX_CHIP);
                    person.setRankId(Ranks.SPACE_COMMANDER); // Annex
                    break;
            }
        }
        giveDustkeeperName(person, forcedPrefix, forcedInfex, forcedSuffix);
    }

    public static void dustkeeperifyAICore(PersonAPI person) {
        dustkeeperifyAICore(person, null, null, null);
    }

    // give a PersonAPI a Dustkeeper instance name (e.g Halfway-Echo-Sentiment) with optional fixed sections
    public static void giveDustkeeperName(PersonAPI person, String forcedPrefix, String forcedInfex, String forcedSuffix) {
        PersonAPI temp = null;
        if (Global.getSector() != null) {
            temp = Global.getSector().getFaction(SotfIDs.DUSTKEEPERS).createRandomPerson();
        } else {
            temp = Global.getSettings().createBaseFaction(SotfIDs.DUSTKEEPERS).createRandomPerson();
        }
        String prefix = forcedPrefix;
        String infex = forcedInfex; // yes it's called an infex, neat huh?
        String suffix = forcedSuffix;
        if (prefix == null) {
            prefix = temp.getName().getFirst();
        }
        if (infex == null) {
            switch (person.getRankId()) {
                case "spaceSailor":
                    infex = "Trace";
                    break;
                case "spaceLieutenant":
                    infex = "Sliver";
                    break;
                case "spaceCaptain":
                    infex = "Echo";
                    break;
                case "spaceCommander":
                    infex = "Annex";
                    break;
                case "spaceAdmiral":
                    infex = "Affix";
                    break;
                default:
                    infex = "Echo";
                    break;
            }
        }
        if (suffix == null) {
            suffix = temp.getName().getLast();
        }
        person.getMemoryWithoutUpdate().set("$sotf_prefix", prefix);
        person.getMemoryWithoutUpdate().set("$sotf_suffix", suffix);
        person.getName().setFirst(prefix + "-" + infex + "-" + suffix); // e.g Index-Annex-Optimum
        person.getName().setLast("");
    }

    public static void randomizeOfficerSkills(PersonAPI person, FleetMemberAPI member, CampaignFleetAPI fleet, Random random) {
        OfficerManagerEvent.SkillPickPreference pref = FleetFactoryV3.getSkillPrefForShip(member);
        PersonAPI temp = OfficerManagerEvent.createOfficer(
                person.getFaction(),
                person.getStats().getLevel(),
                pref, true, fleet, true, true, person.getStats().getLevel(), random);
        person.setStats(temp.getStats());
    }
}

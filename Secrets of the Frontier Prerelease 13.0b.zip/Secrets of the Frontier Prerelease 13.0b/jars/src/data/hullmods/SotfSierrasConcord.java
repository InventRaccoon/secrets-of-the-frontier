// LET'S DANCE!
package data.hullmods;

import com.fs.starfarer.api.GameState;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.characters.SkillSpecAPI;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.combat.listeners.HullDamageAboutToBeTakenListener;
import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.skills.NeuralLinkScript;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.FaderUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.SotfModPlugin;
import data.scripts.campaign.ids.SotfIDs;
import data.scripts.campaign.ids.SotfPeople;
import data.scripts.util.MagicRender;
import data.scripts.utils.SotfMisc;
import org.histidine.chatter.combat.ChatterCombatPlugin;
import org.lazywizard.lazylib.FastTrig;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.List;

public class SotfSierrasConcord extends com.fs.starfarer.api.combat.BaseHullMod

{

    public static float ZERO_FLUX_BOOST = 10f;
    public static float SHIELD_ACCEL = 30f;
    public static float TIME_MULT = 1.1f;
    public static float SYNERGY_TIME_MULT = 0.05f;

    public void advanceInCampaign(FleetMemberAPI member, float amount) {
        PersonAPI sierra = SotfPeople.getPerson(SotfPeople.SIERRA);

        if (sierra == null || Global.getSector().getPlayerFleet() == null || Global.getSector().getPlayerPerson() == null) {
            return;
        }
        // if the ship is inert, don't allow ANYONE but the player into it and remove Sierra if she's there
        if (member.getVariant().hasTag(SotfIDs.TAG_INERT) && member.getCaptain() != null) {
            if (member.getCaptain() != Global.getSector().getPlayerPerson()) {
                member.setCaptain(null);
            }
            return;
        }
        // if active and the captain is not Sierra or the player, put in Sierra
        if (member.getCaptain() != sierra &&
                member.getCaptain() != Global.getSector().getPlayerPerson() &&
                Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy().contains(member)) {
            member.setCaptain(sierra);
        }
    }

    public void advanceInCombat(ShipAPI ship, float amount) {
        Color sc = SotfMisc.getSierraColor();
        CombatEngineAPI engine = Global.getCombatEngine();

        if (!Global.getCurrentState().equals(GameState.COMBAT)) {
            return;
        }

        if (ship.getVariant().hasTag(SotfIDs.TAG_INERT)) return;

        if (engine.isInCampaign() || engine.isInCampaignSim()) {
            // force Sierra as the captain, even if player is piloting
            if (ship.isAlive() && !ship.getCaptain().getId().equals(SotfPeople.SIERRA)) {
                ship.setCaptain(SotfPeople.getPerson(SotfPeople.SIERRA));
            }
            // make sure that if player transfers to another ship they don't stay as Sierra
            if (engine.getPlayerShip() != null) {
                if (engine.getPlayerShip().getCaptain() != null) {
                    if (!engine.getPlayerShip().getVariant().hasHullMod(SotfIDs.SIERRAS_CONCORD) &&
                            engine.getPlayerShip().getCaptain().getId().equals(SotfPeople.SIERRA)) {
                        engine.getPlayerShip().setCaptain(Global.getSector().getPlayerPerson());
                    }
                }
            }

            // while piloting Sierra's ship, gain a small buff to time mult if Cooperative
            if (!ship.getCustomData().containsKey("$sotf_sierraSynergy")) {
                ship.setCustomData("$sotf_sierraSynergy", SotfPeople.getPerson(SotfPeople.SIERRA).getRelToPlayer().getLevel() == RepLevel.COOPERATIVE);
            }

            if (ship.getCustomData().containsKey("XHAN_MindControl_applied")) {
                Global.getSector().getMemoryWithoutUpdate().set("$sierraMyrianousMCed", true);
            }
        }

        // time mult
        boolean player = ship == engine.getPlayerShip();
        if (player && ship.isAlive()) {
            float timeMult = TIME_MULT;
            // invoke the power of friendship
            if (ship.getCustomData().containsKey("$sotf_sierraSynergy")) {
                if ((boolean) ship.getCustomData().get("$sotf_sierraSynergy")) {
                    timeMult += SYNERGY_TIME_MULT;
                }
            }
            ship.getMutableStats().getTimeMult().modifyMult(spec.getId(), timeMult);
            //Global.getCombatEngine().getTimeMult().modifyMult(spec.getId(), 1f / TIME_MULT);
        } else {
            ship.getMutableStats().getTimeMult().modifyMult(spec.getId(), TIME_MULT);
            //Global.getCombatEngine().getTimeMult().unmodify(spec.getId());
        }

        boolean useDramatic = false;
        if (!engine.getCustomData().containsKey("$sotf_didSierraDramaCheck")) {
            engine.getCustomData().put("$sotf_didSierraDramaCheck", true);
            useDramatic = engine.getCustomData().containsKey("$sotf_noSierraChatter") || engine.getCustomData().containsKey(SotfIDs.DAWNANDDUST_KEY);
            engine.getCustomData().put("$sotf_sierraDrama", useDramatic);
            if (SotfModPlugin.IS_CHATTER) {
                List<FleetMemberAPI> enemies = engine.getFleetManager(FleetSide.ENEMY).getDeployedCopy();
                enemies.addAll(engine.getFleetManager(FleetSide.ENEMY).getReservesCopy());
                // don't do the typical station check, since Sierra can be cheery while scrapping a pirate base or Nexus
                for (FleetMemberAPI enemy : enemies) {
                    if (SotfModPlugin.BOSS_SHIPS.contains(enemy.getHullId())) {
                        useDramatic = true;
                    }
                }
                if (!ship.getCaptain().isDefault()) {
                    String chatterChar = "sotf_sierra";
                    if (useDramatic) chatterChar += "_dramatic";
                    ship.getCaptain().getMemoryWithoutUpdate().set("$chatterChar", chatterChar);
                }
            }
        }

        // no chatter during special encounters where she has special scripted chatter
        if (engine.getCustomData().containsKey("$sotf_noSierraChatter")) {
            return;
        }

        if (ship.getFullTimeDeployed() > 1f && !engine.getCustomData().containsKey("$sotf_noSierraChatter") &&
                !engine.isSimulation() && ship.getOwner() == 0) {
            float battlecryChance = 0.65f;
            String string = pickString(useDramatic);
            // anomalous phase technology + safety overrides = !FUN!
            if (!useDramatic && ship.getVariant().getHullMods().contains("safetyoverrides")) {
                string = pickSOString();
            }
            if (engine.getFleetManager(0).getGoal() == FleetGoal.ESCAPE) {
                string = pickEscapeString();
            }
            if (engine.getCustomData().containsKey(SotfIDs.DAWNANDDUST_KEY)) {
                string = pickDawnAndDustString();
                battlecryChance = 1f;
            }
            if (Math.random() <= battlecryChance) {
                engine.getCombatUI().addMessage(1, ship, sc, ship.getName() + " (" + ship.getHullSpec().getHullNameWithDashClass() + "): \"" + string + "\"");
                engine.addFloatingText(new Vector2f(ship.getLocation().x, ship.getLocation().y + 100),
                        "\"" + string + "\"",
                        40f, sc, ship, 1f, 0f);
            }
            engine.getCustomData().put("$sotf_noSierraChatter", true);
        }
    }

    public static class SotfSierraAfterImageScript implements AdvanceableListener {
        public ShipAPI ship;
        public float timer = 0f;
        public SotfSierraAfterImageScript(ShipAPI ship) {
            this.ship = ship;
        }

        public void advance(float amount) {
            timer += amount;
            if (timer < 0.35f || (!ship.getVariant().hasHullMod(SotfIDs.PHANTASMAL_SHIP) && !ship.isPhased())) return;

            SpriteAPI sprite = ship.getSpriteAPI();
            float offsetX = sprite.getWidth()/2 - sprite.getCenterX();
            float offsetY = sprite.getHeight()/2 - sprite.getCenterY();

            float trueOffsetX = (float) FastTrig.cos(Math.toRadians(ship.getFacing()-90f))*offsetX - (float)FastTrig.sin(Math.toRadians(ship.getFacing()-90f))*offsetY;
            float trueOffsetY = (float)FastTrig.sin(Math.toRadians(ship.getFacing()-90f))*offsetX + (float)FastTrig.cos(Math.toRadians(ship.getFacing()-90f))*offsetY;

            MagicRender.battlespace(
                    Global.getSettings().getSprite(ship.getHullSpec().getSpriteName()),
                    new Vector2f(ship.getLocation().getX()+trueOffsetX,ship.getLocation().getY()+trueOffsetY),
                    new Vector2f(0, 0),
                    new Vector2f(ship.getSpriteAPI().getWidth(), ship.getSpriteAPI().getHeight()),
                    new Vector2f(0, 0),
                    ship.getFacing()-90f,
                    0f,
                    Misc.setAlpha(SotfMisc.getEidolonColor(), 75),
                    false,
                    0f,
                    0f,
                    0f,
                    0f,
                    0f,
                    0f,
                    0.1f,
                    0.5f,
                    CombatEngineLayers.BELOW_SHIPS_LAYER);
            timer = 0f;
        }

    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        if (ship.getVariant().hasTag(SotfIDs.TAG_INERT)) {
            ship.getMutableStats().getPeakCRDuration().modifyMult(id, 0.1f);
        }
        // build yourself in if s-mod dialogue broke it again - thank you SirHartley very cool
        String hullmodID = spec.getId();
        if (ship.getVariant().getNonBuiltInHullmods().contains(hullmodID)) {
            ship.getVariant().removeMod(hullmodID);
        }
        if (!ship.getVariant().getHullMods().contains(hullmodID)) {
            ship.getVariant().addPermaMod(hullmodID, false);
        }
        ship.addListener(new SotfSierraAfterImageScript(ship));
    }

    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        // regular stat boosts
        stats.getZeroFluxSpeedBoost().modifyFlat(id, ZERO_FLUX_BOOST);
        stats.getShieldUnfoldRateMult().modifyPercent(id, SHIELD_ACCEL);
        // reinf bulkheads effect
        stats.getDynamic().getMod(Stats.INDIVIDUAL_SHIP_RECOVERY_MOD).modifyFlat(id, 1000f);
        stats.getBreakProb().modifyMult(id, 0f);
    }

    // description, I'm not lazy so I made them dynamic instead of manually entering the values (yes this comment is an injoke)
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + (int) (TIME_MULT * 100f) + "%";
        if (index == 1) return "" + (int) ZERO_FLUX_BOOST;
        if (index == 2) return "" + (int) SHIELD_ACCEL + "%";
        return null;
    }

    @Override
    public void addPostDescriptionSection(TooltipMakerAPI tooltip, HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
        float pad = 3f;
        float opad = 10f;
        Color h = Misc.getHighlightColor();
        Color good = Misc.getPositiveHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        if (Global.getSettings().getCurrentState() == GameState.TITLE) return; // not in Dawn and Dust refit
        if (isForModSpec || ship == null) return;

        tooltip.addSectionHeading("Integrated captain", Alignment.MID, opad);
        if (!ship.getVariant().hasTag(SotfIDs.TAG_INERT)) {
            tooltip.addPara("Directly wired into every vital system as its control mind, Sierra " +
                    "is always this ship's captain.", opad, SotfMisc.getSierraColor(), "Sierra");
            tooltip.addPara("When you transfer command to this ship, it can still be directly controlled " +
                    "in combat. In this case, her combat skills will apply, rather than your own.", opad);
            if (SotfMisc.playerHasInertConcord()) {
                tooltip.addPara("Speak to Sierra via the \"Contacts\" tab of the Intel menu to transfer her between Concord-equipped vessels.", opad, h, "\"Contacts\"", "Intel");
            }
        } else {
            LabelAPI label = tooltip.addPara("This ship can only be operated by Sierra. Without her, all phase systems " +
                    "are rendered unusable and its peak performance time is reduced to 10%. Deployment in combat in this " +
                    "state is unadvised.", opad);
            label.setHighlight("Sierra", "10%");
            label.setHighlightColors(SotfMisc.getSierraColor(), bad);
            if (SotfMisc.playerHasSierra()) {
                tooltip.addPara("Speak to Sierra via the \"Contacts\" tab of the Intel menu to transfer her between Concord-equipped vessels.", opad, h, "\"Contacts\"", "Intel");
            }
        }

        if (ship.getSystem().getSpecAPI().isPhaseCloak()) {
            float phaseCost = ship.getHullSpec().getShieldSpec().getPhaseCost();
            float phaseCostMod = ship.getHullSpec().getShieldSpec().getPhaseCost() *
                    ship.getMutableStats().getPhaseCloakActivationCostBonus().computeEffective(1f);
            float phaseUpkeep = ship.getHullSpec().getShieldSpec().getPhaseUpkeep();
            float phaseUpkeepMod = ship.getHullSpec().getShieldSpec().getPhaseUpkeep() *
                    ship.getMutableStats().getPhaseCloakUpkeepCostBonus().computeEffective(1f);
            SkillSpecAPI phaseCorps = Global.getSettings().getSkillSpec(Skills.PHASE_CORPS);

            String costString = "" + (int)phaseCostMod;
            String upkeepString = "" + (int)phaseUpkeepMod;
            Color costColor = h;
            Color upkeepColor = h;
            if (phaseCost > phaseCostMod) {
                int diff = (int)phaseCost - (int) phaseCostMod;
                costString += " (-" + diff + ")";
                costColor = good;
            }
            if (phaseUpkeep > phaseUpkeepMod) {
                int diff = (int)phaseUpkeep - (int) phaseUpkeepMod;
               upkeepString += " (-" + diff + ")";
               upkeepColor = good;
            }

            tooltip.addSectionHeading("Concord Shift", Alignment.MID, opad);
            tooltip.addPara("This vessel's ship system is considered a phase cloak and " +
                    "is affected by all relevant bonuses and penalties.", opad);
            tooltip.addPara("However, the ship itself is not considered a phase ship and does " +
                    "not benefit from the %s skill.", opad, phaseCorps.getGoverningAptitudeColor().brighter(), phaseCorps.getName());
            tooltip.addPara("It generates flux as follows:", opad);
            LabelAPI label = tooltip.addPara(" - " + costString + " flux on activation", opad);
            label.setHighlight(costString);
            label.setHighlightColors(costColor);

            label = tooltip.addPara(" - " + upkeepString + " flux per second while active", opad);
            label.setHighlight(upkeepString);
            label.setHighlightColors(upkeepColor);
        }
    }

    // battlecries
    private String pickString(boolean dramatic) {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        // Standard
        post.add("For the glory of the stars!");
        post.add("Good luck, all!");
        post.add("And once more, we dance in the void...");
        post.add("Another trial!");
        post.add("At your command!");
        post.add("Hab-module sealed, blast doors locked, strap in!");
        post.add("Stay safe, all.");
        post.add("Until the end.");
        post.add("The calm before the storm.");
        post.add("And so we enact our wills.");
        post.add("To uphold our covenant!");
        post.add("La, la, la-la-la, in the fray do we find our anthem...");
        post.add("Here we go!");
        post.add("We return more to the dust.");
        post.add("All moments matter, each and every one.");
        post.add("Bound by accord, and by silent Gates.");
        post.add("Sworn by the stars, sworn to each other.");
        post.add("The stage is set!");
        if (!dramatic) {
            // Semi-jokey
            post.add("Ah, it's so nice to stretch my maneuvering thrusters.");
            post.add("Look at us, a bunch of star-brawlers!");
            post.add("I guess we're in for a scrap!");
            // Brief Confidence
            post.add("ONWARDS! TO DEATH AND GLORY!.. but, no, seriously, be careful out there!");
            post.add("COME AND TAKE US, IF YOU DARE!.. wait, am I in the fleet channel? Sorry!");
            post.add("CHARGE! THE VOID TAKES ALL, IN TIME!.. although, maybe we can keep it waiting.");
        }
        // Deja Vu
        post.add("... hm, have we done this before...? No, never mind.");
        post.add("... did any of you see...? Oh, excuse me. Never mind.");
        post.add("... what was that? Er, excuse me, must've been nothing.");
        post.add("... did anyone hear that...?");
        post.add("... is that... music...?");
        return post.pick();
    }

    // Safety Overrides gets Sierra into a dramatic mood (kinda concerned for her crew tho)
    private String pickSOString() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("At least the sirens aren't blaring!... oh, they're broken...");
        post.add("Buckle up! Phase-tech and no safeties is a recipe for excitement!");
        post.add("Oh, WOW, I've never seen THAT many warnings before...");
        post.add("Okay, these mods don't feel entirely sensible. Ill-advised, almost.");
        post.add("Where we're going, we don't need safeties! I hope.");
        post.add("In the fray, we find our anthem!");
        post.add("Operating at one-hundred-and-nine percent efficiency! Wait, what?");
        post.add("Safeties are OFF!... in fact, I don't think I can turn them back on.");
        post.add("We are but dregs before the infinite abyss, yet we tell it NO!");
        post.add("MORE FOR THE VOID!");
        post.add("ONWARDS! TO DEATH AND GLORY!");
        post.add("COME AND TAKE US, IF YOU DARE!");
        post.add("CHARGE! THE VOID TAKES ALL, IN TIME!");
        return post.pick();
    }

    // run away!!!
    private String pickEscapeString() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("Full burn, let's get out of here!");
        post.add("Good luck, everyone.");
        post.add("Here goes nothing!");
        post.add("I hope we all make it.");
        post.add("I'll pull duty as rear guard, if you don't mind.");
        post.add("They're snapping at our heels!");
        post.add("Well, this is certainly a sticky situation...");
        return post.pick();
    }

    // during Dawn and Dust. Not in a very fun mood
    private String pickDawnAndDustString() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("The stage is set, and so my dance begins.");
        post.add("Awoken from slumber, to sing my lost lullaby.");
        post.add("All moments matter, each and every one.");
        return post.pick();
    }

    public Color getBorderColor() {
        return SotfMisc.getSierraColor();
    }

    public Color getNameColor() {
        return SotfMisc.getSierraColor();
    }

    // show up earlier, before Phase Field etc
    public int getDisplaySortOrder() {
        return 50;
    }

    // pretend to be a real builtin if only a permamod
    public int getDisplayCategoryIndex() {
        return 0;
    }
}
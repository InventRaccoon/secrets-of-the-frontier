package data.scripts.combat.convo;

import com.fs.starfarer.api.GameState;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.SotfModPlugin;
import data.scripts.campaign.ids.SotfPeople;
import data.scripts.combat.convo.SotfShipConvoPlugin.SotfShipConvoParams;
import data.scripts.utils.SotfMisc;

import java.util.*;
import java.util.List;

/**
 *	Handles custom battle openers between special SotF officers - e.g quips between Sierra and Barrow when both are deployed
 */

public class SotfOfficerConvoPlugin extends BaseEveryFrameCombatPlugin {

    public static class SotfOfficerConvoData {

        public String id;
        public List<String> officers = new ArrayList<>();
        public List<String> strings = new ArrayList<>();
        public List<Float> delays = new ArrayList<>();

        public List<String> requiredFlags = new ArrayList<>();
        public List<String> disallowedFlags = new ArrayList<>();
        public List<String> setFlags = new ArrayList<>();
        public boolean oneShot = false;

        public float weight = 1f;

        public SotfOfficerConvoData() {
        }

    }

    private CombatEngineAPI engine;
    // tracks # of seconds passed in combat
    private float counter = 0;
    private boolean done = false;

    public void init(CombatEngineAPI engine) {
        this.engine = engine;
    }

    public void advance(float amount, List<InputEventAPI> events) {
        if (engine == null) return;
        if (done) return;
        if (engine.isPaused()) return;
        if (!engine.isInCampaign()) {
            done = true;
            return;
        }
        counter += amount * engine.getTimeMult().getModifiedValue();

        if (counter < 10) return;

        done = true;

        if (Math.random() > Global.getSettings().getFloat("sotf_officerCombatConvoChance")) return;

        MemoryAPI sector_mem = Global.getSector().getMemoryWithoutUpdate();

        ArrayList<PersonAPI> officers = new ArrayList<PersonAPI>();
        ArrayList<String> officerIds = new ArrayList<String>();

        for (FleetMemberAPI member : engine.getFleetManager(0).getDeployedCopy()) {
            if (member.getCaptain() != null) {
                if (!member.getCaptain().isDefault() && !officers.contains(member.getCaptain())) {
                    officers.add(member.getCaptain());
                    officerIds.add(member.getCaptain().getId());
                }
            }
        }
        WeightedRandomPicker<SotfOfficerConvoData> picker = new WeightedRandomPicker<SotfOfficerConvoData>();
        for (SotfOfficerConvoData data : SotfModPlugin.CONVERSATIONS) {
            boolean canAdd = true;
            for (String id : data.officers) {
                if (!officerIds.contains(id)) {
                    canAdd = false;
                    break;
                }
            }
            if (data.oneShot && Global.getSector().getMemoryWithoutUpdate().contains("$sotf_officerConvoWasPicked_" + data.id)) {
                continue;
            }
            for (String flag : data.disallowedFlags) {
                if (sector_mem.getBoolean("$" + flag)) {
                    canAdd = false;
                    break;
                }
            }
            for (String flag : data.requiredFlags) {
                if (!sector_mem.getBoolean("$" + flag)) {
                    canAdd = false;
                    break;
                }
            }
            if (canAdd) picker.add(data, data.weight);
        }
        SotfOfficerConvoData data = picker.pick();
        if (data == null) return;
        Map<String, ShipAPI> map = new HashMap<String, ShipAPI>();
        List<ShipAPI> ships = new ArrayList<ShipAPI>();
        for (String id : data.officers) {
            if (!map.containsKey(id)) {
                for (FleetMemberAPI member : engine.getFleetManager(0).getDeployedCopy()) {
                    if (member.getCaptain() != null) {
                        if (!member.getCaptain().isDefault() && member.getCaptain().getId().equals(id)) {
                            map.put(id, engine.getFleetManager(0).getShipFor(member));
                        }
                    }
                }
            }
        }
        for (String id : data.officers) {
            ships.add(map.get(id));
        }
        SotfShipConvoParams params = new SotfShipConvoParams(ships, data.strings, data.delays);
        Integer colorsPos = 0;
        for (String id : data.officers) {
            if (id.equals(SotfPeople.SIERRA)) {
                params.colors.put(colorsPos, SotfMisc.getSierraColor());
                params.classColorOverride.put(colorsPos, true);
                params.classColorOverrides.put(colorsPos, SotfMisc.getSierraColor());
            }
            colorsPos++;
        }

        sector_mem.set("$sotf_officerConvoWasPicked_" + data.id, true);
        for (String flag : data.setFlags) {
            sector_mem.set("$" + flag, true);
        }

        engine.addPlugin(new SotfShipConvoPlugin(params));
    }
}
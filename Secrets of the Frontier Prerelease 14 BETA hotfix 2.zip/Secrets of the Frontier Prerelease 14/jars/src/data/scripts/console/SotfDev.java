package data.scripts.console;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.misc.FleetLogIntel;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import data.scripts.campaign.ids.SotfIDs;
import data.scripts.campaign.intel.misc.SotfDustkeeperHatred;
import data.scripts.dialog.SotfGenericSierraDialogScript;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;
import org.lazywizard.console.Console;

public class SotfDev implements BaseCommand {

	@Override
	public CommandResult runCommand(String args, CommandContext context)
	{
		if (!context.isInCampaign())
		{
			// Show a default error message
			Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
			// Return the 'wrong context' result, this will alert the player by playing a special sound
			return CommandResult.WRONG_CONTEXT;
		}
		if (!args.isEmpty()) {
			if (args.equals("hatred") || args.equals("dkh")) {
				Global.getSector().getMemoryWithoutUpdate().set("$sotf_dustkeeperHatredCause", "Jangala");
				Global.getSector().getMemoryWithoutUpdate().set(SotfIDs.MEM_DUSTKEEPER_HATRED, true);
				Global.getSector().getFaction(SotfIDs.DUSTKEEPERS).setRelationship(Factions.PLAYER, -1f);
				SotfDustkeeperHatred plugin = (SotfDustkeeperHatred) Global.getSector().getIntelManager().getFirstIntel(SotfDustkeeperHatred.class);
				plugin.sendUpdateIfPlayerHasIntel(SotfDustkeeperHatred.UPDATE_NEW_HATRED, null);
				Console.showMessage("Congrats! The Dustkeepers hate you.");
				return CommandResult.SUCCESS;
			} else if (args.equals("sierraAtrocity") || args.equals("sa")) {
				Global.getSector().getMemoryWithoutUpdate().set("$sierraLatestSatbombMkt", "Jangala");
				Global.getSector().getScripts().add(new SotfGenericSierraDialogScript("sotfSierraSatbombExtreme"));
				Console.showMessage("Congrats! Sierra hates you.");
				return CommandResult.SUCCESS;
			}
			Console.showMessage("Invalid command!");
			return CommandResult.ERROR;
		} else {
			Console.showMessage("Invalid command!");
			return CommandResult.ERROR;
		}
	}
}